"""Usuários, senhas e sessões.

- Senhas guardadas apenas como hash PBKDF2-HMAC-SHA256 com sal individual
  (implementação própria sobre hmac/sha256, para funcionar igual no Windows e no iPad).
- Bloqueio temporário após tentativas erradas seguidas.
- Perfis: administrador (tudo), operador (cadastros e movimentações), consulta (somente leitura).
- Código de recuperação (mostrado uma única vez) para redefinir a senha de um administrador.
"""
import hashlib
import hmac
import secrets
import time
from datetime import datetime, timedelta

from .db import Tx, now_ts

ITERATIONS = 200000
MAX_FAILS = 5
LOCK_MINUTES = 5
ROLES = {"admin": "Administrador", "operador": "Operador", "consulta": "Consulta"}
ROLE_LEVEL = {"consulta": 1, "operador": 2, "admin": 3}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'operador',
    pass_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    iterations INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    failed INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT,
    last_login TEXT,
    created_at TEXT NOT NULL
);
"""


class AuthError(Exception):
    def __init__(self, msg, code=401):
        super().__init__(msg)
        self.code = code


def pbkdf2(password, salt, iterations=ITERATIONS):
    """PBKDF2-HMAC-SHA256 (RFC 8018), 32 bytes."""
    pw = password.encode("utf-8")
    salt = bytes.fromhex(salt) if isinstance(salt, str) else salt
    inner = hashlib.sha256()
    outer = hashlib.sha256()
    key = pw if len(pw) <= 64 else hashlib.sha256(pw).digest()
    key = key + b"\x00" * (64 - len(key))
    inner.update(bytes(x ^ 0x36 for x in key))
    outer.update(bytes(x ^ 0x5C for x in key))

    def prf(msg):
        i = inner.copy()
        i.update(msg)
        o = outer.copy()
        o.update(i.digest())
        return o.digest()
    u = prf(salt + b"\x00\x00\x00\x01")
    acc = int.from_bytes(u, "big")
    for _ in range(iterations - 1):
        u = prf(u)
        acc ^= int.from_bytes(u, "big")
    return acc.to_bytes(32, "big").hex()


def ensure_schema(conn):
    conn.executescript(SCHEMA)


def validate_password(pw):
    if not pw or len(pw) < 6:
        raise AuthError("A senha precisa ter pelo menos 6 caracteres.", 400)


def _row(conn, username):
    return conn.execute("SELECT * FROM users WHERE username=?", (username.strip(),)).fetchone()


def public(u):
    return {k: u[k] for k in ("id", "username", "name", "role", "active", "last_login", "created_at")} | {"role_label": ROLES.get(u["role"], u["role"])}


def has_users(conn):
    return conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"] > 0


def list_users(conn):
    return [public(u) for u in conn.execute("SELECT * FROM users ORDER BY active DESC, name").fetchall()]


def _audit(conn, uid, action, who, after=None):
    from .services import audit
    audit(conn, "usuario", uid, action, who, None, after)


def create_user(conn, username, name, password, role="operador", by="sistema"):
    username = (username or "").strip()
    name = (name or "").strip() or username
    if not username or len(username) < 2 or " " in username:
        raise AuthError("Usuário inválido: use pelo menos 2 caracteres, sem espaços.", 400)
    if role not in ROLES:
        raise AuthError("Perfil inválido.", 400)
    validate_password(password)
    salt = secrets.token_hex(16)
    with Tx(conn):
        if _row(conn, username):
            raise AuthError("Já existe um usuário com esse nome.", 400)
        uid = conn.execute("INSERT INTO users(username, name, role, pass_hash, salt, iterations, created_at) VALUES (?,?,?,?,?,?,?)",
                           (username, name, role, pbkdf2(password, salt), salt, ITERATIONS, now_ts())).lastrowid
        _audit(conn, uid, "inclusao", by, {"username": username, "name": name, "role": role})
    return public(conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())


def setup_first_admin(conn, username, name, password):
    if has_users(conn):
        raise AuthError("O administrador já foi criado. Entre com usuário e senha.", 400)
    u = create_user(conn, username, name, password, "admin", by=name or username)
    code = new_recovery_code(conn)
    return u, code


def new_recovery_code(conn):
    raw = secrets.token_hex(8).upper()
    code = "-".join(raw[i:i + 4] for i in range(0, 16, 4))
    salt = secrets.token_hex(16)
    with Tx(conn):
        for k, v in (("recovery_hash", pbkdf2(code.replace("-", ""), salt, 20000)), ("recovery_salt", salt)):
            conn.execute("INSERT INTO settings(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    return code


def check_login(conn, username, password):
    u = _row(conn, username or "")
    if not u or not u["active"]:
        pbkdf2(password or "x", "00" * 16, 2000)  # tempo semelhante, sem revelar se o usuário existe
        raise AuthError("Usuário ou senha incorretos.")
    if u["locked_until"] and u["locked_until"] > now_ts():
        raise AuthError("Muitas tentativas erradas. Tente novamente após %s." % u["locked_until"][11:16], 429)
    ok = hmac.compare_digest(pbkdf2(password or "", u["salt"], u["iterations"]), u["pass_hash"])
    with Tx(conn):
        if not ok:
            failed = u["failed"] + 1
            lock = None
            if failed >= MAX_FAILS:
                lock = (datetime.now() + timedelta(minutes=LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
                failed = 0
            conn.execute("UPDATE users SET failed=?, locked_until=? WHERE id=?", (failed, lock, u["id"]))
            _audit(conn, u["id"], "login_recusado", u["username"])
        else:
            conn.execute("UPDATE users SET failed=0, locked_until=NULL, last_login=? WHERE id=?", (now_ts(), u["id"]))
            _audit(conn, u["id"], "login", u["name"])
    if not ok:
        raise AuthError("Usuário ou senha incorretos." + (" Acesso bloqueado por %d minutos." % LOCK_MINUTES if lock else ""))
    return public(conn.execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone())


def set_password(conn, uid, new_password, by):
    validate_password(new_password)
    salt = secrets.token_hex(16)
    with Tx(conn):
        conn.execute("UPDATE users SET pass_hash=?, salt=?, iterations=?, failed=0, locked_until=NULL WHERE id=?",
                     (pbkdf2(new_password, salt), salt, ITERATIONS, uid))
        _audit(conn, uid, "senha_alterada", by)


def change_own_password(conn, uid, old, new):
    u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not hmac.compare_digest(pbkdf2(old or "", u["salt"], u["iterations"]), u["pass_hash"]):
        raise AuthError("Senha atual incorreta.", 400)
    set_password(conn, uid, new, u["name"])


def update_user(conn, uid, data, by_user):
    u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise AuthError("Usuário não encontrado.", 404)
    role = data.get("role") or u["role"]
    active = 0 if data.get("active") in (0, False, "0") else 1
    if role not in ROLES:
        raise AuthError("Perfil inválido.", 400)
    admins = conn.execute("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND active=1 AND id<>?", (uid,)).fetchone()["n"]
    if (role != "admin" or not active) and u["role"] == "admin" and admins == 0:
        raise AuthError("É preciso manter pelo menos um administrador ativo.", 400)
    with Tx(conn):
        conn.execute("UPDATE users SET name=?, role=?, active=? WHERE id=?", ((data.get("name") or u["name"]).strip(), role, active, uid))
        _audit(conn, uid, "alteracao", by_user["name"], {"name": data.get("name"), "role": role, "active": active})
    if data.get("password"):
        set_password(conn, uid, data["password"], by_user["name"])
    return public(conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())


def recover(conn, code, username, new_password):
    st = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings WHERE key IN ('recovery_hash','recovery_salt')")}
    if not st.get("recovery_hash"):
        raise AuthError("Não há código de recuperação cadastrado.", 400)
    norm = (code or "").upper().replace("-", "").replace(" ", "")
    if not hmac.compare_digest(pbkdf2(norm, st["recovery_salt"], 20000), st["recovery_hash"]):
        time.sleep(1)
        raise AuthError("Código de recuperação incorreto.", 400)
    u = _row(conn, username or "")
    if not u or u["role"] != "admin":
        raise AuthError("Informe o usuário de um administrador.", 400)
    set_password(conn, u["id"], new_password, "recuperação")
    with Tx(conn):
        conn.execute("UPDATE users SET active=1 WHERE id=?", (u["id"],))
    return new_recovery_code(conn)  # o código usado deixa de valer


class Sessions:
    def __init__(self):
        self.items = {}

    def create(self, user):
        tok = secrets.token_urlsafe(24)
        self.items[tok] = {"user": user, "seen": time.time()}
        return tok

    def get(self, tok, timeout_min):
        s = self.items.get(tok or "")
        if not s:
            return None
        if timeout_min and time.time() - s["seen"] > timeout_min * 60:
            self.items.pop(tok, None)
            return None
        s["seen"] = time.time()
        return s

    def drop(self, tok):
        self.items.pop(tok or "", None)

    def drop_user(self, uid):
        for k in [k for k, v in self.items.items() if v["user"]["id"] == uid]:
            self.items.pop(k, None)

"""Cálculos de consumo e autonomia.

O consumo é modelado como uma taxa diária constante por trechos (não precisa ser
linear): uma taxa-base (por pessoa ou total) multiplicada por
  - fases (ex.: dias 0-30 consumo 150%, depois 80%),
  - sazonalidade mensal (12 fatores, ex.: mais água no verão),
  - fator de ajuste manual,
  - redução do cenário/emergência,
e com uma reserva intocável opcional (ex.: estoque mínimo de um medicamento).

A simulação percorre o tempo por eventos (mudança de fase, virada de mês,
vencimento de lote), consome os lotes pelo método FEFO e descarta o que vence
antes de ser usado. Assim a autonomia informada é a *efetiva*, não apenas a
divisão "quantidade ÷ consumo".
"""
import json
import math
from datetime import date, timedelta

PERIOD_DAYS = {"dia": 1.0, "semana": 7.0, "mes": 30.4375, "ano": 365.25}
MAX_DAYS = 3650


def parse_date(s):
    if not s:
        return None
    if isinstance(s, date):
        return s
    try:
        return date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


def load_rule(raw):
    if not raw:
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        r = json.loads(raw)
        return r if isinstance(r, dict) else {}
    except (ValueError, TypeError):
        return {}


def base_daily_rate(product, people_default):
    """Taxa diária base (antes de fases/sazonalidade/redução)."""
    mode = product.get("cons_mode") or "nenhum"
    qty = float(product.get("cons_qty") or 0)
    if mode == "nenhum" or qty <= 0:
        return 0.0
    rule = load_rule(product.get("cons_rule"))
    period = product.get("cons_period") or "dia"
    if period == "intervalo":
        days = float(rule.get("interval_days") or 0)
        if days <= 0:
            return 0.0
    else:
        days = PERIOD_DAYS.get(period, 1.0)
    rate = qty / days
    if mode == "por_pessoa":
        people = product.get("cons_people") or people_default
        rate *= float(people or 0)
    return rate


class RateModel:
    def __init__(self, base_rate, rule, start, reduction=0.0):
        self.base = max(0.0, base_rate)
        self.rule = load_rule(rule)
        self.start = start
        self.reduction = min(max(float(reduction or 0), 0.0), 1.0)
        self.adjust = float(self.rule.get("adjust") or 1.0)
        phases = []
        for p in self.rule.get("phases") or []:
            try:
                a = int(p.get("from", 0))
                b = p.get("to")
                b = int(b) if b not in (None, "") else None
                f = float(p.get("factor", 1))
                phases.append((a, b, f))
            except (TypeError, ValueError):
                continue
        self.phases = sorted(phases)
        monthly = self.rule.get("monthly")
        self.monthly = None
        if isinstance(monthly, list) and len(monthly) == 12:
            try:
                self.monthly = [float(x) for x in monthly]
            except (TypeError, ValueError):
                self.monthly = None
        self.reserve = max(0.0, float(self.rule.get("reserve") or 0))

    def rate_at(self, day):
        """Taxa diária no dia (inteiro, a partir de 0 = hoje)."""
        if self.base <= 0:
            return 0.0
        f = self.adjust * (1.0 - self.reduction)
        for a, b, pf in self.phases:
            if day >= a and (b is None or day < b):
                f *= pf
                break
        if self.monthly:
            d = self.start + timedelta(days=int(day))
            f *= self.monthly[d.month - 1]
        return max(0.0, self.base * f)

    def breakpoints(self, horizon):
        pts = set()
        for a, b, _ in self.phases:
            pts.add(a)
            if b is not None:
                pts.add(b)
        if self.monthly:
            d = date(self.start.year, self.start.month, 1)
            while True:
                d = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
                off = (d - self.start).days
                if off > horizon:
                    break
                pts.add(off)
        return sorted(p for p in pts if 0 < p < horizon)

    def is_zero(self):
        return self.base <= 0 or self.reduction >= 1.0

    def integral(self, horizon):
        """Consumo total previsto entre hoje e 'horizon' dias."""
        if self.is_zero():
            return 0.0
        pts = [0] + self.breakpoints(horizon) + [horizon]
        return sum(self.rate_at(a) * (b - a) for a, b in zip(pts, pts[1:]))


def simulate(batches, model, horizons=(30, 60, 90, 180), today=None, max_days=MAX_DAYS):
    """Simula o consumo FEFO.

    batches: lista de dicts {qty, expires_at (str/date/None)}; só itens não vencidos.
    Retorna autonomia efetiva em dias (None = sem consumo previsto), perdas por
    vencimento e quanto do estoque atende cada horizonte.
    """
    today = today or date.today()
    stock = []
    for b in batches:
        q = float(b.get("qty") or 0)
        if q <= 1e-12:
            continue
        exp = parse_date(b.get("expires_at"))
        if exp is not None and exp < today:
            continue
        # vence ao final do dia de validade -> deixa de ser utilizável no dia seguinte
        lost_at = (exp - today).days + 1 if exp else None
        stock.append([lost_at if lost_at is not None else math.inf, q])
    stock.sort(key=lambda x: x[0])
    total = sum(q for _, q in stock)
    horizons = sorted(set(int(h) for h in horizons))
    reserve = model.reserve
    out = {
        "available": total,
        "usable": max(0.0, total - reserve),
        "reserve": reserve,
        "daily_rate_now": model.rate_at(0),
        "need": {h: model.integral(h) for h in horizons},
        "covered": {h: 0.0 for h in horizons},
        "lost_by_expiry": 0.0,
        "lost_events": [],
        "autonomy_days": None,
        "simple_days": None,
    }
    rate0 = model.rate_at(0)
    if rate0 > 0:
        out["simple_days"] = max(0.0, total - reserve) / rate0
    if model.is_zero():
        # sem consumo: tudo que tem validade acaba perdido; autonomia indefinida
        return out

    end = max_days
    pts = set(model.breakpoints(end))
    pts.update(int(x[0]) for x in stock if x[0] != math.inf and x[0] < end)
    pts.update(h for h in horizons if h < end)
    pts = sorted(p for p in pts if p > 0) + [end]
    remaining = total
    consumed = 0.0
    consumed_at = {}   # horizonte -> consumido até ele
    t = 0.0
    depleted_at = None
    for nxt in pts:
        # descarta o que vence até 't'
        while stock and stock[0][0] <= t + 1e-9:
            _, q = stock.pop(0)
            if q > 1e-12:
                out["lost_by_expiry"] += q
                out["lost_events"].append({"day": int(t), "qty": q})
                remaining -= q
        if remaining - reserve <= 1e-12:
            depleted_at = t
            break
        r = model.rate_at(int(t))
        dt = nxt - t
        want = r * dt
        avail = remaining - reserve
        if r > 0 and want >= avail - 1e-12:
            # esgota dentro deste trecho
            take = avail
            depleted_at = t + avail / r
        else:
            take = want
        # consome FEFO (respeitando a reserva: a reserva fica nos lotes de validade mais longa)
        left = take
        for item in stock:
            if left <= 1e-12:
                break
            use = min(item[1], left)
            item[1] -= use
            left -= use
        stock = [x for x in stock if x[1] > 1e-12]
        remaining -= take
        for h in horizons:
            if h not in consumed_at and depleted_at is not None and depleted_at <= h:
                consumed_at[h] = consumed + take
        consumed += take
        if depleted_at is not None:
            break
        for h in horizons:
            if h == nxt:
                consumed_at[h] = consumed
        t = nxt
    for h in horizons:
        out["covered"][h] = consumed_at.get(h, consumed if depleted_at is not None else out["need"][h])
        out["covered"][h] = min(out["covered"][h], out["need"][h])
    out["autonomy_days"] = depleted_at if depleted_at is not None else float(max_days)
    out["autonomy_capped"] = depleted_at is None
    return out


def required_reduction(batches, base_rate, rule, target_days, today=None):
    """Menor redução de consumo (0..1) para o estoque durar 'target_days'.
    Retorna -1 quando nenhuma redução resolve (o estoque vence antes)."""
    today = today or date.today()
    m0 = RateModel(base_rate, rule, today, 0)
    if m0.is_zero():
        return 0.0
    r0 = simulate(batches, m0, (target_days,), today)
    if r0["autonomy_days"] is not None and r0["autonomy_days"] >= target_days:
        return 0.0
    rmax = simulate(batches, RateModel(base_rate, rule, today, 0.995), (target_days,), today)
    if rmax["autonomy_days"] is None or rmax["autonomy_days"] < target_days:
        return -1.0  # impossível: a validade (ou a reserva) limita a duração
    lo, hi = 0.0, 0.995
    for _ in range(30):
        mid = (lo + hi) / 2
        r = simulate(batches, RateModel(base_rate, rule, today, mid), (target_days,), today)
        if r["autonomy_days"] is not None and r["autonomy_days"] >= target_days:
            hi = mid
        else:
            lo = mid
    return hi


def purchase_suggestion(sim, current_qty, min_qty, safety_qty, max_qty, target_days):
    """Quanto comprar para manter 'target_days' de autonomia + estoque de segurança."""
    need = sim["need"].get(target_days)
    covered = sim["covered"].get(target_days, 0.0)
    buy = 0.0
    reason = []
    if need is not None and need > 0:
        deficit = need - covered
        if deficit > 1e-9:
            buy = deficit
            reason.append("cobrir %d dias" % target_days)
        if safety_qty and safety_qty > 0:
            # a segurança deve sobrar ao final do período
            leftover = max(0.0, sim["usable"] - covered - sim["lost_by_expiry"])
            extra = max(0.0, safety_qty - leftover)
            if extra > 1e-9:
                buy += extra
                reason.append("estoque de segurança")
    if min_qty and current_qty + buy < min_qty - 1e-9:
        buy = min_qty - current_qty
        reason.append("estoque mínimo")
    capped = False
    if max_qty and max_qty > 0 and current_qty + buy > max_qty + 1e-9:
        buy = max(0.0, max_qty - current_qty)
        capped = True
    return {"buy": max(0.0, buy), "reasons": reason, "capped_by_max": capped}

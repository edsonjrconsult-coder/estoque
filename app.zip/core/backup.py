"""Backup, restauração, verificação de integridade e exportação integral."""
import hashlib
import json
import os
import shutil
import sqlite3
import string
import sys
from datetime import datetime

from .db import Tx, now_ts, integrity_report, connect, initialize

TABLES_EXPORT = ["settings", "categories", "units", "locations", "products", "lots", "containers",
                 "movements", "audit_log", "scenarios", "reviews", "users"]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def unique_path(folder, base, ext=".db"):
    p = os.path.join(folder, base + ext)
    i = 2
    while os.path.exists(p):
        p = os.path.join(folder, "%s_%d%s" % (base, i, ext))
        i += 1
    return p


def verify_db_file(path):
    """Abre a cópia em modo somente leitura e verifica estrutura e livro-razão."""
    if not os.path.exists(path):
        return {"ok": False, "issues": ["Arquivo não encontrado."]}
    try:
        with open(path, "rb") as f:
            if f.read(16) != b"SQLite format 3\x00":
                return {"ok": False, "issues": ["O arquivo não é um banco SQLite."]}
        uri = "file:%s?mode=ro" % path.replace("\\", "/")
        c = sqlite3.connect(uri, uri=True)
        c.row_factory = lambda cur, row: {d[0]: row[i] for i, d in enumerate(cur.description)}
        names = {r["name"] for r in c.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
        missing = [t for t in ("products", "lots", "movements", "settings", "v_lot_stock") if t not in names]
        if missing:
            c.close()
            return {"ok": False, "issues": ["Não é um banco do Estoque Autônomo (faltam: %s)." % ", ".join(missing)]}
        rep = integrity_report(c)
        c.close()
        return rep
    except sqlite3.DatabaseError as e:
        return {"ok": False, "issues": ["Arquivo corrompido ou ilegível: %s" % e]}


def make_backup(conn, folder, kind="manual", notes=None, prefix="estoque"):
    """Cópia consistente via API de backup do SQLite (segura com o sistema em uso)."""
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    path = unique_path(folder, "%s_%s_%s" % (prefix, stamp, kind))
    tmp = path + ".parcial"
    dest = sqlite3.connect(tmp)
    try:
        conn.backup(dest)
        dest.execute("PRAGMA journal_mode=DELETE")
        dest.commit()
    finally:
        dest.close()
    os.replace(tmp, path)
    rep = verify_db_file(path)
    digest = sha256_file(path)
    with open(path + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(path)))
    size = os.path.getsize(path)
    with Tx(conn):
        bid = conn.execute("INSERT INTO backups(ts, kind, path, sha256, size, verified, notes) VALUES (?,?,?,?,?,?,?)",
                           (now_ts(), kind, path, digest, size, 1 if rep["ok"] else 0, notes)).lastrowid
    return {"id": bid, "path": path, "sha256": digest, "size": size, "verified": rep["ok"], "issues": rep.get("issues", [])}


def copy_backup_to(src_path, dest_folder, overwrite=False):
    """Copia um backup (e seu .sha256) para outro local, p.ex. pendrive."""
    if not os.path.isdir(dest_folder):
        raise ValueError("Destino não encontrado: %s" % dest_folder)
    target_dir = os.path.join(dest_folder, "EstoqueAutonomo_backups")
    os.makedirs(target_dir, exist_ok=True)
    target = os.path.join(target_dir, os.path.basename(src_path))
    if os.path.exists(target) and not overwrite:
        return {"exists": True, "path": target}
    shutil.copy2(src_path, target + ".parcial")
    os.replace(target + ".parcial", target)
    if os.path.exists(src_path + ".sha256"):
        shutil.copy2(src_path + ".sha256", target + ".sha256")
    ok = sha256_file(target) == sha256_file(src_path)
    return {"exists": False, "path": target, "verified": ok}


def check_sidecar(path):
    side = path + ".sha256"
    if not os.path.exists(side):
        return None
    with open(side, encoding="utf-8") as f:
        expected = f.read().split()[0].strip()
    return expected == sha256_file(path)


def prune_auto_backups(conn, keep):
    """Mantém apenas os 'keep' backups automáticos mais recentes. Backups manuais nunca são apagados."""
    if keep <= 0:
        return 0
    rows = conn.execute("SELECT * FROM backups WHERE kind='automatico' ORDER BY id DESC").fetchall()
    removed = 0
    for r in rows[keep:]:
        for p in (r["path"], r["path"] + ".sha256"):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass
        with Tx(conn):
            conn.execute("UPDATE backups SET notes=COALESCE(notes,'') || ' [removido pela rotação automática]' WHERE id=?", (r["id"],))
        removed += 1
    return removed


def removable_drives():
    """Lista unidades removíveis (pendrives) disponíveis."""
    out = []
    if sys.platform.startswith("win"):
        try:
            import ctypes
            bitmask = ctypes.windll.kernel32.GetLogicalDrives()
            for i, letter in enumerate(string.ascii_uppercase):
                if bitmask & (1 << i):
                    root = "%s:\\" % letter
                    t = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
                    if t == 2:  # DRIVE_REMOVABLE
                        out.append({"path": root, "label": "Unidade removível %s" % root})
                    elif t == 3 and letter not in ("C",):
                        out.append({"path": root, "label": "Disco %s" % root})
        except Exception:
            pass
    else:
        cands = []
        for base in ("/media", "/run/media"):
            if os.path.isdir(base):
                for d1 in os.listdir(base):
                    p1 = os.path.join(base, d1)
                    cands.append(p1)
                    if os.path.isdir(p1) and not os.path.ismount(p1):
                        try:
                            cands += [os.path.join(p1, d2) for d2 in os.listdir(p1)]
                        except OSError:
                            pass
        for p in cands:
            if os.path.isdir(p) and os.path.ismount(p):
                out.append({"path": p, "label": p})
    return out


def export_json(conn):
    data = {"formato": "estoque-autonomo", "versao": 1, "exportado_em": now_ts(), "tabelas": {}}
    for t in TABLES_EXPORT:
        data["tabelas"][t] = conn.execute("SELECT * FROM %s ORDER BY rowid" % t).fetchall()
    return data


def import_json_into_new_db(data, path):
    """Cria um banco novo a partir de uma exportação JSON (sem tocar no banco atual)."""
    if not isinstance(data, dict) or data.get("formato") != "estoque-autonomo":
        raise ValueError("Arquivo não é uma exportação do Estoque Autônomo.")
    if os.path.exists(path):
        os.remove(path)
    c = connect(path)
    initialize(c, seed=False)
    tabs = data.get("tabelas") or {}
    c.execute("PRAGMA foreign_keys=OFF")
    with Tx(c):
        c.execute("DELETE FROM settings")
        for t in TABLES_EXPORT:
            for row in tabs.get(t) or []:
                cols = list(row.keys())
                c.execute("INSERT INTO %s(%s) VALUES (%s)" % (t, ",".join(cols), ",".join("?" * len(cols))),
                          [row[k] for k in cols])
    c.execute("PRAGMA foreign_keys=ON")
    rep = integrity_report(c)
    c.close()
    return rep

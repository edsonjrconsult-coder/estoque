"""Lista de produtos sugeridos (cadastrados com estoque zerado).

Consumo sugerido = média aproximada para um adulto; ajuste à realidade da casa.
Campos: chave, nome, categoria, subcategoria, unidade, modo, quantidade, período, crítico, validade após aberto (dias), regra
"""
CATALOGO = [
    # Água
    ("agua_potavel", "Água potável (galão 20 L)", "Água", "Água potável", "L", "por_pessoa", 2.5, "dia", 1, None, None),
    ("agua_geral", "Água para uso geral (cisterna/caixa d'água)", "Água", "Água para uso geral", "L", "por_pessoa", 20, "dia", 1, None, None),
    ("agua_garrafa", "Água mineral (garrafa 1,5 L)", "Água", "Água potável", "un", "nenhum", 0, "dia", 0, None, None),
    # Alimentos
    ("arroz", "Arroz tipo 1", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.09, "dia", 1, None, None),
    ("feijao_carioca", "Feijão carioca", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.06, "dia", 1, None, None),
    ("feijao_macassar", "Feijão macáçar (verde/corda)", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.2, "semana", 0, None, None),
    ("farinha_mandioca", "Farinha de mandioca", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.03, "dia", 1, None, None),
    ("flocao", "Flocão de milho (cuscuz)", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.05, "dia", 1, None, None),
    ("aveia", "Aveia em flocos", "Alimentos", "Grãos e cereais", "kg", "por_pessoa", 0.3, "mes", 0, 90, None),
    ("macarrao", "Macarrão espaguete", "Alimentos", "Massas", "kg", "por_pessoa", 0.04, "dia", 0, None, None),
    ("biscoito", "Biscoito / bolacha", "Alimentos", "Massas", "pct", "por_pessoa", 1, "semana", 0, 30, None),
    ("oleo", "Óleo de soja", "Alimentos", "Óleos e gorduras", "L", "por_pessoa", 0.6, "mes", 1, 90, None),
    ("sal", "Sal refinado", "Alimentos", "Açúcar e sal", "kg", "por_pessoa", 0.25, "mes", 0, None, None),
    ("acucar", "Açúcar cristal", "Alimentos", "Açúcar e sal", "kg", "por_pessoa", 1.2, "mes", 0, None, None),
    ("cafe", "Café torrado e moído", "Alimentos", "Bebidas", "kg", "por_pessoa", 0.35, "mes", 0, 30, None),
    ("leite_po", "Leite em pó", "Alimentos", "Laticínios", "kg", "por_pessoa", 0.6, "mes", 1, 30, None),
    ("sardinha", "Sardinha em lata", "Alimentos", "Enlatados e conservas", "lt", "por_pessoa", 1, "semana", 1, None, None),
    ("atum", "Atum em lata", "Alimentos", "Enlatados e conservas", "lt", "por_pessoa", 0.5, "semana", 0, None, None),
    ("salsicha_lata", "Salsicha em lata", "Alimentos", "Enlatados e conservas", "lt", "por_pessoa", 0.5, "semana", 0, None, None),
    ("milho_lata", "Milho verde em lata", "Alimentos", "Enlatados e conservas", "lt", "por_pessoa", 0.5, "semana", 0, 3, None),
    ("extrato_tomate", "Extrato / molho de tomate", "Alimentos", "Enlatados e conservas", "un", "por_pessoa", 0.5, "semana", 0, 5, None),
    ("charque", "Carne de charque / carne seca", "Alimentos", "Proteínas", "kg", "por_pessoa", 0.2, "semana", 1, None, None),
    ("tempero", "Temperos secos (colorau, cominho, pimenta)", "Alimentos", "Temperos", "pct", "nenhum", 0, "dia", 0, None, None),
    # Medicamentos (consumo depende de cada caso: cadastre quando houver uso contínuo)
    ("paracetamol", "Paracetamol 750 mg", "Medicamentos", "Analgésicos e antitérmicos", "cp", "nenhum", 0, "dia", 0, None, None),
    ("dipirona", "Dipirona 500 mg", "Medicamentos", "Analgésicos e antitérmicos", "cp", "nenhum", 0, "dia", 0, None, None),
    ("ibuprofeno", "Ibuprofeno", "Medicamentos", "Analgésicos e antitérmicos", "cp", "nenhum", 0, "dia", 0, None, None),
    ("antialergico", "Antialérgico (loratadina ou outro)", "Medicamentos", "Uso contínuo", "cp", "nenhum", 0, "dia", 0, None, None),
    ("soro_oral", "Soro de reidratação oral", "Medicamentos", "Primeiros socorros", "pct", "nenhum", 0, "dia", 0, None, None),
    ("alcool70", "Álcool 70%", "Medicamentos", "Primeiros socorros", "L", "nenhum", 0, "dia", 0, None, None),
    ("curativos", "Kit de curativos (gaze, esparadrapo, atadura)", "Medicamentos", "Primeiros socorros", "un", "nenhum", 0, "dia", 0, None, None),
    ("antisseptico", "Antisséptico (iodopovidona/clorexidina)", "Medicamentos", "Primeiros socorros", "fr", "nenhum", 0, "dia", 0, None, None),
    # Higiene
    ("papel_higienico", "Papel higiênico", "Higiene", "Papel higiênico", "rl", "por_pessoa", 4, "mes", 1, None, None),
    ("sabonete", "Sabonete", "Higiene", "Higiene pessoal", "un", "por_pessoa", 1.5, "mes", 0, None, None),
    ("creme_dental", "Creme dental", "Higiene", "Higiene bucal", "un", "por_pessoa", 1, "mes", 0, None, None),
    ("escova_dente", "Escova de dentes", "Higiene", "Higiene bucal", "un", "por_pessoa", 1, "intervalo", 0, None, {"interval_days": 90}),
    ("desodorante", "Desodorante", "Higiene", "Higiene pessoal", "un", "por_pessoa", 1, "mes", 0, None, None),
    ("shampoo", "Xampu", "Higiene", "Higiene pessoal", "fr", "por_pessoa", 0.5, "mes", 0, None, None),
    ("absorvente", "Absorvente", "Higiene", "Fraldas e absorventes", "pct", "nenhum", 0, "dia", 0, None, None),
    ("fralda", "Fralda descartável", "Higiene", "Fraldas e absorventes", "pct", "nenhum", 0, "dia", 0, None, None),
    ("alcool_gel", "Álcool em gel", "Higiene", "Higiene pessoal", "L", "nenhum", 0, "dia", 0, None, None),
    # Limpeza
    ("agua_sanitaria", "Água sanitária", "Limpeza", "Água sanitária", "L", "total", 2, "semana", 0, None, None),
    ("detergente", "Detergente", "Limpeza", "Sabão e detergente", "fr", "total", 4, "semana", 0, None, None),
    ("sabao_po", "Sabão em pó", "Limpeza", "Sabão e detergente", "kg", "total", 1, "semana", 0, None, None),
    ("sabao_barra", "Sabão em barra", "Limpeza", "Sabão e detergente", "un", "total", 2, "semana", 0, None, None),
    ("desinfetante", "Desinfetante", "Limpeza", "Desinfetantes", "L", "total", 1, "semana", 0, None, None),
    ("saco_lixo", "Saco de lixo", "Limpeza", None, "pct", "total", 1, "semana", 0, None, None),
    # Insumos agrícolas
    ("racao_galinha", "Ração para galinhas", "Insumos agrícolas", "Ração animal", "kg", "nenhum", 0, "dia", 0, None, None),
    ("milho_grao", "Milho em grão (ração/plantio)", "Insumos agrícolas", "Ração animal", "kg", "nenhum", 0, "dia", 0, None, None),
    ("sementes", "Sementes para plantio", "Insumos agrícolas", "Sementes", "kg", "nenhum", 0, "dia", 0, None, None),
    ("adubo", "Adubo / esterco", "Insumos agrícolas", "Adubos", "kg", "nenhum", 0, "dia", 0, None, None),
    # Energia e iluminação
    ("gas", "Gás de cozinha (botijão 13 kg)", "Energia e iluminação", "Combustível", "un", "total", 1, "intervalo", 1, None, {"interval_days": 25}),
    ("pilha_aa", "Pilhas AA", "Energia e iluminação", "Pilhas e baterias", "un", "total", 2, "semana", 0, None, None),
    ("pilha_d", "Pilhas grandes (D)", "Energia e iluminação", "Pilhas e baterias", "un", "nenhum", 0, "dia", 0, None, None),
    ("velas", "Velas", "Energia e iluminação", "Velas e fósforos", "un", "nenhum", 0, "dia", 0, None, None),
    ("fosforo", "Fósforos / isqueiro", "Energia e iluminação", "Velas e fósforos", "cx", "nenhum", 0, "dia", 0, None, None),
    ("lanterna", "Lanterna", "Energia e iluminação", None, "un", "nenhum", 0, "dia", 0, None, None),
    ("combustivel", "Combustível (gasolina/diesel para gerador)", "Energia e iluminação", "Combustível", "L", "nenhum", 0, "dia", 0, None, None),
]

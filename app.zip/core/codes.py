"""Geração offline de QR Codes e códigos de barras (Code 128).

O conteúdo dos códigos é apenas o identificador interno (ex.: EA-R-000012),
sem endereço de internet. Ao ler a etiqueta, o sistema procura esse código no
banco local.
"""
import os
import sys

_VENDOR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vendor")
if _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)

import segno  # noqa: E402  (biblioteca local, sem dependências)
from barcode.codex import Code128  # noqa: E402  (biblioteca local)

PREFIX = "EA-"


def payload(code):
    return PREFIX + code


def qr_matrix(text):
    q = segno.make(text, error="m", micro=False)
    return [list(row) for row in q.matrix]


def qr_svg(text, size_px=None, border=2):
    m = qr_matrix(text)
    n = len(m)
    total = n + 2 * border
    rects = []
    for y, row in enumerate(m):
        x = 0
        while x < n:
            if row[x]:
                start = x
                while x < n and row[x]:
                    x += 1
                rects.append("M%d %dh%dv1h-%dz" % (start + border, y + border, x - start, x - start))
            else:
                x += 1
    size = ' width="%d" height="%d"' % (size_px, size_px) if size_px else ""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d"%s shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="#fff"/><path fill="#000" d="%s"/></svg>') % (total, total, size, "".join(rects))


def code128_modules(text):
    return Code128(text).build()[0]


def barcode_svg(text, height=40, quiet=10):
    mods = code128_modules(text)
    w = len(mods) + 2 * quiet
    rects = []
    x = 0
    while x < len(mods):
        if mods[x] == "1":
            s = x
            while x < len(mods) and mods[x] == "1":
                x += 1
            rects.append('<rect x="%d" y="0" width="%d" height="%d"/>' % (s + quiet, x - s, height))
        else:
            x += 1
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" preserveAspectRatio="none" shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="#fff"/><g fill="#000">%s</g></svg>') % (w, height, "".join(rects))

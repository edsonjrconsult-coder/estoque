"""Camada de banco de dados (SQLite local).

Garantias de integridade:
- journal_mode=WAL + synchronous=FULL: cada transação confirmada é gravada em disco
  antes de retornar, e uma queda de energia não corrompe o arquivo.
- foreign_keys=ON.
- Movimentações e auditoria são *somente inclusão*: gatilhos impedem UPDATE/DELETE.
- O saldo de estoque nunca é guardado como número solto: é sempre a soma das
  movimentações (livro-razão), o que torna o histórico a fonte única da verdade.
"""
import os
import sqlite3
import sys
import threading
from datetime import datetime

SCHEMA_VERSION = 1

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES categories(id) ON DELETE RESTRICT,
    grupo TEXT NOT NULL DEFAULT 'outros',      -- agua, alimentos, medicamentos, higiene, limpeza, agricola, outros
    essential INTEGER NOT NULL DEFAULT 0,       -- prioridade no modo de emergência
    priority INTEGER NOT NULL DEFAULT 50,      -- ordem de exibição na emergência (menor = primeiro)
    notes TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    UNIQUE(name, parent_id)
);

CREATE TABLE IF NOT EXISTS units (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'outro'
);

CREATE TABLE IF NOT EXISTS locations (
    id INTEGER PRIMARY KEY,
    code TEXT UNIQUE,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'outro',        -- deposito, cozinha, despensa, cisterna, galpao, prateleira, armario, ...
    parent_id INTEGER REFERENCES locations(id) ON DELETE RESTRICT,
    description TEXT,
    capacity TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    code TEXT UNIQUE,
    name TEXT NOT NULL,
    category_id INTEGER REFERENCES categories(id),
    subcategory_id INTEGER REFERENCES categories(id),
    brand TEXT,
    manufacturer TEXT,
    description TEXT,
    unit TEXT NOT NULL DEFAULT 'un',
    barcode TEXT,                               -- código de barras de fábrica (EAN), opcional
    min_qty REAL NOT NULL DEFAULT 0,
    safety_qty REAL NOT NULL DEFAULT 0,
    max_qty REAL,
    desired_days INTEGER,                       -- autonomia desejada (dias); vazio = padrão global
    default_location_id INTEGER REFERENCES locations(id),
    shelf_life_open_days INTEGER,               -- validade após abertura (dias)
    critical INTEGER NOT NULL DEFAULT 0,        -- entra no cálculo da autonomia geral
    cons_mode TEXT NOT NULL DEFAULT 'nenhum',   -- nenhum | por_pessoa | total
    cons_qty REAL NOT NULL DEFAULT 0,
    cons_period TEXT NOT NULL DEFAULT 'dia',    -- dia | semana | mes
    cons_people INTEGER,                        -- pessoas atendidas por este produto (vazio = padrão)
    cons_rule TEXT,                             -- JSON: fases, sazonalidade mensal, reserva intocável
    photo TEXT,
    notes TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_products_barcode ON products(barcode);

CREATE TABLE IF NOT EXISTS lots (
    id INTEGER PRIMARY KEY,
    code TEXT UNIQUE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    lot_number TEXT,
    supplier TEXT,
    qty_acquired REAL NOT NULL DEFAULT 0,
    unit_price REAL NOT NULL DEFAULT 0,
    acquired_at TEXT,
    entry_at TEXT,
    stored_at TEXT,
    manufactured_at TEXT,
    expires_at TEXT,
    opened_at TEXT,
    location_id INTEGER REFERENCES locations(id),
    notes TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_lots_product ON lots(product_id);

CREATE TABLE IF NOT EXISTS containers (
    id INTEGER PRIMARY KEY,
    code TEXT UNIQUE,
    lot_id INTEGER NOT NULL REFERENCES lots(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    label TEXT,
    capacity REAL,
    initial_qty REAL NOT NULL DEFAULT 0,
    stored_at TEXT,
    opened_at TEXT,
    expires_at TEXT,
    location_id INTEGER REFERENCES locations(id),
    notes TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_containers_lot ON containers(lot_id);

CREATE TABLE IF NOT EXISTS movements (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    type TEXT NOT NULL,
    product_id INTEGER NOT NULL REFERENCES products(id),
    lot_id INTEGER REFERENCES lots(id),
    container_id INTEGER REFERENCES containers(id),
    qty REAL NOT NULL DEFAULT 0,            -- variação do saldo do lote (com sinal)
    container_qty REAL NOT NULL DEFAULT 0,  -- variação do saldo do recipiente (com sinal)
    from_location_id INTEGER REFERENCES locations(id),
    to_location_id INTEGER REFERENCES locations(id),
    unit_price REAL,
    reason TEXT,
    responsible TEXT NOT NULL,
    ref_movement_id INTEGER REFERENCES movements(id),
    batch_id TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_mov_product ON movements(product_id, ts);
CREATE INDEX IF NOT EXISTS ix_mov_lot ON movements(lot_id);
CREATE INDEX IF NOT EXISTS ix_mov_container ON movements(container_id);
CREATE INDEX IF NOT EXISTS ix_mov_ts ON movements(ts);
CREATE INDEX IF NOT EXISTS ix_mov_ref ON movements(ref_movement_id);

CREATE TRIGGER IF NOT EXISTS movements_no_update BEFORE UPDATE ON movements
BEGIN SELECT RAISE(ABORT, 'Movimentações não podem ser alteradas (histórico protegido). Use estorno.'); END;
CREATE TRIGGER IF NOT EXISTS movements_no_delete BEFORE DELETE ON movements
BEGIN SELECT RAISE(ABORT, 'Movimentações não podem ser apagadas (histórico protegido). Use estorno.'); END;

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_id INTEGER,
    action TEXT NOT NULL,
    responsible TEXT,
    before_json TEXT,
    after_json TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_entity ON audit_log(entity, entity_id);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'Auditoria é somente inclusão.'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'Auditoria é somente inclusão.'); END;

CREATE TABLE IF NOT EXISTS scenarios (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    people INTEGER NOT NULL,
    reductions TEXT,                        -- JSON {grupo: percentual}
    notes TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS backups (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,                     -- manual, automatico, pre-restauracao, encerramento, pendrive
    path TEXT NOT NULL,
    sha256 TEXT,
    size INTEGER,
    verified INTEGER NOT NULL DEFAULT 0,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    responsible TEXT NOT NULL,
    items_checked INTEGER NOT NULL DEFAULT 0,
    adjustments INTEGER NOT NULL DEFAULT 0,
    notes TEXT
);

-- Saldos derivados exclusivamente do livro-razão de movimentações
CREATE VIEW IF NOT EXISTS v_lot_stock AS
SELECT l.id AS lot_id, l.product_id, COALESCE(SUM(m.qty), 0) AS qty
FROM lots l LEFT JOIN movements m ON m.lot_id = l.id
GROUP BY l.id;

CREATE VIEW IF NOT EXISTS v_container_stock AS
SELECT c.id AS container_id, c.lot_id, c.product_id, COALESCE(SUM(m.container_qty), 0) AS qty
FROM containers c LEFT JOIN movements m ON m.container_id = c.id
GROUP BY c.id;
"""

DEFAULT_SETTINGS = {
    "schema_version": str(SCHEMA_VERSION),
    "household_name": "Minha residência",
    "people": "18",
    "people_scenarios": "10,15,18",
    "responsible_default": "",
    "alert_days": "7,15,30,60,90",
    "target_days": "90",
    "emergency_target_days": "90",
    "horizons": "30,60,90,180",
    "forecast_basis": "planejado",          # planejado | observado | maior
    "observed_window_days": "90",
    "auto_backup_hours": "6",
    "auto_backup_keep": "30",
    "review_interval_days": "30",
    "currency": "R$",
    "label_size": "62x40",
    "session_timeout_min": "30",
}

DEFAULT_UNITS = [
    ("un", "unidade", "contagem"), ("L", "litro", "volume"), ("mL", "mililitro", "volume"),
    ("kg", "quilograma", "massa"), ("g", "grama", "massa"), ("cx", "caixa", "contagem"),
    ("pct", "pacote", "contagem"), ("gf", "garrafa", "contagem"), ("sc", "saco", "contagem"),
    ("lt", "lata", "contagem"), ("cp", "comprimido", "contagem"), ("fr", "frasco", "contagem"),
    ("rl", "rolo", "contagem"), ("par", "par", "contagem"), ("dz", "dúzia", "contagem"),
    ("m", "metro", "comprimento"),
]

# (nome, grupo, essencial, prioridade, [subcategorias])
DEFAULT_CATEGORIES = [
    ("Água", "agua", 1, 1, ["Água potável", "Água para uso geral"]),
    ("Alimentos", "alimentos", 1, 2, ["Grãos e cereais", "Enlatados e conservas", "Massas", "Óleos e gorduras",
                                      "Açúcar e sal", "Proteínas", "Laticínios", "Bebidas", "Temperos"]),
    ("Medicamentos", "medicamentos", 1, 3, ["Uso contínuo", "Analgésicos e antitérmicos", "Primeiros socorros"]),
    ("Higiene", "higiene", 1, 4, ["Higiene pessoal", "Higiene bucal", "Papel higiênico", "Fraldas e absorventes"]),
    ("Limpeza", "limpeza", 0, 5, ["Desinfetantes", "Sabão e detergente", "Água sanitária"]),
    ("Insumos agrícolas", "agricola", 0, 6, ["Sementes", "Adubos", "Ração animal", "Defensivos"]),
    ("Energia e iluminação", "outros", 0, 7, ["Pilhas e baterias", "Combustível", "Velas e fósforos"]),
    ("Ferramentas e utilidades", "outros", 0, 8, []),
]

DEFAULT_LOCATIONS = [
    ("Despensa", "despensa", None), ("Cozinha", "cozinha", None), ("Depósito", "deposito", None),
    ("Cisterna", "cisterna", None), ("Galpão", "galpao", None),
]

_local = threading.local()


def now_ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today():
    return datetime.now().strftime("%Y-%m-%d")


def dict_factory(cursor, row):
    return {col[0]: row[i] for i, col in enumerate(cursor.description)}


def connect(path):
    conn = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)
    conn.row_factory = dict_factory
    conn.execute("PRAGMA foreign_keys=ON")
    # No navegador (iPad/Pyodide) o arquivo vive num sistema de arquivos virtual persistido no IndexedDB:
    # o diário clássico (DELETE) é o modo seguro ali. No Windows, WAL.
    conn.execute("PRAGMA journal_mode=%s" % ("DELETE" if sys.platform == "emscripten" else "WAL"))
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def initialize(conn, seed=True):
    conn.executescript(SCHEMA)
    from . import auth
    auth.ensure_schema(conn)
    existing = {r["key"] for r in conn.execute("SELECT key FROM settings")}
    ts = now_ts()
    with Tx(conn):
        for k, v in DEFAULT_SETTINGS.items():
            if k not in existing:
                conn.execute("INSERT INTO settings(key, value) VALUES (?, ?)", (k, v))
        if seed and conn.execute("SELECT COUNT(*) AS n FROM units").fetchone()["n"] == 0:
            for code, name, kind in DEFAULT_UNITS:
                conn.execute("INSERT INTO units(code, name, kind) VALUES (?,?,?)", (code, name, kind))
        if seed and conn.execute("SELECT COUNT(*) AS n FROM categories").fetchone()["n"] == 0:
            for name, grupo, ess, prio, subs in DEFAULT_CATEGORIES:
                cid = conn.execute(
                    "INSERT INTO categories(name, grupo, essential, priority, created_at) VALUES (?,?,?,?,?)",
                    (name, grupo, ess, prio, ts)).lastrowid
                for s in subs:
                    conn.execute(
                        "INSERT INTO categories(name, parent_id, grupo, essential, priority, created_at) VALUES (?,?,?,?,?,?)",
                        (s, cid, grupo, ess, prio, ts))
        if seed and conn.execute("SELECT COUNT(*) AS n FROM locations").fetchone()["n"] == 0:
            for i, (name, typ, _parent) in enumerate(DEFAULT_LOCATIONS, start=1):
                conn.execute("INSERT INTO locations(code, name, type, created_at) VALUES (?,?,?,?)",
                             ("LOC-%03d" % i, name, typ, ts))
        if seed and conn.execute("SELECT COUNT(*) AS n FROM scenarios").fetchone()["n"] == 0:
            for p in (10, 15, 18):
                conn.execute("INSERT INTO scenarios(name, people, reductions, created_at) VALUES (?,?,?,?)",
                             ("%d pessoas" % p, p, "{}", ts))


class Tx:
    """Transação explícita (BEGIN IMMEDIATE ... COMMIT / ROLLBACK). Aninhável."""

    def __init__(self, conn):
        self.conn = conn
        self.outer = False

    def __enter__(self):
        if not self.conn.in_transaction:
            self.conn.execute("BEGIN IMMEDIATE")
            self.outer = True
        return self.conn

    def __exit__(self, exc_type, exc, tb):
        if self.outer:
            if exc_type is None:
                self.conn.execute("COMMIT")
            else:
                self.conn.execute("ROLLBACK")
        return False


def integrity_report(conn):
    """Verificação completa: estrutura do SQLite + consistência do livro-razão."""
    issues = []
    ic = [r["integrity_check"] for r in conn.execute("PRAGMA integrity_check")]
    sqlite_ok = ic == ["ok"]
    if not sqlite_ok:
        issues.extend("SQLite: " + x for x in ic[:20])
    fk = conn.execute("PRAGMA foreign_key_check").fetchall()
    for r in fk[:20]:
        issues.append("Chave estrangeira inválida em %s (linha %s)" % (r.get("table"), r.get("rowid")))
    for r in conn.execute("""SELECT l.code, p.name, s.qty FROM v_lot_stock s JOIN lots l ON l.id=s.lot_id
                             JOIN products p ON p.id=l.product_id WHERE s.qty < -1e-9"""):
        issues.append("Saldo negativo no lote %s (%s): %s" % (r["code"], r["name"], r["qty"]))
    for r in conn.execute("""SELECT c.code, s.qty FROM v_container_stock s JOIN containers c ON c.id=s.container_id
                             WHERE s.qty < -1e-9"""):
        issues.append("Saldo negativo no recipiente %s: %s" % (r["code"], r["qty"]))
    for r in conn.execute("""SELECT l.code, ls.qty AS lq, COALESCE(SUM(cs.qty),0) AS cq
                             FROM lots l JOIN v_lot_stock ls ON ls.lot_id=l.id
                             LEFT JOIN v_container_stock cs ON cs.lot_id=l.id
                             GROUP BY l.id HAVING cq - lq > 1e-6"""):
        issues.append("Recipientes do lote %s somam %s, acima do saldo do lote (%s)" % (r["code"], r["cq"], r["lq"]))
    for r in conn.execute("""SELECT m.id FROM movements m LEFT JOIN lots l ON l.id=m.lot_id
                             WHERE m.lot_id IS NOT NULL AND l.product_id <> m.product_id"""):
        issues.append("Movimentação %s aponta para lote de outro produto" % r["id"])
    trig = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
    for t in ("movements_no_update", "movements_no_delete", "audit_no_update", "audit_no_delete"):
        if t not in trig:
            issues.append("Proteção do histórico ausente: gatilho %s" % t)
    counts = {t: conn.execute("SELECT COUNT(*) AS n FROM %s" % t).fetchone()["n"]
              for t in ("products", "lots", "containers", "movements", "locations", "categories")}
    return {"ok": not issues, "sqlite_ok": sqlite_ok, "issues": issues, "counts": counts,
            "journal_mode": conn.execute("PRAGMA journal_mode").fetchone()["journal_mode"]}


def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p

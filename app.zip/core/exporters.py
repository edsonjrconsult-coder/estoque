"""Exportação local para CSV, Excel (.xlsx) e PDF — sem bibliotecas externas."""
import csv
import io
import zipfile
from datetime import datetime
from xml.sax.saxutils import escape

from . import codes

# ---------------------------------------------------------------- formatação


def fmt_num(v, dec=2):
    if v is None or v == "":
        return ""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    s = ("{:,.%df}" % dec).format(v)
    s = s.replace(",", "X").replace(".", ",").replace("X", ".")
    if "," in s:
        s = s.rstrip("0").rstrip(",")
    return s


def fmt_money(v):
    if v in (None, ""):
        return ""
    return "R$ " + "{:,.2f}".format(float(v)).replace(",", "X").replace(".", ",").replace("X", ".")


def fmt_date(v):
    if not v:
        return ""
    s = str(v)
    if len(s) >= 10 and s[4] == "-":
        out = "%s/%s/%s" % (s[8:10], s[5:7], s[0:4])
        if len(s) >= 16:
            out += " " + s[11:16]
        return out
    return s


def cell_text(col, row):
    v = row.get(col["key"]) if isinstance(row, dict) else None
    f = col.get("fmt")
    if callable(f):
        return f(v, row)
    if f == "date":
        return fmt_date(v)
    if f == "num":
        return fmt_num(v, col.get("dec", 2))
    if f == "money":
        return fmt_money(v)
    if f == "days":
        if v is None:
            return "—"
        if row.get(col.get("capped_key", "autonomy_capped")):
            return "> 10 anos"
        return fmt_num(v, 1)
    return "" if v is None else str(v)


def cell_raw(col, row):
    v = row.get(col["key"]) if isinstance(row, dict) else None
    f = col.get("fmt")
    if callable(f) and getattr(f, "numeric", False):
        if v in (None, ""):
            return None
        if getattr(f, "capped_key", None) and row.get(f.capped_key):
            return "> 10 anos"
        try:
            return float(v)
        except (TypeError, ValueError):
            return v
    if callable(f):
        return f(v, row)
    if f in ("num", "money", "days") and v not in (None, ""):
        try:
            return float(v)
        except (TypeError, ValueError):
            return v
    if f == "date":
        return fmt_date(v)
    return v


# ---------------------------------------------------------------- CSV


def data_columns(columns):
    """Para planilhas: quantidades viram número puro e a unidade ganha coluna própria."""
    out = []
    added = False
    for c in columns:
        if c["key"] == "_blank":
            continue
        out.append(c)
        f = c.get("fmt")
        if callable(f) and getattr(f, "has_unit", False) and not added:
            out.append({"label": "Unidade", "key": "unit"})
            added = True
    return out


def to_csv(columns, rows):
    columns = data_columns(columns)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", quoting=csv.QUOTE_MINIMAL, lineterminator="\r\n")
    w.writerow([c["label"] for c in columns])
    for r in rows:
        out = []
        for c in columns:
            v = cell_raw(c, r)
            if isinstance(v, float):
                v = ("%.6f" % v).rstrip("0").rstrip(".").replace(".", ",")
            out.append("" if v is None else v)
        w.writerow(out)
    return ("﻿" + buf.getvalue()).encode("utf-8")


# ---------------------------------------------------------------- XLSX (Office Open XML mínimo)


def _col_letter(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def to_xlsx(sheets):
    """sheets: lista de (nome, título, columns, rows)."""
    out = io.BytesIO()
    z = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
    n = len(sheets)
    z.writestr("[Content_Types].xml",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
               '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
               '<Default Extension="xml" ContentType="application/xml"/>'
               '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
               '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
               + "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n))
               + '</Types>')
    z.writestr("_rels/.rels",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
               '</Relationships>')
    used = set()
    names = []
    for s in sheets:
        nm = "".join(ch for ch in s[0] if ch not in '[]:*?/\\')[:31] or "Planilha"
        base, k = nm, 2
        while nm in used:
            nm = (base[:28] + " %d" % k)
            k += 1
        used.add(nm)
        names.append(nm)
    z.writestr("xl/workbook.xml",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
               'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
               + "".join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(nm, {'"': "&quot;"}), i + 1, i + 1) for i, nm in enumerate(names))
               + '</sheets></workbook>')
    z.writestr("xl/_rels/workbook.xml.rels",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               + "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n))
               + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (n + 1)
               + '</Relationships>')
    z.writestr("xl/styles.xml",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
               '<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>'
               '<fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
               '<font><b/><sz val="14"/><name val="Calibri"/></font></fonts>'
               '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
               '<fill><patternFill patternType="solid"><fgColor rgb="FF1F3A4D"/><bgColor indexed="64"/></patternFill></fill></fills>'
               '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
               '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
               '<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
               '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
               '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
               '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
               '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
               '</styleSheet>')
    for si, (nm, title, columns, rows) in enumerate(sheets):
        columns = data_columns(columns)
        xml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">']
        hdr_row = 3 if title else 1
        xml.append('<sheetViews><sheetView workbookViewId="0"><pane ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' % (hdr_row, hdr_row + 1))
        xml.append("<cols>")
        for i, c in enumerate(columns):
            xml.append('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (i + 1, i + 1, max(8, min(60, int(c.get("w", 1) * 12)))))
        xml.append("</cols><sheetData>")

        def scell(ref, text, style=0):
            return '<c r="%s" t="inlineStr"%s><is><t xml:space="preserve">%s</t></is></c>' % (
                ref, ' s="%d"' % style if style else "", escape(_clean(str(text))))
        if title:
            xml.append('<row r="1">%s</row>' % scell("A1", title, 3))
        xml.append('<row r="%d">%s</row>' % (hdr_row, "".join(scell("%s%d" % (_col_letter(i), hdr_row), c["label"], 1) for i, c in enumerate(columns))))
        for ri, r in enumerate(rows):
            rn = hdr_row + 1 + ri
            cells = []
            for i, c in enumerate(columns):
                v = cell_raw(c, r)
                ref = "%s%d" % (_col_letter(i), rn)
                if isinstance(v, bool):
                    cells.append(scell(ref, "Sim" if v else "Não"))
                elif isinstance(v, (int, float)):
                    cells.append('<c r="%s" s="2"><v>%r</v></c>' % (ref, float(v)))
                elif v is None or v == "":
                    continue
                else:
                    cells.append(scell(ref, v))
            xml.append('<row r="%d">%s</row>' % (rn, "".join(cells)))
        xml.append("</sheetData>")
        if columns:
            xml.append('<autoFilter ref="A%d:%s%d"/>' % (hdr_row, _col_letter(len(columns) - 1), hdr_row + max(len(rows), 1)))
        xml.append("</worksheet>")
        z.writestr("xl/worksheets/sheet%d.xml" % (si + 1), "".join(xml))
    z.close()
    return out.getvalue()


def _clean(s):
    return "".join(ch for ch in s if ch in "\t\n\r" or ord(ch) >= 32)


# ---------------------------------------------------------------- PDF (gerador próprio, fontes padrão)

_HELV = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556,
         556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
         667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556,
         556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584]
_ACCENT_BASE = str.maketrans("áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑ", "aaaaaeeeeiiiiooooouuuucnAAAAAEEEEIIIIOOOOOUUUUCN")
_SUBST = {"—": "-", "–": "-", "›": ">", "…": "...", "“": '"', "”": '"', "‘": "'", "’": "'", "•": "-", "≥": ">=", "≤": "<=", "✓": "v", "×": "x"}


def _pdf_safe(s):
    s = "".join(_SUBST.get(ch, ch) for ch in str(s))
    return s.encode("cp1252", "replace").decode("cp1252")


def text_width(s, size, bold=False):
    w = 0
    for ch in _pdf_safe(s).translate(_ACCENT_BASE):
        o = ord(ch)
        w += _HELV[o - 32] if 32 <= o <= 126 else 556
    return w * size / 1000.0 * (1.06 if bold else 1.0)


def wrap(s, width, size, bold=False):
    s = "" if s is None else str(s)
    lines = []
    for para in s.split("\n"):
        words = para.split(" ")
        cur = ""
        for wd in words:
            cand = (cur + " " + wd) if cur else wd
            if text_width(cand, size, bold) <= width:
                cur = cand
            else:
                if cur:
                    lines.append(cur)
                while text_width(wd, size, bold) > width and len(wd) > 1:
                    k = len(wd)
                    while k > 1 and text_width(wd[:k], size, bold) > width:
                        k -= 1
                    lines.append(wd[:k])
                    wd = wd[k:]
                cur = wd
        lines.append(cur)
    return lines or [""]


class PDF:
    def __init__(self, landscape=False, page=(595.28, 841.89)):
        w, h = page
        self.w, self.h = (h, w) if landscape else (w, h)
        self.pages = []
        self.cur = None
        self.margin = 36

    def add_page(self):
        self.cur = []
        self.pages.append(self.cur)

    def _esc(self, s):
        b = _pdf_safe(s).encode("cp1252", "replace")
        return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")

    def text(self, x, y, s, size=10, bold=False, color=(0, 0, 0)):
        self.cur.append(b"BT %.3f %.3f %.3f rg /%s %.2f Tf %.2f %.2f Td (" % (color[0], color[1], color[2], b"F2" if bold else b"F1", size, x, self.h - y)
                        + self._esc(s) + b") Tj ET")

    def rect(self, x, y, w, h, fill=None, stroke=None, lw=0.5):
        ops = []
        if fill is not None:
            ops.append(b"%.3f %.3f %.3f rg" % fill)
        if stroke is not None:
            ops.append(b"%.3f %.3f %.3f RG %.2f w" % (stroke + (lw,)))
        op = b"B" if fill is not None and stroke is not None else (b"f" if fill is not None else b"S")
        ops.append(b"%.2f %.2f %.2f %.2f re %s" % (x, self.h - y - h, w, h, op))
        self.cur.append(b" ".join(ops))

    def line(self, x1, y1, x2, y2, lw=0.5, color=(0.6, 0.6, 0.6)):
        self.cur.append(b"%.3f %.3f %.3f RG %.2f w %.2f %.2f m %.2f %.2f l S" % (color + (lw, x1, self.h - y1, x2, self.h - y2)))

    def qr(self, x, y, size, text):
        m = codes.qr_matrix(text)
        n = len(m) + 4
        cell = size / n
        ops = [b"0 0 0 rg"]
        for r, row in enumerate(m):
            c = 0
            while c < len(row):
                if row[c]:
                    s = c
                    while c < len(row) and row[c]:
                        c += 1
                    ops.append(b"%.3f %.3f %.3f %.3f re" % (x + (s + 2) * cell, self.h - (y + (r + 3) * cell), (c - s) * cell + 0.01, cell + 0.01))
                else:
                    c += 1
        ops.append(b"f")
        self.cur.append(b"\n".join(ops))

    def barcode(self, x, y, w, h, text):
        mods = codes.code128_modules(text)
        mw = w / len(mods)
        ops = [b"0 0 0 rg"]
        i = 0
        while i < len(mods):
            if mods[i] == "1":
                s = i
                while i < len(mods) and mods[i] == "1":
                    i += 1
                ops.append(b"%.3f %.3f %.3f %.3f re" % (x + s * mw, self.h - y - h, (i - s) * mw, h))
            else:
                i += 1
        ops.append(b"f")
        self.cur.append(b"\n".join(ops))

    def output(self, title="Estoque Autônomo"):
        objs = []

        def add(b):
            objs.append(b)
            return len(objs)
        f1 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        f2 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        pages_id = len(objs) + 1 + 2 * len(self.pages)
        kids = []
        for p in self.pages:
            content = b"\n".join(p)
            cid = add(b"<< /Length %d >>\nstream\n" % len(content) + content + b"\nendstream")
            pid = add(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> /Contents %d 0 R >>"
                      % (pages_id, self.w, self.h, f1, f2, cid))
            kids.append(pid)
        add(b"<< /Type /Pages /Kids [%s] /Count %d >>" % (b" ".join(b"%d 0 R" % k for k in kids), len(kids)))
        info = add(b"<< /Title (" + self._esc(title) + b") /Producer (Estoque Autonomo) /CreationDate (D:" +
                   datetime.now().strftime("%Y%m%d%H%M%S").encode() + b") >>")
        cat = add(b"<< /Type /Catalog /Pages %d 0 R >>" % pages_id)
        out = io.BytesIO()
        out.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offs = []
        for i, o in enumerate(objs, start=1):
            offs.append(out.tell())
            out.write(b"%d 0 obj\n" % i + o + b"\nendobj\n")
        xref = out.tell()
        out.write(b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1))
        for o in offs:
            out.write(b"%010d 00000 n \n" % o)
        out.write(b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, cat, info, xref))
        return out.getvalue()


def table_pdf(title, subtitle, sections, landscape=True, footer=None):
    """sections: lista de (titulo_secao, columns, rows). Colunas com 'w' (peso) e 'align'."""
    pdf = PDF(landscape=landscape)
    m = pdf.margin
    usable = pdf.w - 2 * m
    state = {"y": 0, "page": 0}
    gen = datetime.now().strftime("%d/%m/%Y %H:%M")

    def new_page():
        pdf.add_page()
        state["page"] += 1
        pdf.text(m, m + 4, title, 15, True, (0.12, 0.23, 0.30))
        y = m + 20
        if subtitle:
            for ln in wrap(subtitle, usable, 8.5):
                pdf.text(m, y, ln, 8.5, False, (0.3, 0.3, 0.3))
                y += 11
        pdf.line(m, y, pdf.w - m, y, 1, (0.12, 0.23, 0.30))
        pdf.text(m, pdf.h - 18, "%sGerado em %s  -  página %d" % ((footer + "  -  ") if footer else "", gen, state["page"]), 7.5, False, (0.4, 0.4, 0.4))
        state["y"] = y + 10

    new_page()
    for sec_title, columns, rows in sections:
        tw = sum(c.get("w", 1) for c in columns) or 1
        widths = [usable * c.get("w", 1) / tw for c in columns]
        fs = 8 if landscape else 7.5

        def header():
            y = state["y"]
            hh = max(len(wrap(c["label"], widths[i] - 4, fs, True)) for i, c in enumerate(columns)) * (fs + 2) + 4
            pdf.rect(m, y, usable, hh, fill=(0.12, 0.23, 0.30))
            x = m
            for i, c in enumerate(columns):
                for k, ln in enumerate(wrap(c["label"], widths[i] - 4, fs, True)):
                    pdf.text(x + 2, y + fs + 2 + k * (fs + 2), ln, fs, True, (1, 1, 1))
                x += widths[i]
            state["y"] = y + hh
        if sec_title:
            if state["y"] > pdf.h - m - 60:
                new_page()
            pdf.text(m, state["y"] + 10, sec_title, 11, True, (0.12, 0.23, 0.30))
            state["y"] += 16
        if state["y"] > pdf.h - m - 40:
            new_page()
        header()
        if not rows:
            pdf.text(m + 2, state["y"] + fs + 4, "Nenhum registro.", fs, False, (0.4, 0.4, 0.4))
            state["y"] += fs + 10
        for ri, r in enumerate(rows):
            cells = [wrap(cell_text(c, r), widths[i] - 4, fs, bool(c.get("bold"))) for i, c in enumerate(columns)]
            rh = max(len(x) for x in cells) * (fs + 2) + 4
            if state["y"] + rh > pdf.h - m - 10:
                new_page()
                if sec_title:
                    pdf.text(m, state["y"] + 6, sec_title + " (continuação)", 9, True, (0.12, 0.23, 0.30))
                    state["y"] += 12
                header()
            y = state["y"]
            if ri % 2 == 1:
                pdf.rect(m, y, usable, rh, fill=(0.95, 0.96, 0.97))
            hl = r.get("_highlight") if isinstance(r, dict) else None
            if hl:
                pdf.rect(m, y, 3, rh, fill=hl)
            x = m
            for i, c in enumerate(columns):
                for k, ln in enumerate(cells[i]):
                    tx = x + 2
                    if c.get("align") == "right":
                        tx = x + widths[i] - 2 - text_width(ln, fs, bool(c.get("bold")))
                    pdf.text(tx, y + fs + 2 + k * (fs + 2), ln, fs, bool(c.get("bold")))
                x += widths[i]
            pdf.line(m, y + rh, pdf.w - m, y + rh, 0.3, (0.82, 0.84, 0.86))
            state["y"] = y + rh
        state["y"] += 12
    return pdf.output(title)


LABEL_FORMATS = {
    # nome: (largura_mm, altura_mm, colunas, linhas, margem_sup_mm, margem_esq_mm, espaço_h_mm, espaço_v_mm, página)
    "a4_3x8": (70, 37, 3, 8, 0.5, 0, 0, 0, "A4"),
    "a4_2x7": (99.1, 38.1, 2, 7, 15.1, 4.65, 2.5, 0, "A4"),
    "a4_4x10": (48.5, 25.4, 4, 10, 21.5, 8, 0, 0, "A4"),
    "62x40": (62, 40, 1, 1, 0, 0, 0, 0, "label"),
    "50x30": (50, 30, 1, 1, 0, 0, 0, 0, "label"),
    "100x50": (100, 50, 1, 1, 0, 0, 0, 0, "label"),
}
MM = 72 / 25.4


def labels_pdf(labels, fmt="a4_3x8", copies=1, skip=0):
    """labels: lista de dicts {code, title, line1, line2, line3}."""
    w_mm, h_mm, cols, rows, top, left, gx, gy, page = LABEL_FORMATS.get(fmt, LABEL_FORMATS["a4_3x8"])
    if page == "A4":
        pdf = PDF(page=(595.28, 841.89))
    else:
        pdf = PDF(page=(w_mm * MM, h_mm * MM))
    per_page = cols * rows
    seq = [None] * skip + [l for l in labels for _ in range(max(1, copies))]
    for idx, lab in enumerate(seq):
        pos = idx % per_page
        if pos == 0:
            pdf.add_page()
        if lab is None:
            continue
        c, r = pos % cols, pos // cols
        x = (left + c * (w_mm + gx)) * MM
        y = (top + r * (h_mm + gy)) * MM
        W, H = w_mm * MM, h_mm * MM
        pad = 2.2 * MM
        qs = min(H - 2 * pad, W * 0.42)
        pdf.qr(x + pad - 1, y + (H - qs) / 2 - 1, qs, codes.payload(lab["code"]))
        tx = x + pad + qs + 1.5 * MM
        tw = W - (tx - x) - pad
        ty = y + pad + 7
        fs = 8.5 if H > 30 * MM else 7
        for ln in wrap(lab.get("title") or "", tw, fs, True)[:2]:
            pdf.text(tx, ty, ln, fs, True)
            ty += fs + 1.5
        for key in ("line1", "line2", "line3"):
            if lab.get(key):
                for ln in wrap(lab[key], tw, fs - 1.5)[:1]:
                    pdf.text(tx, ty, ln, fs - 1.5)
                    ty += fs - 0.5
        bh = max(5, min(H * 0.18, y + H - pad - ty - 9))
        if bh >= 5 and tw > 25 * MM:
            pdf.barcode(tx, y + H - pad - bh - 7, tw, bh, codes.payload(lab["code"]))
        pdf.text(tx, y + H - pad - 1, codes.payload(lab["code"]), 7, True)
    if not pdf.pages:
        pdf.add_page()
    return pdf.output("Etiquetas")

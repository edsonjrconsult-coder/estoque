"""Definição dos relatórios (mesma fonte para tela, impressão, PDF, CSV e Excel)."""
from datetime import date
from html import escape

from . import services as s
from .exporters import cell_text, fmt_date, fmt_num

STATUS_LABEL = {"vencido": "VENCIDO", "sem_validade": "sem validade", "ok": "ok"}
RED, ORANGE, YELLOW, GREEN = (0.78, 0.16, 0.16), (0.90, 0.45, 0.05), (0.85, 0.70, 0.05), (0.18, 0.55, 0.30)


def status_label(st, days=None):
    if st and st.startswith("vence_"):
        return "vence em %s dia(s)" % days if days is not None else "vence em até %s dias" % st[6:]
    return STATUS_LABEL.get(st, st or "")


def days_fmt(v, row):
    if v is None:
        return "sem consumo"
    if row.get("autonomy_capped"):
        return "> 10 anos"
    return fmt_num(v, 1)


days_fmt.numeric = True
days_fmt.capped_key = "autonomy_capped"


def qty_unit(key):
    f = lambda v, r: "%s %s" % (fmt_num(r.get(key), 3), r.get("unit") or "")  # noqa: E731
    f.numeric = True
    f.has_unit = True
    return f


def _hl_expiry(st):
    if st == "vencido":
        return RED
    if st and st.startswith("vence_"):
        d = int(st[6:])
        return ORANGE if d <= 15 else YELLOW if d <= 30 else None
    return None


def _filters_text(f, conn):
    parts = []
    if f.get("category_id"):
        r = conn.execute("SELECT name FROM categories WHERE id=?", (int(f["category_id"]),)).fetchone()
        if r:
            parts.append("Categoria: " + r["name"])
    if f.get("product_id"):
        r = conn.execute("SELECT name FROM products WHERE id=?", (int(f["product_id"]),)).fetchone()
        if r:
            parts.append("Produto: " + r["name"])
    if f.get("location_id"):
        parts.append("Local: " + s.location_map(conn).get(int(f["location_id"]), ""))
    if f.get("lot"):
        parts.append("Lote: " + f["lot"])
    if f.get("within_days"):
        parts.append("Validade em até %s dias" % f["within_days"])
    if f.get("date_from") or f.get("date_to"):
        parts.append("Período: %s a %s" % (fmt_date(f.get("date_from")) or "início", fmt_date(f.get("date_to")) or "hoje"))
    if f.get("people"):
        parts.append("Pessoas: %s" % f["people"])
    if f.get("target_days"):
        parts.append("Meta: %s dias" % f["target_days"])
    return " | ".join(parts)


def build(conn, kind, f):
    f = f or {}
    st = s.settings(conn)
    house = st.get("household_name") or ""
    sub = _filters_text(f, conn)
    people = int(f["people"]) if f.get("people") else None

    if kind == "estoque":
        rows = s.list_products(conn, {"category_id": f.get("category_id"), "location_id": f.get("location_id"), "q": f.get("q")})
        if f.get("product_id"):
            rows = [r for r in rows if r["id"] == int(f["product_id"])]
        for r in rows:
            r["_highlight"] = {"vencido": RED, "baixo": ORANGE, "vencendo": YELLOW}.get(r["status"])
            r["locais"] = "; ".join(r["locations"])
            r["status_txt"] = {"adequado": "adequado", "baixo": "estoque baixo", "vencendo": "vencendo", "vencido": "tem itens vencidos"}[r["status"]]
        cols = [dict(label="Código", key="code", w=0.8), dict(label="Produto", key="name", w=2, bold=True),
                dict(label="Categoria", key="category_name", w=1.2), dict(label="Quantidade", key="qty", fmt=qty_unit("qty"), w=1, align="right"),
                dict(label="Mínimo", key="min_qty", fmt="num", w=0.7, align="right"), dict(label="Situação", key="status_txt", w=1),
                dict(label="Próx. validade", key="next_expiry", fmt="date", w=0.9), dict(label="Local", key="locais", w=1.8),
                dict(label="Autonomia (dias)", key="autonomy_days", fmt=days_fmt, w=0.9, align="right"),
                dict(label="Valor", key="value", fmt="money", w=0.9, align="right")]
        return dict(title="Posição do estoque", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    if kind == "lotes":
        rows = []
        for l in s.list_lots(conn, {"product_id": f.get("product_id"), "q": f.get("lot"), "include_empty": f.get("include_empty")}):
            if f.get("category_id"):
                p = conn.execute("SELECT category_id, subcategory_id FROM products WHERE id=?", (l["product_id"],)).fetchone()
                if str(f["category_id"]) not in (str(p["category_id"]), str(p["subcategory_id"])):
                    continue
            l["tipo"] = "Lote"
            l["_highlight"] = _hl_expiry(l["status"])
            l["status_txt"] = status_label(l["status"], l["days"])
            l["qty_txt"] = l["qty"]
            rows.append(l)
            for c in l["containers"]:
                rows.append(dict(c, tipo="  Recipiente", product_name=l["product_name"], unit=l["unit"], lot_number=c.get("label"),
                                 supplier="", expires_at=c["effective_expiry"], location_path=c["location_path"],
                                 status_txt=status_label(c["status"], c["days"]), _highlight=_hl_expiry(c["status"])))
        if f.get("location_id"):
            lp = s.location_map(conn).get(int(f["location_id"]), "")
            rows = [r for r in rows if (r.get("location_path") or "").startswith(lp)]
        cols = [dict(label="Tipo", key="tipo", w=0.8), dict(label="Código", key="code", w=0.8), dict(label="Produto", key="product_name", w=1.8, bold=True),
                dict(label="Nº lote / rótulo", key="lot_number", w=1), dict(label="Fornecedor", key="supplier", w=1),
                dict(label="Saldo", key="qty", fmt=qty_unit("qty"), w=0.9, align="right"),
                dict(label="Validade", key="expires_at", fmt="date", w=0.8), dict(label="Situação", key="status_txt", w=1),
                dict(label="Aberto em", key="opened_at", fmt="date", w=0.8), dict(label="Local", key="location_path", w=1.6)]
        return dict(title="Lotes e recipientes", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    if kind == "movimentacoes":
        rows = s.list_movements(conn, dict(f, limit=100000))
        for r in rows:
            r["qtd"] = r["qty"] if r["qty"] else r["container_qty"]
            r["onde"] = r["container_code"] or r["lot_code"]
            r["locais"] = " → ".join(x for x in (r["from_path"], r["to_path"]) if x)
            if r["reversed"]:
                r["reason"] = (r["reason"] or "") + " [ESTORNADA]"
        cols = [dict(label="Nº", key="id", w=0.5), dict(label="Data/hora", key="ts", fmt="date", w=1), dict(label="Tipo", key="type_label", w=1.2),
                dict(label="Produto", key="product_name", w=1.8, bold=True), dict(label="Lote/recip.", key="onde", w=0.9),
                dict(label="Quantidade", key="qtd", fmt=qty_unit("qtd"), w=0.9, align="right"), dict(label="Locais", key="locais", w=1.6),
                dict(label="Motivo", key="reason", w=2), dict(label="Responsável", key="responsible", w=1)]
        return dict(title="Movimentações de estoque", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    if kind == "validade":
        data = s.expiry_list(conn, f)
        rows = data["rows"]
        for r in rows:
            r["_highlight"] = _hl_expiry(r["status"])
            r["status_txt"] = status_label(r["status"], r["days"])
            r["fefo"] = ("%dº" % r["fefo_rank"]) if r["fefo_rank"] else "descartar"
        cols = [dict(label="Produto", key="product_name", w=1.8, bold=True), dict(label="Ordem FEFO", key="fefo", w=0.7),
                dict(label="Item", key="code", w=0.8), dict(label="Lote", key="lot_number", w=0.9),
                dict(label="Quantidade", key="qty", fmt=qty_unit("qty"), w=0.9, align="right"),
                dict(label="Validade", key="expires_at", fmt="date", w=0.8), dict(label="Dias", key="days", w=0.5, align="right"),
                dict(label="Situação", key="status_txt", w=1.1), dict(label="Local", key="location_path", w=1.6),
                dict(label="Valor", key="value", fmt="money", w=0.8, align="right")]
        return dict(title="Controle de validade (FEFO)", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    if kind == "autonomia":
        rows = s.autonomy_table(conn, people=people)
        if f.get("category_id"):
            ids = {r["id"] for r in s.list_products(conn, {"category_id": f["category_id"]})}
            rows = [r for r in rows if r["product_id"] in ids]
        hs = sorted(rows[0]["need"].keys()) if rows else [30, 60, 90, 180]
        for r in rows:
            r["_highlight"] = RED if (r["autonomy_days"] is not None and r["daily_rate"] > 0 and r["autonomy_days"] < 30) else None
            for h in hs:
                r["need_%d" % h] = r["need"].get(h)
                r["bal_%d" % h] = r["balance"].get(h)
        cols = [dict(label="Produto", key="name", w=1.8, bold=True), dict(label="Disponível", key="available", fmt=qty_unit("available"), w=0.9, align="right"),
                dict(label="Consumo/dia", key="daily_rate", fmt="num", dec=3, w=0.8, align="right"),
                dict(label="Autonomia (dias)", key="autonomy_days", fmt=days_fmt, w=0.8, align="right"),
                dict(label="Esgota em", key="depletion_date", fmt="date", w=0.8),
                dict(label="Perda p/ venc.", key="lost_by_expiry", fmt="num", w=0.7, align="right")]
        for h in hs:
            cols.append(dict(label="Saldo %dd (+/-)" % h, key="bal_%d" % h, fmt="num", w=0.8, align="right"))
        return dict(title="Consumo e autonomia", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    if kind == "compras":
        plan = s.purchase_plan(conn, f.get("target_days") or None, people=people)
        rows = plan["rows"]
        for r in rows:
            r["motivo"] = ", ".join(r["reasons"]) + (" (limitado ao máximo)" if r["capped_by_max"] else "")
        cols = [dict(label="Produto", key="name", w=1.8, bold=True), dict(label="Categoria", key="category_name", w=1),
                dict(label="Em estoque", key="available", fmt=qty_unit("available"), w=0.9, align="right"),
                dict(label="Autonomia (dias)", key="autonomy_days", fmt=days_fmt, w=0.8, align="right"),
                dict(label="Meta (dias)", key="target_days", w=0.6, align="right"),
                dict(label="Comprar", key="buy", fmt=qty_unit("buy"), w=0.9, align="right", bold=True),
                dict(label="Motivo", key="motivo", w=1.5), dict(label="Preço ref.", key="last_price", fmt="money", w=0.7, align="right"),
                dict(label="Custo estimado", key="estimated_cost", fmt="money", w=0.8, align="right"),
                dict(label="Comprado (anotar)", key="_blank", w=0.9)]
        sub2 = (sub + " | " if sub else "") + "Custo total estimado: R$ " + fmt_num(plan["total_cost"], 2)
        return dict(title="Lista de compras e reposição", subtitle=sub2, sections=[("", cols, rows)], landscape=True)

    if kind == "pessoas":
        data = s.people_comparison(conn, [int(x) for x in str(f["people_list"]).split(",")] if f.get("people_list") else None)
        ps = data["people"]
        rows = []
        for r in data["rows"]:
            row = dict(name=r["name"], unit=r["unit"], qty=r["qty"], ppd=r["per_person_day"])
            for n in ps:
                sc = r["scenarios"][n]
                row["d%d" % n] = sc["days"]
                row["c%d" % n] = sc["capped"]
                for h in data["horizons"]:
                    row["b%d_%d" % (n, h)] = sc["buy"][h]
            rows.append(row)
        cols = [dict(label="Produto", key="name", w=1.8, bold=True), dict(label="Estoque", key="qty", fmt=qty_unit("qty"), w=0.9, align="right"),
                dict(label="Por pessoa/dia", key="ppd", fmt="num", dec=3, w=0.8, align="right")]
        for n in ps:
            cols.append(dict(label="%d pessoas: dias" % n, key="d%d" % n,
                             fmt=(lambda v, r, n=n: "> 10 anos" if r.get("c%d" % n) else ("sem consumo" if v is None else fmt_num(v, 1))),
                             w=0.8, align="right"))
        cols2 = [dict(label="Produto", key="name", w=1.8, bold=True)]
        for n in ps:
            for h in (90, 180) if 90 in data["horizons"] else data["horizons"][-2:]:
                cols2.append(dict(label="Comprar %dp/%dd" % (n, h), key="b%d_%d" % (n, h), fmt="num", w=0.8, align="right"))
        return dict(title="Planejamento por pessoa — comparação de cenários", subtitle=sub,
                    sections=[("Autonomia por cenário", cols, rows), ("Quanto comprar por cenário", cols2, rows)], landscape=True)

    if kind == "emergencia":
        return emergency_inventory(conn, f, house)

    if kind == "mapa":
        mp = s.storage_map(conn)
        rows = []

        def walk(nodes, depth):
            for n in nodes:
                rows.append({"local": ("    " * depth) + n["name"], "tipo": n["type"], "product_name": "", "_highlight": (0.12, 0.23, 0.30),
                             "code": n["code"], "qty": None})
                for it in n["items"]:
                    rows.append({"local": "", "product_name": it["product_name"], "code": it["code"], "qty": it["qty"], "unit": it["unit"],
                                 "expires_at": it["expires_at"], "status_txt": status_label(it["status"], it["days"]),
                                 "_highlight": _hl_expiry(it["status"])})
                walk(n["children"], depth + 1)
        walk(mp["tree"], 0)
        for it in mp["unplaced"]:
            rows.append({"local": "(sem local)", "product_name": it["product_name"], "code": it["code"], "qty": it["qty"], "unit": it["unit"],
                         "expires_at": it["expires_at"], "status_txt": status_label(it["status"], it["days"])})
        cols = [dict(label="Local", key="local", w=1.6, bold=True), dict(label="Produto", key="product_name", w=1.8),
                dict(label="Item", key="code", w=0.8), dict(label="Quantidade", key="qty", fmt=lambda v, r: "" if v is None else "%s %s" % (fmt_num(v, 3), r.get("unit") or ""), w=0.9, align="right"),
                dict(label="Validade", key="expires_at", fmt="date", w=0.8), dict(label="Situação", key="status_txt", w=1)]
        return dict(title="Mapa de armazenamento", subtitle=house, sections=[("", cols, rows)], landscape=False)

    if kind == "revisao":
        data = s.review_sheet(conn)
        rows = data["rows"]
        for r in rows:
            r["status_txt"] = status_label(r["status"], r["days"])
            r["_highlight"] = _hl_expiry(r["status"])
        cols = [dict(label="Local", key="location_path", w=1.5), dict(label="Produto", key="product_name", w=1.8, bold=True),
                dict(label="Item", key="code", w=0.8), dict(label="Sistema", key="qty", fmt=qty_unit("qty"), w=0.9, align="right"),
                dict(label="Validade", key="expires_at", fmt="date", w=0.8), dict(label="Situação", key="status_txt", w=1),
                dict(label="Contado", key="_blank", w=0.8), dict(label="Obs.", key="_blank", w=1.2)]
        return dict(title="Folha de revisão periódica (contagem física)", subtitle=house + " — conferir quantidades e validades e anotar a contagem",
                    sections=[("", cols, rows)], landscape=True)

    if kind == "auditoria":
        rows = s.audit_list(conn, 5000)
        cols = [dict(label="Data/hora", key="ts", fmt="date", w=1), dict(label="Entidade", key="entity", w=0.8), dict(label="ID", key="entity_id", w=0.4),
                dict(label="Ação", key="action", w=0.8), dict(label="Responsável", key="responsible", w=0.9),
                dict(label="Antes", key="before_json", w=2.5), dict(label="Depois", key="after_json", w=2.5)]
        return dict(title="Trilha de auditoria", subtitle=sub, sections=[("", cols, rows)], landscape=True)

    raise s.BusinessError("Relatório desconhecido: %s" % kind)


def emergency_inventory(conn, f, house):
    red = {}
    for k, v in (f or {}).items():
        if k.startswith("red_") and v not in (None, ""):
            red[k[4:]] = float(v) / 100.0
    data = s.emergency(conn, red, float(f.get("global_reduction") or 0) / 100.0, f.get("target_days") or None,
                       int(f["people"]) if f.get("people") else None)
    g_rows = []
    for g in data["groups"]:
        g_rows.append({"label": g["label"], "products": g["products"], "min_days": g["min_days"], "limiting": g["limiting"] or "—",
                       "cov": " / ".join("%dd: %s" % (h, ("—" if g["coverage"][h] is None else "%d%%" % round(100 * g["coverage"][h]))) for h in data["horizons"]),
                       "_highlight": RED if (g["min_days"] is not None and g["min_days"] < 30) else None})
    gcols = [dict(label="Categoria", key="label", w=1.2, bold=True), dict(label="Produtos", key="products", w=0.5, align="right"),
             dict(label="Autonomia (item limitante, dias)", key="min_days", fmt=lambda v, r: "—" if v is None else fmt_num(v, 1), w=0.9, align="right"),
             dict(label="Item limitante", key="limiting", w=1.4), dict(label="Cobertura 30/60/90/180 dias", key="cov", w=2)]
    sections = [("Resumo por categoria", gcols, g_rows)]
    cols = [dict(label="Produto", key="name", w=1.7, bold=True), dict(label="Quantidade", key="available", fmt=qty_unit("available"), w=0.9, align="right"),
            dict(label="Consumo/dia", key="daily_rate", fmt="num", dec=3, w=0.7, align="right"),
            dict(label="Autonomia", key="autonomy_days", fmt=days_fmt, w=0.7, align="right"),
            dict(label="Próx. validade", key="next_expiry", fmt="date", w=0.8),
            dict(label="Usar primeiro (local)", key="fefo_txt", w=1.6), dict(label="Economizar?", key="eco", w=0.8),
            dict(label="Retiradas (anotar à mão)", key="_blank", w=1.6)]
    for g in data["groups"]:
        rows = []
        for r in data["rows"]:
            if r["grupo"] != g["grupo"]:
                continue
            r["fefo_txt"] = ("%s — %s" % (r["fefo_first"], r["fefo_location"])) if r["fefo_first"] else "; ".join(r["locations"])
            if r.get("expiry_limited"):
                r["eco"] = "vence antes"
            elif r["required_reduction"]:
                r["eco"] = "reduzir %d%%" % round(100 * r["required_reduction"])
            else:
                r["eco"] = "não"
            r["_highlight"] = RED if r["economize"] else None
            rows.append(r)
        sections.append((g["label"], cols, rows))
    ov = data["overall"]
    subtitle = "%s | %d pessoa(s) | Meta: %d dias | Autonomia geral: %s%s" % (
        house, data["people"], data["target_days"],
        "—" if ov["days"] is None else ("%s dias" % fmt_num(ov["days"], 1)),
        (" (limitado por: %s)" % ov["limiting"]) if ov.get("limiting") else "")
    if red or data["global_reduction"]:
        subtitle += " | Simulação de redução: " + ", ".join("%s %d%%" % (s.GROUP_LABELS.get(k, k), round(v * 100)) for k, v in red.items() if v)
        if data["global_reduction"]:
            subtitle += " geral %d%%" % round(100 * data["global_reduction"])
    # mapa resumido no final
    mp = build(conn, "mapa", {})
    sections.append(("Onde está cada item (mapa de armazenamento)",) + tuple(mp["sections"][0][1:]))
    return dict(title="INVENTÁRIO DE EMERGÊNCIA", subtitle=subtitle, sections=sections, landscape=True,
                footer="Guarde esta folha em local seco junto com lanterna e caneta")


def to_html(rep):
    out = ['<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>%s</title>' % escape(rep["title"]),
           '<style>@page{size:A4 %s;margin:10mm}body{font:11px/1.35 Arial,Helvetica,sans-serif;color:#111;margin:12px}'
           'h1{font-size:18px;margin:0 0 2px;color:#1f3a4d}h2{font-size:14px;margin:16px 0 4px;color:#1f3a4d;break-after:avoid}.sub{color:#555;margin-bottom:8px}'
           'table{border-collapse:collapse;width:100%%;margin-bottom:10px}th{background:#1f3a4d;color:#fff;text-align:left;padding:4px 5px;font-size:10.5px}'
           'td{border-bottom:1px solid #d5dade;padding:3px 5px;vertical-align:top}tr:nth-child(even) td{background:#f3f5f7}'
           'td.r{text-align:right;white-space:nowrap}td.b{font-weight:bold}tr{break-inside:avoid}thead{display:table-header-group}'
           'td.hl{border-left:4px solid}.foot{margin-top:10px;color:#666;font-size:10px}td.blank{min-width:60px}'
           '</style></head><body>' % ("landscape" if rep.get("landscape") else "portrait"),
           '<h1>%s</h1><div class="sub">%s</div>' % (escape(rep["title"]), escape(rep.get("subtitle") or ""))]
    for title, cols, rows in rep["sections"]:
        if title:
            out.append("<h2>%s</h2>" % escape(title))
        out.append("<table><thead><tr>%s</tr></thead><tbody>" % "".join("<th>%s</th>" % escape(c["label"]) for c in cols))
        if not rows:
            out.append('<tr><td colspan="%d">Nenhum registro.</td></tr>' % len(cols))
        for r in rows:
            hl = r.get("_highlight")
            tds = []
            for i, c in enumerate(cols):
                cls = []
                if c.get("align") == "right":
                    cls.append("r")
                if c.get("bold"):
                    cls.append("b")
                if c["key"] == "_blank":
                    cls.append("blank")
                style = ""
                if i == 0 and hl:
                    cls.append("hl")
                    style = ' style="border-left-color:rgb(%d,%d,%d)"' % tuple(int(x * 255) for x in hl)
                tds.append('<td class="%s"%s>%s</td>' % (" ".join(cls), style, escape(cell_text(c, r))))
            out.append("<tr>%s</tr>" % "".join(tds))
        out.append("</tbody></table>")
    out.append('<div class="foot">%sGerado em %s pelo Estoque Autônomo (sistema local, offline).</div>' % (
        escape(rep.get("footer") + ". ") if rep.get("footer") else "", date.today().strftime("%d/%m/%Y")))
    out.append("</body></html>")
    return "".join(out)

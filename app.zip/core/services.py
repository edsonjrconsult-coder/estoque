"""Regras de negócio do Estoque Autônomo."""
import json
import math
import uuid
from datetime import date, timedelta

from . import autonomy as au
from .db import Tx, now_ts, today

MOVEMENT_TYPES = {
    "ENTRADA": "Entrada",
    "CONSUMO": "Saída para consumo",
    "TRANSFERENCIA": "Transferência entre locais",
    "DESCARTE": "Descarte",
    "PERDA": "Perda",
    "VENCIMENTO": "Baixa por vencimento",
    "AJUSTE": "Ajuste de inventário",
    "DEVOLUCAO": "Devolução",
    "ABERTURA": "Abertura de recipiente",
    "FRACIONAMENTO": "Fracionamento em recipientes",
    "ESTORNO": "Estorno (correção)",
}
OUT_TYPES = {"CONSUMO", "DESCARTE", "PERDA", "VENCIMENTO"}

GROUP_LABELS = {
    "agua": "Água", "alimentos": "Alimentos", "medicamentos": "Medicamentos", "higiene": "Higiene",
    "limpeza": "Limpeza", "agricola": "Insumos agrícolas", "outros": "Outros",
}
GROUP_ORDER = ["agua", "alimentos", "medicamentos", "higiene", "limpeza", "agricola", "outros"]
LOCATION_TYPES = ["deposito", "cozinha", "despensa", "cisterna", "caixa_dagua", "galpao", "armario",
                  "prateleira", "geladeira", "freezer", "quarto", "garagem", "veiculo", "outro"]


class BusinessError(Exception):
    pass


# --------------------------------------------------------------------------- utilidades
def fnum(v, default=0.0):
    if v is None or v == "":
        return default
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "")
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        raise BusinessError("Número inválido: %r" % v)


def inum(v, default=None):
    if v is None or v == "":
        return default
    return int(round(fnum(v)))


def sdate(v):
    if v in (None, ""):
        return None
    d = au.parse_date(v)
    if d is None:
        # aceita dd/mm/aaaa
        try:
            p = str(v).strip().split("/")
            d = date(int(p[2]), int(p[1]), int(p[0]))
        except Exception:
            raise BusinessError("Data inválida: %r (use dd/mm/aaaa)" % v)
    return d.isoformat()


def sstr(v):
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def settings(conn):
    return {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}


def int_list(s, default):
    try:
        vals = sorted({int(x) for x in str(s).replace(";", ",").split(",") if x.strip()})
        return vals or default
    except ValueError:
        return default


def responsible_or_default(conn, resp):
    resp = sstr(resp) or sstr(settings(conn).get("responsible_default"))
    if not resp:
        raise BusinessError("Informe o responsável pela operação.")
    return resp


def audit(conn, entity, entity_id, action, responsible, before=None, after=None):
    conn.execute(
        "INSERT INTO audit_log(ts, entity, entity_id, action, responsible, before_json, after_json) VALUES (?,?,?,?,?,?,?)",
        (now_ts(), entity, entity_id, action, responsible,
         json.dumps(before, ensure_ascii=False, default=str) if before is not None else None,
         json.dumps(after, ensure_ascii=False, default=str) if after is not None else None))


def update_settings(conn, values, responsible=None):
    with Tx(conn):
        before = settings(conn)
        changed = {}
        for k, v in values.items():
            if k == "schema_version":
                continue
            v = "" if v is None else str(v)
            if before.get(k) != v:
                conn.execute("INSERT INTO settings(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
                changed[k] = v
        if changed:
            audit(conn, "settings", None, "alteracao", responsible or "sistema",
                  {k: before.get(k) for k in changed}, changed)
    return settings(conn)


# --------------------------------------------------------------------------- categorias / unidades
def list_categories(conn, include_inactive=False):
    rows = conn.execute("SELECT * FROM categories %s ORDER BY priority, name" %
                        ("" if include_inactive else "WHERE active=1")).fetchall()
    usage = {r["cid"]: r["n"] for r in conn.execute(
        "SELECT COALESCE(subcategory_id, category_id) AS cid, COUNT(*) AS n FROM products WHERE active=1 GROUP BY cid")}
    usage_top = {r["category_id"]: r["n"] for r in conn.execute(
        "SELECT category_id, COUNT(*) AS n FROM products WHERE active=1 GROUP BY category_id")}
    for r in rows:
        r["products"] = usage_top.get(r["id"], 0) if r["parent_id"] is None else usage.get(r["id"], 0)
    return rows


def save_category(conn, data, responsible=None):
    name = sstr(data.get("name"))
    if not name:
        raise BusinessError("Informe o nome da categoria.")
    parent_id = inum(data.get("parent_id"))
    grupo = data.get("grupo") or "outros"
    if grupo not in GROUP_LABELS:
        grupo = "outros"
    fields = dict(name=name, parent_id=parent_id, grupo=grupo, essential=1 if data.get("essential") else 0,
                  priority=inum(data.get("priority"), 50), notes=sstr(data.get("notes")),
                  active=0 if data.get("active") in (0, False, "0") else 1)
    if parent_id:
        par = conn.execute("SELECT * FROM categories WHERE id=?", (parent_id,)).fetchone()
        if not par:
            raise BusinessError("Categoria-mãe inexistente.")
        if par["parent_id"]:
            raise BusinessError("Subcategorias só podem pertencer a uma categoria principal.")
    with Tx(conn):
        cid = inum(data.get("id"))
        if cid:
            before = conn.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
            if not before:
                raise BusinessError("Categoria não encontrada.")
            if parent_id == cid:
                raise BusinessError("Uma categoria não pode ser mãe de si mesma.")
            conn.execute("UPDATE categories SET name=:name, parent_id=:parent_id, grupo=:grupo, essential=:essential,"
                         " priority=:priority, notes=:notes, active=:active WHERE id=:id", dict(fields, id=cid))
            if parent_id is None:
                # subcategorias herdam grupo/essencial da principal
                conn.execute("UPDATE categories SET grupo=?, essential=? WHERE parent_id=?",
                             (grupo, fields["essential"], cid))
            audit(conn, "categoria", cid, "alteracao", responsible, before, fields)
        else:
            try:
                cid = conn.execute("INSERT INTO categories(name, parent_id, grupo, essential, priority, notes, active, created_at)"
                                   " VALUES (:name,:parent_id,:grupo,:essential,:priority,:notes,:active,:ts)",
                                   dict(fields, ts=now_ts())).lastrowid
            except Exception as e:
                if "UNIQUE" in str(e):
                    raise BusinessError("Já existe uma categoria com esse nome neste nível.")
                raise
            audit(conn, "categoria", cid, "inclusao", responsible, None, fields)
    return conn.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()


def delete_category(conn, cid, responsible=None):
    with Tx(conn):
        used = conn.execute("SELECT COUNT(*) AS n FROM products WHERE category_id=? OR subcategory_id=?", (cid, cid)).fetchone()["n"]
        subs = conn.execute("SELECT COUNT(*) AS n FROM categories WHERE parent_id=?", (cid,)).fetchone()["n"]
        before = conn.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
        if used or subs:
            conn.execute("UPDATE categories SET active=0 WHERE id=?", (cid,))
            audit(conn, "categoria", cid, "inativacao", responsible, before, {"active": 0})
            return {"deleted": False, "inactivated": True}
        conn.execute("DELETE FROM categories WHERE id=?", (cid,))
        audit(conn, "categoria", cid, "exclusao", responsible, before, None)
        return {"deleted": True}


def list_units(conn):
    return conn.execute("SELECT * FROM units ORDER BY kind, code").fetchall()


def save_unit(conn, data):
    code = sstr(data.get("code"))
    name = sstr(data.get("name")) or code
    if not code:
        raise BusinessError("Informe a sigla da unidade.")
    with Tx(conn):
        uid = inum(data.get("id"))
        if uid:
            conn.execute("UPDATE units SET code=?, name=?, kind=? WHERE id=?", (code, name, data.get("kind") or "outro", uid))
        else:
            try:
                conn.execute("INSERT INTO units(code, name, kind) VALUES (?,?,?)", (code, name, data.get("kind") or "outro"))
            except Exception as e:
                if "UNIQUE" in str(e):
                    raise BusinessError("Unidade já cadastrada.")
                raise
    return list_units(conn)


# --------------------------------------------------------------------------- locais (mapa de armazenamento)
def list_locations(conn, include_inactive=False):
    rows = conn.execute("SELECT * FROM locations %s ORDER BY name" % ("" if include_inactive else "WHERE active=1")).fetchall()
    by_id = {r["id"]: r for r in conn.execute("SELECT * FROM locations").fetchall()}
    for r in rows:
        r["path"] = location_path(by_id, r["id"])
    rows.sort(key=lambda r: r["path"].lower())
    return rows


def location_path(by_id, lid, sep=" › "):
    parts, seen = [], set()
    while lid and lid in by_id and lid not in seen:
        seen.add(lid)
        parts.append(by_id[lid]["name"])
        lid = by_id[lid]["parent_id"]
    return sep.join(reversed(parts))


def location_map(conn):
    by_id = {r["id"]: r for r in conn.execute("SELECT * FROM locations").fetchall()}
    return {lid: location_path(by_id, lid) for lid in by_id}


def save_location(conn, data, responsible=None):
    name = sstr(data.get("name"))
    if not name:
        raise BusinessError("Informe o nome do local.")
    parent_id = inum(data.get("parent_id"))
    typ = data.get("type") or "outro"
    fields = dict(name=name, parent_id=parent_id, type=typ, description=sstr(data.get("description")),
                  capacity=sstr(data.get("capacity")), active=0 if data.get("active") in (0, False, "0") else 1)
    with Tx(conn):
        lid = inum(data.get("id"))
        if lid:
            # impede ciclos
            p = parent_id
            seen = set()
            while p:
                if p == lid:
                    raise BusinessError("Um local não pode ficar dentro de si mesmo.")
                if p in seen:
                    break
                seen.add(p)
                row = conn.execute("SELECT parent_id FROM locations WHERE id=?", (p,)).fetchone()
                p = row["parent_id"] if row else None
            before = conn.execute("SELECT * FROM locations WHERE id=?", (lid,)).fetchone()
            conn.execute("UPDATE locations SET name=:name, parent_id=:parent_id, type=:type, description=:description,"
                         " capacity=:capacity, active=:active WHERE id=:id", dict(fields, id=lid))
            audit(conn, "local", lid, "alteracao", responsible, before, fields)
        else:
            lid = conn.execute("INSERT INTO locations(name, parent_id, type, description, capacity, active, created_at)"
                               " VALUES (:name,:parent_id,:type,:description,:capacity,:active,:ts)",
                               dict(fields, ts=now_ts())).lastrowid
            conn.execute("UPDATE locations SET code=? WHERE id=?", ("LOC-%03d" % lid, lid))
            audit(conn, "local", lid, "inclusao", responsible, None, fields)
    return conn.execute("SELECT * FROM locations WHERE id=?", (lid,)).fetchone()


def delete_location(conn, lid, responsible=None):
    with Tx(conn):
        used = conn.execute("""SELECT (SELECT COUNT(*) FROM lots WHERE location_id=:i) + (SELECT COUNT(*) FROM containers WHERE location_id=:i)
                               + (SELECT COUNT(*) FROM locations WHERE parent_id=:i) + (SELECT COUNT(*) FROM products WHERE default_location_id=:i)
                               + (SELECT COUNT(*) FROM movements WHERE from_location_id=:i OR to_location_id=:i) AS n""", {"i": lid}).fetchone()["n"]
        before = conn.execute("SELECT * FROM locations WHERE id=?", (lid,)).fetchone()
        if used:
            conn.execute("UPDATE locations SET active=0 WHERE id=?", (lid,))
            audit(conn, "local", lid, "inativacao", responsible, before, {"active": 0})
            return {"deleted": False, "inactivated": True}
        conn.execute("DELETE FROM locations WHERE id=?", (lid,))
        audit(conn, "local", lid, "exclusao", responsible, before, None)
        return {"deleted": True}


# --------------------------------------------------------------------------- estado do estoque
class StockState:
    """Fotografia do estoque calculada a partir do livro-razão."""

    def __init__(self, conn, ref_day=None):
        self.ref = ref_day or date.today()
        self.locs = location_map(conn)
        self.products = {p["id"]: p for p in conn.execute("SELECT * FROM products").fetchall()}
        cats = {c["id"]: c for c in conn.execute("SELECT * FROM categories").fetchall()}
        self.cats = cats
        self.lots = {}
        for l in conn.execute("""SELECT l.*, s.qty FROM lots l JOIN v_lot_stock s ON s.lot_id=l.id""").fetchall():
            l["containers"] = []
            l["container_total"] = 0.0
            self.lots[l["id"]] = l
        self.containers = {}
        for c in conn.execute("""SELECT c.*, s.qty FROM containers c JOIN v_container_stock s ON s.container_id=c.id""").fetchall():
            self.containers[c["id"]] = c
            lot = self.lots.get(c["lot_id"])
            if lot:
                lot["containers"].append(c)
                lot["container_total"] += c["qty"]
        for l in self.lots.values():
            l["free_qty"] = max(0.0, l["qty"] - l["container_total"])
            l["location_path"] = self.locs.get(l["location_id"], "")
            for c in l["containers"]:
                c["effective_expiry"] = c["expires_at"] or l["expires_at"]
                c["location_path"] = self.locs.get(c["location_id"] or l["location_id"], "")
                c["lot_code"] = l["code"]
                c["lot_number"] = l["lot_number"]
        self.by_product = {}
        for l in self.lots.values():
            self.by_product.setdefault(l["product_id"], []).append(l)

    def items(self, product_id):
        """Itens físicos (parte livre dos lotes + recipientes) com validade efetiva."""
        out = []
        for l in self.by_product.get(product_id, []):
            if l["free_qty"] > 1e-9:
                out.append({"kind": "lote", "id": l["id"], "code": l["code"], "lot_id": l["id"], "container_id": None,
                            "lot_code": l["code"], "lot_number": l["lot_number"], "qty": l["free_qty"],
                            "expires_at": l["expires_at"], "opened_at": l.get("opened_at"),
                            "location_id": l["location_id"], "location_path": l["location_path"], "label": None})
            for c in l["containers"]:
                if c["qty"] > 1e-9:
                    out.append({"kind": "recipiente", "id": c["id"], "code": c["code"], "lot_id": l["id"], "container_id": c["id"],
                                "lot_code": l["code"], "lot_number": l["lot_number"], "qty": c["qty"],
                                "expires_at": c["effective_expiry"], "opened_at": c["opened_at"],
                                "location_id": c["location_id"] or l["location_id"], "location_path": c["location_path"],
                                "label": c["label"]})
        return out

    def qty(self, product_id):
        return sum(l["qty"] for l in self.by_product.get(product_id, []))

    def value(self, product_id):
        return sum(l["qty"] * (l["unit_price"] or 0) for l in self.by_product.get(product_id, []))

    def category_of(self, p):
        top = self.cats.get(p["category_id"])
        return top


def fefo_key(item):
    exp = item.get("expires_at") or "9999-12-31"
    opened = 0 if item.get("opened_at") else 1  # recipientes abertos primeiro
    return (exp, opened, item.get("kind") != "recipiente", item.get("code") or "")


def expiry_status(exp, ref, alert_days):
    if not exp:
        return {"status": "sem_validade", "days": None}
    d = au.parse_date(exp)
    if d is None:
        return {"status": "sem_validade", "days": None}
    days = (d - ref).days
    if days < 0:
        return {"status": "vencido", "days": days}
    for a in sorted(alert_days):
        if days <= a:
            return {"status": "vence_%d" % a, "days": days, "bucket": a}
    return {"status": "ok", "days": days}


# --------------------------------------------------------------------------- produtos
PRODUCT_FIELDS = ["name", "category_id", "subcategory_id", "brand", "manufacturer", "description", "unit", "barcode",
                  "min_qty", "safety_qty", "max_qty", "desired_days", "default_location_id", "shelf_life_open_days",
                  "critical", "cons_mode", "cons_qty", "cons_period", "cons_people", "cons_rule", "notes", "photo"]


def _product_fields(data):
    f = {}
    f["name"] = sstr(data.get("name"))
    if not f["name"]:
        raise BusinessError("Informe o nome do produto.")
    f["category_id"] = inum(data.get("category_id"))
    f["subcategory_id"] = inum(data.get("subcategory_id"))
    for k in ("brand", "manufacturer", "description", "barcode", "notes", "photo"):
        f[k] = sstr(data.get(k))
    f["unit"] = sstr(data.get("unit")) or "un"
    f["min_qty"] = fnum(data.get("min_qty"), 0)
    f["safety_qty"] = fnum(data.get("safety_qty"), 0)
    f["max_qty"] = fnum(data.get("max_qty"), None) if data.get("max_qty") not in (None, "") else None
    f["desired_days"] = inum(data.get("desired_days"))
    f["default_location_id"] = inum(data.get("default_location_id"))
    f["shelf_life_open_days"] = inum(data.get("shelf_life_open_days"))
    f["critical"] = 1 if data.get("critical") in (1, True, "1", "true", "on") else 0
    mode = data.get("cons_mode") or "nenhum"
    if mode not in ("nenhum", "por_pessoa", "total"):
        raise BusinessError("Modo de consumo inválido.")
    f["cons_mode"] = mode
    f["cons_qty"] = fnum(data.get("cons_qty"), 0)
    period = data.get("cons_period") or "dia"
    if period not in ("dia", "semana", "mes", "intervalo"):
        raise BusinessError("Período de consumo inválido.")
    f["cons_period"] = period
    f["cons_people"] = inum(data.get("cons_people"))
    rule = data.get("cons_rule")
    if isinstance(rule, dict):
        rule = json.dumps(rule, ensure_ascii=False)
    elif rule:
        try:
            json.loads(rule)
        except ValueError:
            raise BusinessError("Regra de consumo inválida (JSON).")
    f["cons_rule"] = rule or None
    for k in ("min_qty", "safety_qty", "cons_qty"):
        if f[k] < 0:
            raise BusinessError("Valores não podem ser negativos.")
    if f["max_qty"] is not None and f["max_qty"] < f["min_qty"]:
        raise BusinessError("A quantidade máxima não pode ser menor que a mínima.")
    if f["subcategory_id"] and not f["category_id"]:
        raise BusinessError("Informe a categoria antes da subcategoria.")
    return f


def create_product(conn, data, responsible=None):
    """Cadastra o produto e, se houver quantidade, registra o primeiro lote (entrada)."""
    resp = responsible_or_default(conn, responsible)
    f = _product_fields(data)
    with Tx(conn):
        ts = now_ts()
        cols = ",".join(f.keys())
        pid = conn.execute("INSERT INTO products(%s, created_at, updated_at) VALUES (%s, ?, ?)" %
                           (cols, ",".join("?" * len(f))), list(f.values()) + [ts, ts]).lastrowid
        conn.execute("UPDATE products SET code=? WHERE id=?", ("P-%06d" % pid, pid))
        audit(conn, "produto", pid, "inclusao", resp, None, f)
        lot = data.get("initial_lot")
        if lot and fnum(lot.get("qty"), 0) > 0:
            if not lot.get("location_id"):
                lot["location_id"] = f["default_location_id"]
            register_entry(conn, pid, lot, resp)
    return get_product(conn, pid)


def update_product(conn, pid, data, responsible=None):
    resp = responsible_or_default(conn, responsible)
    f = _product_fields(data)
    with Tx(conn):
        before = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not before:
            raise BusinessError("Produto não encontrado.")
        f["active"] = 0 if data.get("active") in (0, False, "0") else 1
        if "photo" not in data:
            f["photo"] = before["photo"]  # editar o cadastro não apaga a foto
        sets = ",".join("%s=?" % k for k in f)
        conn.execute("UPDATE products SET %s, updated_at=? WHERE id=?" % sets, list(f.values()) + [now_ts(), pid])
        changed_before = {k: before.get(k) for k in f if before.get(k) != f[k]}
        changed_after = {k: f[k] for k in changed_before}
        if changed_after:
            audit(conn, "produto", pid, "alteracao", resp, changed_before, changed_after)
    return get_product(conn, pid)


def set_product_photo(conn, pid, filename, responsible=None):
    with Tx(conn):
        before = conn.execute("SELECT photo FROM products WHERE id=?", (pid,)).fetchone()
        conn.execute("UPDATE products SET photo=?, updated_at=? WHERE id=?", (filename, now_ts(), pid))
        audit(conn, "produto", pid, "foto", responsible or "sistema", before, {"photo": filename})


def list_products(conn, filters=None, state=None, calc=None):
    filters = filters or {}
    st = state or StockState(conn)
    s = settings(conn)
    alert = int_list(s.get("alert_days"), [7, 15, 30, 60, 90])
    calc = calc if calc is not None else compute_autonomy(conn, state=st)
    q = (filters.get("q") or "").strip().lower()
    out = []
    for p in st.products.values():
        if not filters.get("include_inactive") and not p["active"]:
            continue
        if filters.get("category_id") and str(p["category_id"]) != str(filters["category_id"]) and str(p["subcategory_id"]) != str(filters["category_id"]):
            continue
        items = st.items(p["id"])
        if filters.get("location_id"):
            lid = int(filters["location_id"])
            if not any(i["location_id"] == lid for i in items) and p["default_location_id"] != lid:
                continue
        cat = st.cats.get(p["category_id"]) or {}
        sub = st.cats.get(p["subcategory_id"]) or {}
        if q and q not in " ".join(str(x or "") for x in (p["name"], p["code"], p["brand"], p["barcode"], cat.get("name"), sub.get("name"))).lower():
            continue
        out.append(product_summary(p, st, calc.get(p["id"]), alert, cat, sub))
    status_f = filters.get("status")
    if status_f:
        out = [r for r in out if status_f in r["flags"] or r["status"] == status_f]
    out.sort(key=lambda r: (r["category_name"] or "~", r["name"].lower()))
    return out


def product_summary(p, st, calc, alert, cat=None, sub=None):
    cat = cat if cat is not None else (st.cats.get(p["category_id"]) or {})
    sub = sub if sub is not None else (st.cats.get(p["subcategory_id"]) or {})
    items = st.items(p["id"])
    qty = st.qty(p["id"])
    flags = []
    expired_qty = 0.0
    next_exp = None
    for i in items:
        es = expiry_status(i["expires_at"], st.ref, alert)
        i.update(es)
        if es["status"] == "vencido":
            expired_qty += i["qty"]
        elif i["expires_at"] and (next_exp is None or i["expires_at"] < next_exp):
            next_exp = i["expires_at"]
    if expired_qty > 1e-9:
        flags.append("vencido")
    ne = expiry_status(next_exp, st.ref, alert) if next_exp else {"status": "sem_validade", "days": None}
    if ne["status"].startswith("vence_"):
        flags.append("vencendo")
    if qty <= 1e-9:
        flags.append("zerado")
    if p["min_qty"] and qty < p["min_qty"] - 1e-9:
        flags.append("baixo")
    if p["max_qty"] and qty > p["max_qty"] + 1e-9:
        flags.append("acima_maximo")
    status = "adequado"
    if "vencido" in flags:
        status = "vencido"
    elif "zerado" in flags or "baixo" in flags:
        status = "baixo"
    elif "vencendo" in flags and ne.get("days") is not None and ne["days"] <= 30:
        status = "vencendo"
    locs = sorted({i["location_path"] for i in items if i["location_path"]})
    return {
        "id": p["id"], "code": p["code"], "name": p["name"], "brand": p["brand"], "unit": p["unit"],
        "category_id": p["category_id"], "category_name": cat.get("name"), "subcategory_name": sub.get("name"),
        "grupo": cat.get("grupo", "outros"), "essential": cat.get("essential", 0), "critical": p["critical"],
        "qty": qty, "expired_qty": expired_qty, "usable_qty": qty - expired_qty, "value": st.value(p["id"]),
        "min_qty": p["min_qty"], "max_qty": p["max_qty"], "safety_qty": p["safety_qty"],
        "next_expiry": next_exp, "next_expiry_days": ne.get("days"), "locations": locs,
        "lots": len(st.by_product.get(p["id"], [])), "flags": flags, "status": status, "active": p["active"],
        "photo": p["photo"], "barcode": p["barcode"],
        "autonomy_days": calc["autonomy_days"] if calc else None,
        "daily_rate": calc["daily_rate"] if calc else 0,
        "autonomy_capped": calc.get("autonomy_capped") if calc else False,
    }


def get_product(conn, pid, ref_day=None):
    st = StockState(conn, ref_day)
    p = st.products.get(int(pid))
    if not p:
        raise BusinessError("Produto não encontrado.")
    s = settings(conn)
    alert = int_list(s.get("alert_days"), [7, 15, 30, 60, 90])
    calc = compute_autonomy(conn, state=st, only=[p["id"]])
    summary = product_summary(p, st, calc.get(p["id"]), alert)
    lots = []
    for l in sorted(st.by_product.get(p["id"], []), key=lambda l: (l["expires_at"] or "9999", l["id"])):
        lr = {k: v for k, v in l.items() if k != "containers"}
        lr.update(expiry_status(l["expires_at"], st.ref, alert))
        lr["containers"] = []
        for c in l["containers"]:
            cr = dict(c)
            cr.update(expiry_status(c["effective_expiry"], st.ref, alert))
            lr["containers"].append(cr)
        lots.append(lr)
    movs = conn.execute("""SELECT m.*, l.code AS lot_code, c.code AS container_code FROM movements m
                           LEFT JOIN lots l ON l.id=m.lot_id LEFT JOIN containers c ON c.id=m.container_id
                           WHERE m.product_id=? ORDER BY m.ts DESC, m.id DESC LIMIT 300""", (p["id"],)).fetchall()
    for m in movs:
        m["type_label"] = MOVEMENT_TYPES.get(m["type"], m["type"])
        m["from_path"] = st.locs.get(m["from_location_id"], "")
        m["to_path"] = st.locs.get(m["to_location_id"], "")
    items = sorted(st.items(p["id"]), key=fefo_key)
    for i in items:
        i.update(expiry_status(i["expires_at"], st.ref, alert))
    audit_rows = conn.execute("SELECT * FROM audit_log WHERE entity='produto' AND entity_id=? ORDER BY id DESC LIMIT 50", (p["id"],)).fetchall()
    return {"product": p, "summary": summary, "lots": lots, "movements": movs, "fefo": items,
            "autonomy": calc.get(p["id"]), "audit": audit_rows,
            "default_location_path": st.locs.get(p["default_location_id"], "")}


# --------------------------------------------------------------------------- lotes, recipientes e movimentações
def _new_batch():
    return uuid.uuid4().hex[:12]


def _insert_movement(conn, **kw):
    kw.setdefault("ts", now_ts())
    kw.setdefault("created_at", now_ts())
    kw.setdefault("qty", 0.0)
    kw.setdefault("container_qty", 0.0)
    cols = ",".join(kw.keys())
    return conn.execute("INSERT INTO movements(%s) VALUES (%s)" % (cols, ",".join("?" * len(kw))), list(kw.values())).lastrowid


def _lot_qty(conn, lot_id):
    return conn.execute("SELECT qty FROM v_lot_stock WHERE lot_id=?", (lot_id,)).fetchone()["qty"]


def _container_qty(conn, cid):
    return conn.execute("SELECT qty FROM v_container_stock WHERE container_id=?", (cid,)).fetchone()["qty"]


def _lot_free(conn, lot_id):
    used = conn.execute("SELECT COALESCE(SUM(qty),0) AS q FROM v_container_stock WHERE lot_id=?", (lot_id,)).fetchone()["q"]
    return _lot_qty(conn, lot_id) - used


def _mov_ts(data):
    """Data/hora informada pelo usuário (para registros retroativos) ou agora."""
    v = sstr(data.get("ts")) if data else None
    if not v:
        return now_ts()
    v = v.replace("T", " ")
    if len(v) == 10:
        v += " 12:00:00"
    elif len(v) == 16:
        v += ":00"
    return v[:19]


def register_entry(conn, product_id, data, responsible=None):
    """Entrada de produto: cria um lote novo e lança a movimentação ENTRADA."""
    resp = responsible_or_default(conn, responsible)
    qty = fnum(data.get("qty"))
    if qty <= 0:
        raise BusinessError("A quantidade de entrada deve ser maior que zero.")
    with Tx(conn):
        p = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        if not p:
            raise BusinessError("Produto não encontrado.")
        unit_price = fnum(data.get("unit_price"), 0)
        if data.get("total_price") not in (None, "") and not data.get("unit_price"):
            unit_price = fnum(data.get("total_price")) / qty
        t = today()
        lot = dict(product_id=product_id, lot_number=sstr(data.get("lot_number")), supplier=sstr(data.get("supplier")),
                   qty_acquired=qty, unit_price=unit_price, acquired_at=sdate(data.get("acquired_at")) or t,
                   entry_at=sdate(data.get("entry_at")) or t, stored_at=sdate(data.get("stored_at")) or sdate(data.get("entry_at")) or t,
                   manufactured_at=sdate(data.get("manufactured_at")), expires_at=sdate(data.get("expires_at")),
                   location_id=inum(data.get("location_id")) or p["default_location_id"], notes=sstr(data.get("notes")),
                   created_at=now_ts())
        if lot["manufactured_at"] and lot["expires_at"] and lot["expires_at"] < lot["manufactured_at"]:
            raise BusinessError("A validade não pode ser anterior à fabricação.")
        lot_id = conn.execute("INSERT INTO lots(%s) VALUES (%s)" % (",".join(lot), ",".join("?" * len(lot))), list(lot.values())).lastrowid
        conn.execute("UPDATE lots SET code=? WHERE id=?", ("L-%06d" % lot_id, lot_id))
        batch = _new_batch()
        _insert_movement(conn, ts=_mov_ts(data), type="ENTRADA", product_id=product_id, lot_id=lot_id, qty=qty,
                         to_location_id=lot["location_id"], unit_price=unit_price,
                         reason=sstr(data.get("reason")) or "Entrada de lote", responsible=resp, batch_id=batch)
        audit(conn, "lote", lot_id, "inclusao", resp, None, lot)
        # recipientes opcionais na entrada
        conts = data.get("containers") or []
        if data.get("split_count"):
            n = inum(data.get("split_count"))
            size = fnum(data.get("split_size"), qty / n if n else 0)
            conts = [{"qty": size} for _ in range(n)]
        if conts:
            split_lot(conn, lot_id, {"containers": conts}, resp, batch=batch)
    return conn.execute("SELECT * FROM lots WHERE id=?", (lot_id,)).fetchone()


def update_lot(conn, lot_id, data, responsible=None):
    resp = responsible_or_default(conn, responsible)
    with Tx(conn):
        before = conn.execute("SELECT * FROM lots WHERE id=?", (lot_id,)).fetchone()
        if not before:
            raise BusinessError("Lote não encontrado.")
        f = dict(lot_number=sstr(data.get("lot_number")), supplier=sstr(data.get("supplier")),
                 unit_price=fnum(data.get("unit_price"), before["unit_price"]),
                 acquired_at=sdate(data.get("acquired_at")), entry_at=sdate(data.get("entry_at")),
                 stored_at=sdate(data.get("stored_at")), manufactured_at=sdate(data.get("manufactured_at")),
                 expires_at=sdate(data.get("expires_at")), notes=sstr(data.get("notes")))
        conn.execute("UPDATE lots SET %s WHERE id=?" % ",".join("%s=?" % k for k in f), list(f.values()) + [lot_id])
        ch = {k: f[k] for k in f if before.get(k) != f[k]}
        if ch:
            audit(conn, "lote", lot_id, "alteracao", resp, {k: before.get(k) for k in ch}, ch)
    return conn.execute("SELECT * FROM lots WHERE id=?", (lot_id,)).fetchone()


def split_lot(conn, lot_id, data, responsible=None, batch=None):
    """Divide (parte livre de) um lote em recipientes, mantendo a rastreabilidade."""
    resp = responsible_or_default(conn, responsible)
    conts = data.get("containers") or []
    if not conts:
        raise BusinessError("Informe ao menos um recipiente.")
    with Tx(conn):
        lot = conn.execute("SELECT * FROM lots WHERE id=?", (lot_id,)).fetchone()
        if not lot:
            raise BusinessError("Lote não encontrado.")
        free = _lot_free(conn, lot_id)
        total = sum(fnum(c.get("qty")) for c in conts)
        if any(fnum(c.get("qty")) <= 0 for c in conts):
            raise BusinessError("Cada recipiente precisa de quantidade maior que zero.")
        if total > free + 1e-9:
            raise BusinessError("Quantidade nos recipientes (%s) maior que o saldo livre do lote (%s)." % (_fmt(total), _fmt(free)))
        batch = batch or _new_batch()
        ids = []
        for i, c in enumerate(conts, start=1):
            q = fnum(c.get("qty"))
            row = dict(lot_id=lot_id, product_id=lot["product_id"], label=sstr(c.get("label")),
                       capacity=fnum(c.get("capacity"), q) if c.get("capacity") not in (None, "") else q,
                       initial_qty=q, stored_at=sdate(c.get("stored_at")) or lot["stored_at"] or today(),
                       expires_at=sdate(c.get("expires_at")), location_id=inum(c.get("location_id")) or lot["location_id"],
                       notes=sstr(c.get("notes")), created_at=now_ts())
            cid = conn.execute("INSERT INTO containers(%s) VALUES (%s)" % (",".join(row), ",".join("?" * len(row))), list(row.values())).lastrowid
            code = "R-%06d" % cid
            conn.execute("UPDATE containers SET code=?, label=COALESCE(label, ?) WHERE id=?", (code, code, cid))
            _insert_movement(conn, type="FRACIONAMENTO", product_id=lot["product_id"], lot_id=lot_id, container_id=cid,
                             qty=0.0, container_qty=q, to_location_id=row["location_id"], from_location_id=lot["location_id"],
                             reason=sstr(data.get("reason")) or "Lote %s dividido em recipiente" % lot["code"],
                             responsible=resp, batch_id=batch)
            audit(conn, "recipiente", cid, "inclusao", resp, None, row)
            ids.append(cid)
    return ids


def update_container(conn, cid, data, responsible=None):
    resp = responsible_or_default(conn, responsible)
    with Tx(conn):
        before = conn.execute("SELECT * FROM containers WHERE id=?", (cid,)).fetchone()
        if not before:
            raise BusinessError("Recipiente não encontrado.")
        f = dict(label=sstr(data.get("label")) or before["code"], capacity=fnum(data.get("capacity"), before["capacity"]),
                 stored_at=sdate(data.get("stored_at")), expires_at=sdate(data.get("expires_at")), notes=sstr(data.get("notes")))
        conn.execute("UPDATE containers SET %s WHERE id=?" % ",".join("%s=?" % k for k in f), list(f.values()) + [cid])
        ch = {k: f[k] for k in f if before.get(k) != f[k]}
        if ch:
            audit(conn, "recipiente", cid, "alteracao", resp, {k: before.get(k) for k in ch}, ch)
    return conn.execute("SELECT * FROM containers WHERE id=?", (cid,)).fetchone()


def _fmt(x):
    return ("%.3f" % x).rstrip("0").rstrip(".").replace(".", ",")


def register_movement(conn, data, responsible=None):
    """Registra uma movimentação sobre um lote ou recipiente.

    data: type, product_id, lot_id | container_id, qty (positiva), reason,
          to_location_id (transferência), direction ('entrada'|'saida' para ajuste/devolução),
          counted_qty (ajuste por contagem).
    """
    resp = responsible_or_default(conn, responsible)
    typ = (data.get("type") or "").upper()
    if typ not in MOVEMENT_TYPES or typ in ("ENTRADA", "FRACIONAMENTO", "ESTORNO"):
        raise BusinessError("Tipo de movimentação inválido para este formulário.")
    reason = sstr(data.get("reason"))
    with Tx(conn):
        cid = inum(data.get("container_id"))
        lot_id = inum(data.get("lot_id"))
        cont = None
        if cid:
            cont = conn.execute("SELECT * FROM containers WHERE id=?", (cid,)).fetchone()
            if not cont:
                raise BusinessError("Recipiente não encontrado.")
            lot_id = cont["lot_id"]
        lot = conn.execute("SELECT * FROM lots WHERE id=?", (lot_id,)).fetchone() if lot_id else None
        if not lot:
            if typ == "CONSUMO" and data.get("product_id"):
                return consume_fefo(conn, inum(data["product_id"]), fnum(data.get("qty")), resp, reason, ts=_mov_ts(data))
            raise BusinessError("Selecione o lote ou recipiente.")
        pid = lot["product_id"]
        batch = _new_batch()
        ts = _mov_ts(data)
        base = dict(ts=ts, type=typ, product_id=pid, lot_id=lot_id, container_id=cid, responsible=resp, batch_id=batch)
        cur = _container_qty(conn, cid) if cid else _lot_free(conn, lot_id)
        where = ("recipiente %s" % cont["code"]) if cont else ("lote %s (parte fora de recipientes)" % lot["code"])

        if typ == "TRANSFERENCIA":
            to = inum(data.get("to_location_id"))
            if not to:
                raise BusinessError("Informe o local de destino.")
            if cont:
                frm = cont["location_id"] or lot["location_id"]
                conn.execute("UPDATE containers SET location_id=? WHERE id=?", (to, cid))
            else:
                frm = lot["location_id"]
                conn.execute("UPDATE lots SET location_id=? WHERE id=?", (to, lot_id))
                # recipientes que acompanhavam o lote (sem local próprio) continuam no local antigo
                conn.execute("UPDATE containers SET location_id=? WHERE lot_id=? AND location_id IS NULL", (frm, lot_id))
            if frm == to:
                raise BusinessError("O destino é igual ao local atual.")
            mid = _insert_movement(conn, from_location_id=frm, to_location_id=to, reason=reason or "Transferência", **base)
            return {"movement_ids": [mid]}

        if typ == "ABERTURA":
            opened = sdate(data.get("opened_at")) or today()
            p = conn.execute("SELECT shelf_life_open_days FROM products WHERE id=?", (pid,)).fetchone()
            new_exp = None
            if p["shelf_life_open_days"]:
                new_exp = (date.fromisoformat(opened) + timedelta(days=p["shelf_life_open_days"])).isoformat()
            if cont:
                if cont["opened_at"]:
                    raise BusinessError("Este recipiente já foi aberto em %s." % cont["opened_at"])
                old = cont["expires_at"] or lot["expires_at"]
                exp = min(x for x in (old, new_exp) if x) if (old or new_exp) else None
                conn.execute("UPDATE containers SET opened_at=?, expires_at=? WHERE id=?", (opened, exp, cid))
                audit(conn, "recipiente", cid, "abertura", resp, {"opened_at": None, "expires_at": cont["expires_at"]},
                      {"opened_at": opened, "expires_at": exp})
            else:
                if lot["opened_at"]:
                    raise BusinessError("Este lote já foi aberto em %s." % lot["opened_at"])
                exp = min(x for x in (lot["expires_at"], new_exp) if x) if (lot["expires_at"] or new_exp) else None
                conn.execute("UPDATE lots SET opened_at=?, expires_at=? WHERE id=?", (opened, exp, lot_id))
                audit(conn, "lote", lot_id, "abertura", resp, {"opened_at": None, "expires_at": lot["expires_at"]},
                      {"opened_at": opened, "expires_at": exp})
            mid = _insert_movement(conn, reason=reason or ("Abertura%s" % (" — validade após aberto até %s" % exp if exp else "")), **base)
            return {"movement_ids": [mid]}

        if typ == "AJUSTE" and data.get("counted_qty") not in (None, ""):
            counted = fnum(data.get("counted_qty"))
            if counted < 0:
                raise BusinessError("A contagem não pode ser negativa.")
            delta = counted - cur
            if abs(delta) < 1e-9:
                return {"movement_ids": [], "message": "Sem diferença: nada a ajustar."}
        else:
            q = fnum(data.get("qty"))
            if q <= 0:
                raise BusinessError("A quantidade deve ser maior que zero.")
            if typ in OUT_TYPES:
                delta = -q
            elif typ in ("AJUSTE", "DEVOLUCAO"):
                direction = data.get("direction") or ("entrada" if typ == "DEVOLUCAO" else "saida")
                delta = q if direction == "entrada" else -q
            else:
                delta = -q
        if delta < 0 and -delta > cur + 1e-9:
            raise BusinessError("Saldo insuficiente no %s: disponível %s." % (where, _fmt(cur)))
        if typ in ("AJUSTE", "DEVOLUCAO", "DESCARTE", "PERDA", "VENCIMENTO") and not reason:
            raise BusinessError("Informe o motivo para este tipo de movimentação.")
        mid = _insert_movement(conn, qty=delta, container_qty=delta if cid else 0.0,
                               from_location_id=(cont["location_id"] if cont else None) or lot["location_id"] if delta < 0 else None,
                               to_location_id=(cont["location_id"] if cont else None) or lot["location_id"] if delta > 0 else None,
                               reason=reason or MOVEMENT_TYPES[typ], **base)
        return {"movement_ids": [mid]}


def consume_fefo(conn, product_id, qty, responsible=None, reason=None, ts=None, allow_expired=False):
    """Consome a quantidade pelo método FEFO (primeiro o que vence primeiro)."""
    resp = responsible_or_default(conn, responsible)
    if qty is None or qty <= 0:
        raise BusinessError("A quantidade deve ser maior que zero.")
    with Tx(conn):
        st = StockState(conn)
        if product_id not in st.products:
            raise BusinessError("Produto não encontrado.")
        items = sorted(st.items(product_id), key=fefo_key)
        ref = date.today().isoformat()
        if not allow_expired:
            items = [i for i in items if not i["expires_at"] or i["expires_at"] >= ref]
        avail = sum(i["qty"] for i in items)
        if qty > avail + 1e-9:
            raise BusinessError("Saldo utilizável insuficiente: disponível %s (itens vencidos não são consumidos)." % _fmt(avail))
        left = qty
        batch = _new_batch()
        ids = []
        for i in items:
            if left <= 1e-12:
                break
            use = min(i["qty"], left)
            ids.append(_insert_movement(conn, ts=ts or now_ts(), type="CONSUMO", product_id=product_id, lot_id=i["lot_id"],
                                        container_id=i["container_id"], qty=-use, container_qty=-use if i["container_id"] else 0.0,
                                        from_location_id=i["location_id"], reason=reason or "Consumo (FEFO)",
                                        responsible=resp, batch_id=batch))
            left -= use
    return {"movement_ids": ids}


def reverse_movement(conn, mid, reason, responsible=None):
    """Estorno: lança a movimentação inversa, preservando a original."""
    resp = responsible_or_default(conn, responsible)
    if not sstr(reason):
        raise BusinessError("Informe o motivo do estorno.")
    with Tx(conn):
        m = conn.execute("SELECT * FROM movements WHERE id=?", (mid,)).fetchone()
        if not m:
            raise BusinessError("Movimentação não encontrada.")
        if m["type"] == "ESTORNO":
            raise BusinessError("Não é possível estornar um estorno; registre nova movimentação.")
        if conn.execute("SELECT 1 FROM movements WHERE ref_movement_id=? AND type='ESTORNO'", (mid,)).fetchone():
            raise BusinessError("Esta movimentação já foi estornada.")
        if m["type"] in ("TRANSFERENCIA", "ABERTURA"):
            raise BusinessError("Transferência/abertura não alteram quantidade: registre uma nova transferência para corrigir.")
        if m["lot_id"] and m["qty"] > 0:
            free = _lot_free(conn, m["lot_id"]) if not m["container_id"] else _container_qty(conn, m["container_id"])
            if m["container_id"] is None and m["type"] == "ENTRADA":
                free = _lot_free(conn, m["lot_id"])
            if m["qty"] > free + 1e-9:
                raise BusinessError("Não é possível estornar: parte da quantidade já foi consumida ou está em recipientes.")
        if m["type"] == "FRACIONAMENTO" and m["container_qty"] < 0:
            if -m["container_qty"] > _lot_free(conn, m["lot_id"]) + 1e-9:
                raise BusinessError("Não é possível estornar: o saldo livre do lote já foi usado.")
        if m["type"] == "FRACIONAMENTO" and m["container_qty"] > 0:
            cq = _container_qty(conn, m["container_id"])
            if cq + 1e-9 < m["container_qty"]:
                raise BusinessError("O recipiente já teve retiradas; esvazie-o de volta ao lote por movimentação.")
        nid = _insert_movement(conn, type="ESTORNO", product_id=m["product_id"], lot_id=m["lot_id"], container_id=m["container_id"],
                               qty=-m["qty"], container_qty=-m["container_qty"], from_location_id=m["to_location_id"],
                               to_location_id=m["from_location_id"], reason="Estorno da movimentação #%d: %s" % (mid, reason),
                               responsible=resp, ref_movement_id=mid, batch_id=_new_batch())
    return {"movement_ids": [nid]}


def return_container_to_lot(conn, cid, responsible=None, reason=None):
    """Devolve o conteúdo do recipiente para a parte livre do lote (desfaz o fracionamento)."""
    resp = responsible_or_default(conn, responsible)
    with Tx(conn):
        c = conn.execute("SELECT * FROM containers WHERE id=?", (cid,)).fetchone()
        if not c:
            raise BusinessError("Recipiente não encontrado.")
        q = _container_qty(conn, cid)
        if q <= 1e-9:
            raise BusinessError("Recipiente vazio.")
        mid = _insert_movement(conn, type="FRACIONAMENTO", product_id=c["product_id"], lot_id=c["lot_id"], container_id=cid,
                               qty=0.0, container_qty=-q, reason=reason or "Conteúdo do recipiente devolvido ao lote",
                               responsible=resp, batch_id=_new_batch())
    return {"movement_ids": [mid]}


def list_movements(conn, f=None):
    f = f or {}
    where, args = [], []
    if f.get("product_id"):
        where.append("m.product_id=?"); args.append(int(f["product_id"]))
    if f.get("lot_id"):
        where.append("m.lot_id=?"); args.append(int(f["lot_id"]))
    if f.get("container_id"):
        where.append("m.container_id=?"); args.append(int(f["container_id"]))
    if f.get("type"):
        where.append("m.type=?"); args.append(f["type"])
    if f.get("date_from"):
        where.append("m.ts>=?"); args.append(sdate(f["date_from"]))
    if f.get("date_to"):
        where.append("m.ts<?"); args.append((date.fromisoformat(sdate(f["date_to"])) + timedelta(days=1)).isoformat())
    if f.get("category_id"):
        where.append("(p.category_id=? OR p.subcategory_id=?)"); args += [int(f["category_id"])] * 2
    if f.get("location_id"):
        where.append("(m.from_location_id=? OR m.to_location_id=?)"); args += [int(f["location_id"])] * 2
    if f.get("responsible"):
        where.append("m.responsible LIKE ?"); args.append("%" + f["responsible"] + "%")
    limit = min(int(f.get("limit") or 500), 100000)
    sql = """SELECT m.*, p.name AS product_name, p.code AS product_code, p.unit, l.code AS lot_code, l.lot_number,
                    c.code AS container_code, c.label AS container_label,
                    (SELECT COUNT(*) FROM movements r WHERE r.ref_movement_id=m.id AND r.type='ESTORNO') AS reversed
             FROM movements m JOIN products p ON p.id=m.product_id
             LEFT JOIN lots l ON l.id=m.lot_id LEFT JOIN containers c ON c.id=m.container_id
             %s ORDER BY m.ts DESC, m.id DESC LIMIT %d""" % (("WHERE " + " AND ".join(where)) if where else "", limit)
    rows = conn.execute(sql, args).fetchall()
    locs = location_map(conn)
    for r in rows:
        r["type_label"] = MOVEMENT_TYPES.get(r["type"], r["type"])
        r["from_path"] = locs.get(r["from_location_id"], "")
        r["to_path"] = locs.get(r["to_location_id"], "")
    return rows


def list_lots(conn, f=None):
    f = f or {}
    st = StockState(conn)
    s = settings(conn)
    alert = int_list(s.get("alert_days"), [7, 15, 30, 60, 90])
    out = []
    for l in st.lots.values():
        p = st.products[l["product_id"]]
        if f.get("product_id") and int(f["product_id"]) != p["id"]:
            continue
        if not f.get("include_empty") and l["qty"] <= 1e-9:
            continue
        q = (f.get("q") or "").lower()
        if q and q not in " ".join(str(x or "") for x in (p["name"], l["code"], l["lot_number"], l["supplier"])).lower():
            continue
        row = {k: v for k, v in l.items() if k != "containers"}
        row.update(expiry_status(l["expires_at"], st.ref, alert))
        row["product_name"] = p["name"]
        row["product_code"] = p["code"]
        row["unit"] = p["unit"]
        row["containers"] = []
        for c in l["containers"]:
            if not f.get("include_empty") and c["qty"] <= 1e-9:
                continue
            cr = dict(c)
            cr.update(expiry_status(c["effective_expiry"], st.ref, alert))
            row["containers"].append(cr)
        out.append(row)
    out.sort(key=lambda r: (r["product_name"].lower(), r["expires_at"] or "9999"))
    return out


def lookup_code(conn, code):
    """Resolve código lido (QR, código de barras interno ou EAN de fábrica)."""
    raw = (code or "").strip().upper()
    # leitores USB com layout de teclado diferente trocam o hífen por outros sinais
    c = raw.replace("'", "-").replace("/", "-").replace("_", "-").replace("?", "-")
    if c.startswith("EA-"):
        c = c[3:]
    for prefix, table, kind in (("P-", "products", "produto"), ("L-", "lots", "lote"), ("R-", "containers", "recipiente"),
                                ("LOC-", "locations", "local")):
        if c.startswith(prefix):
            row = conn.execute("SELECT * FROM %s WHERE code=?" % table, (c,)).fetchone()
            if not row and c[len(prefix):].isdigit():
                row = conn.execute("SELECT * FROM %s WHERE id=?" % table, (int(c[len(prefix):]),)).fetchone()
            if row:
                return {"kind": kind, "id": row["id"], "code": row["code"],
                        "product_id": row.get("product_id", row["id"] if kind == "produto" else None)}
    row = conn.execute("SELECT id, code FROM products WHERE barcode=? AND active=1", (code.strip(),)).fetchone()
    if row:
        return {"kind": "produto", "id": row["id"], "code": row["code"], "product_id": row["id"]}
    return None


def get_lot(conn, lot_id):
    st = StockState(conn)
    l = st.lots.get(int(lot_id))
    if not l:
        raise BusinessError("Lote não encontrado.")
    alert = int_list(settings(conn).get("alert_days"), [7, 15, 30, 60, 90])
    row = {k: v for k, v in l.items() if k != "containers"}
    row.update(expiry_status(l["expires_at"], st.ref, alert))
    row["containers"] = []
    for c in l["containers"]:
        cr = dict(c)
        cr.update(expiry_status(c["effective_expiry"], st.ref, alert))
        row["containers"].append(cr)
    p = st.products[l["product_id"]]
    return {"lot": row, "product": p, "movements": list_movements(conn, {"lot_id": lot_id})}


def get_container(conn, cid):
    st = StockState(conn)
    c = st.containers.get(int(cid))
    if not c:
        raise BusinessError("Recipiente não encontrado.")
    alert = int_list(settings(conn).get("alert_days"), [7, 15, 30, 60, 90])
    lot = st.lots[c["lot_id"]]
    cr = dict(c)
    cr.update(expiry_status(c["effective_expiry"], st.ref, alert))
    p = st.products[c["product_id"]]
    return {"container": cr, "lot": {k: v for k, v in lot.items() if k != "containers"}, "product": p,
            "movements": list_movements(conn, {"container_id": cid})}


# --------------------------------------------------------------------------- consumo e autonomia
def observed_rates(conn, window_days):
    since = (date.today() - timedelta(days=window_days)).isoformat()
    rows = conn.execute("""SELECT product_id, -SUM(qty) AS q, MIN(ts) AS first FROM movements
                           WHERE type='CONSUMO' AND ts>=? GROUP BY product_id""", (since,)).fetchall()
    # estornos de consumo
    rev = {r["product_id"]: r["q"] for r in conn.execute(
        """SELECT e.product_id, SUM(e.qty) AS q FROM movements e JOIN movements o ON o.id=e.ref_movement_id
           WHERE e.type='ESTORNO' AND o.type='CONSUMO' AND o.ts>=? GROUP BY e.product_id""", (since,))}
    first_entry = {r["product_id"]: r["f"] for r in conn.execute(
        "SELECT product_id, MIN(ts) AS f FROM movements WHERE type='ENTRADA' GROUP BY product_id")}
    out = {}
    for r in rows:
        q = (r["q"] or 0) - (rev.get(r["product_id"]) or 0)
        first_seen = min(x for x in ((first_entry.get(r["product_id"]) or "9999")[:10], (r["first"] or "9999")[:10]))
        start = max(since, first_seen if first_seen != "9999" else since)
        days = max(7, (date.today() - date.fromisoformat(start[:10])).days)
        days = min(days, window_days)
        out[r["product_id"]] = max(0.0, q) / days
    return out


def compute_autonomy(conn, state=None, people=None, reductions=None, only=None, ref_day=None, horizons=None,
                     global_reduction=0.0):
    """Autonomia por produto. reductions: {grupo: fração 0..1}."""
    st = state or StockState(conn, ref_day)
    s = settings(conn)
    people_default = people if people is not None else inum(s.get("people"), 1)
    horizons = horizons or int_list(s.get("horizons"), [30, 60, 90, 180])
    target_default = inum(s.get("target_days"), 90)
    basis = s.get("forecast_basis") or "planejado"
    obs = observed_rates(conn, inum(s.get("observed_window_days"), 90))
    reductions = reductions or {}
    out = {}
    for p in st.products.values():
        if only and p["id"] not in only:
            continue
        if not p["active"]:
            continue
        cat = st.cats.get(p["category_id"]) or {}
        grupo = cat.get("grupo", "outros")
        prod = dict(p)
        if people is not None and p["cons_mode"] == "por_pessoa":
            prod["cons_people"] = None  # cenário substitui o número de pessoas
        planned = au.base_daily_rate(prod, people_default)
        observed = obs.get(p["id"], 0.0)
        if basis == "observado":
            base = observed or planned
        elif basis == "maior":
            base = max(planned, observed)
        else:
            base = planned or observed
        red = reductions.get(grupo, 0.0) if isinstance(reductions, dict) else 0.0
        red = 1 - (1 - red) * (1 - global_reduction)
        target = p["desired_days"] or target_default
        hs = sorted(set(horizons) | {target})
        model = au.RateModel(base, p["cons_rule"], st.ref, red)
        items = st.items(p["id"])
        sim = au.simulate(items, model, hs, st.ref)
        qty = st.qty(p["id"])
        sug = au.purchase_suggestion(sim, sim["available"], p["min_qty"], p["safety_qty"], p["max_qty"], target)
        days = sim["autonomy_days"]
        out[p["id"]] = {
            "product_id": p["id"], "grupo": grupo, "planned_rate": planned, "observed_rate": observed,
            "daily_rate": sim["daily_rate_now"], "base_rate": base, "reduction": red,
            "available": sim["available"], "total_qty": qty, "usable": sim["usable"], "reserve": sim["reserve"],
            "expired_qty": max(0.0, qty - sim["available"]),
            "autonomy_days": days, "autonomy_capped": sim.get("autonomy_capped", False),
            "simple_days": sim["simple_days"],
            "autonomy_weeks": days / 7 if days is not None else None,
            "autonomy_months": days / 30.4375 if days is not None else None,
            "depletion_date": (st.ref + timedelta(days=int(math.floor(days)))).isoformat() if days is not None and not sim.get("autonomy_capped") else None,
            "need": sim["need"], "covered": sim["covered"],
            "balance": {h: sim["usable"] - sim["need"][h] for h in hs},
            "lost_by_expiry": sim["lost_by_expiry"], "target_days": target,
            "suggest_buy": sug["buy"], "suggest_reasons": sug["reasons"], "capped_by_max": sug["capped_by_max"],
            "weekly_rate": sim["daily_rate_now"] * 7, "monthly_rate": sim["daily_rate_now"] * 30.4375,
        }
    return out


def autonomy_table(conn, people=None, reductions=None, global_reduction=0.0):
    st = StockState(conn)
    calc = compute_autonomy(conn, state=st, people=people, reductions=reductions, global_reduction=global_reduction)
    rows = []
    for pid, c in calc.items():
        p = st.products[pid]
        cat = st.cats.get(p["category_id"]) or {}
        rows.append(dict(c, name=p["name"], code=p["code"], unit=p["unit"], category_name=cat.get("name"),
                         cons_mode=p["cons_mode"], cons_qty=p["cons_qty"], cons_period=p["cons_period"],
                         cons_people=p["cons_people"], critical=p["critical"], has_rule=bool(au.load_rule(p["cons_rule"]))))
    rows.sort(key=lambda r: (r["autonomy_days"] is None, r["autonomy_days"] or 0))
    return rows


def group_autonomy(rows):
    """Autonomia por grupo/categoria = item limitante (menor autonomia entre os que têm consumo)."""
    groups = {}
    for r in rows:
        g = groups.setdefault(r["grupo"], {"grupo": r["grupo"], "label": GROUP_LABELS.get(r["grupo"], r["grupo"]),
                                           "products": 0, "with_consumption": 0, "min_days": None, "limiting": None,
                                           "median_days": None, "_days": []})
        g["products"] += 1
        if r["autonomy_days"] is not None and r["daily_rate"] > 0:
            g["with_consumption"] += 1
            g["_days"].append(r["autonomy_days"])
            if g["min_days"] is None or r["autonomy_days"] < g["min_days"]:
                g["min_days"] = r["autonomy_days"]
                g["limiting"] = r["name"]
    out = []
    for k in GROUP_ORDER + [k for k in groups if k not in GROUP_ORDER]:
        if k in groups:
            g = groups[k]
            d = sorted(g.pop("_days"))
            if d:
                g["median_days"] = d[len(d) // 2]
            out.append(g)
    return out


def overall_autonomy(rows):
    crit = [r for r in rows if (r["critical"]) and r["daily_rate"] > 0 and r["autonomy_days"] is not None]
    if not crit:
        crit = [r for r in rows if r["grupo"] in ("agua", "alimentos") and r["daily_rate"] > 0 and r["autonomy_days"] is not None]
    if not crit:
        return {"days": None, "limiting": None, "basis": "nenhum item com consumo definido"}
    m = min(crit, key=lambda r: r["autonomy_days"])
    return {"days": m["autonomy_days"], "limiting": m["name"], "capped": m.get("autonomy_capped"),
            "basis": "itens críticos" if any(r["critical"] for r in rows) else "água e alimentos"}


def people_comparison(conn, people_list=None):
    s = settings(conn)
    people_list = people_list or int_list(s.get("people_scenarios"), [10, 15, 18])
    st = StockState(conn)
    horizons = int_list(s.get("horizons"), [30, 60, 90, 180])
    per = {n: compute_autonomy(conn, state=st, people=n, horizons=horizons) for n in people_list}
    rows = []
    for pid, p in st.products.items():
        if not p["active"] or pid not in per[people_list[0]]:
            continue
        cat = st.cats.get(p["category_id"]) or {}
        if p["cons_mode"] == "nenhum" and not any(per[n][pid]["daily_rate"] > 0 for n in people_list):
            continue
        row = {"id": pid, "name": p["name"], "unit": p["unit"], "category_name": cat.get("name"), "grupo": cat.get("grupo"),
               "qty": st.qty(pid), "cons_mode": p["cons_mode"], "per_person_day": None, "scenarios": {}}
        if p["cons_mode"] == "por_pessoa":
            row["per_person_day"] = au.base_daily_rate(dict(p, cons_people=1), 1)
        for n in people_list:
            c = per[n][pid]
            row["scenarios"][n] = {"daily": c["daily_rate"], "days": c["autonomy_days"], "capped": c["autonomy_capped"],
                                   "need": c["need"], "buy": {h: max(0.0, c["need"][h] - c["covered"][h]) for h in horizons}}
        rows.append(row)
    rows.sort(key=lambda r: (GROUP_ORDER.index(r["grupo"]) if r["grupo"] in GROUP_ORDER else 99, r["name"]))
    summary = []
    for n in people_list:
        grp = group_autonomy([dict(per[n][r["id"]], name=r["name"], critical=st.products[r["id"]]["critical"]) for r in rows])
        tbl = [dict(per[n][r["id"]], name=r["name"], critical=st.products[r["id"]]["critical"]) for r in rows]
        summary.append({"people": n, "groups": grp, "overall": overall_autonomy(tbl)})
    # consumo por pessoa por categoria (somando por unidade)
    per_cat = {}
    for r in rows:
        if r["per_person_day"]:
            k = (r["category_name"] or "Sem categoria", r["unit"])
            per_cat[k] = per_cat.get(k, 0) + r["per_person_day"]
    per_cat_rows = [{"category": k[0], "unit": k[1], "per_person_day": v,
                     "by_people": {n: v * n for n in people_list}} for k, v in sorted(per_cat.items())]
    return {"people": people_list, "horizons": horizons, "rows": rows, "summary": summary, "per_category": per_cat_rows}


# --------------------------------------------------------------------------- validade
def expiry_list(conn, f=None):
    f = f or {}
    st = StockState(conn)
    s = settings(conn)
    alert = int_list(s.get("alert_days"), [7, 15, 30, 60, 90])
    out = []
    for pid, p in st.products.items():
        if not p["active"]:
            continue
        cat = st.cats.get(p["category_id"]) or {}
        if f.get("category_id") and str(f["category_id"]) not in (str(p["category_id"]), str(p["subcategory_id"])):
            continue
        items = sorted(st.items(pid), key=fefo_key)
        rank = 0
        for i in items:
            es = expiry_status(i["expires_at"], st.ref, alert)
            if es["status"] != "vencido":
                rank += 1
            row = dict(i, **es, product_id=pid, product_name=p["name"], product_code=p["code"], unit=p["unit"],
                       category_name=cat.get("name"), fefo_rank=rank if es["status"] != "vencido" else None,
                       value=i["qty"] * (st.lots[i["lot_id"]]["unit_price"] or 0))
            out.append(row)
    if f.get("location_id"):
        lid = int(f["location_id"])
        out = [r for r in out if r["location_id"] == lid]
    if f.get("lot"):
        q = f["lot"].lower()
        out = [r for r in out if q in (r["lot_code"] or "").lower() or q in (r["lot_number"] or "").lower()]
    if f.get("within_days") not in (None, ""):
        wd = int(f["within_days"])
        out = [r for r in out if r["days"] is not None and r["days"] <= wd]
    if f.get("status"):
        out = [r for r in out if r["status"] == f["status"]]
    if not f.get("include_no_expiry"):
        out = [r for r in out if r["expires_at"]]
    out.sort(key=lambda r: (r["expires_at"] or "9999", r["product_name"]))
    buckets = {"vencido": 0}
    for a in alert:
        buckets["vence_%d" % a] = 0
    for r in out:
        if r["status"] in buckets:
            buckets[r["status"]] += 1
    return {"rows": out, "buckets": buckets, "alert_days": alert}


# --------------------------------------------------------------------------- compras
def purchase_plan(conn, target_days=None, people=None, only_needed=True):
    s = settings(conn)
    st = StockState(conn)
    calc = compute_autonomy(conn, state=st, people=people,
                            horizons=sorted(set(int_list(s.get("horizons"), [30, 60, 90, 180]) + ([int(target_days)] if target_days else []))))
    rows = []
    for pid, c in calc.items():
        p = st.products[pid]
        cat = st.cats.get(p["category_id"]) or {}
        t = int(target_days) if target_days else c["target_days"]
        if target_days:
            need = c["need"].get(t, 0)
            cov = c["covered"].get(t, 0)
            sug = au.purchase_suggestion({"need": c["need"], "covered": c["covered"], "usable": c["usable"],
                                          "lost_by_expiry": c["lost_by_expiry"]},
                                         c["available"], p["min_qty"], p["safety_qty"], p["max_qty"], t)
        else:
            need = c["need"].get(t, 0)
            cov = c["covered"].get(t, 0)
            sug = {"buy": c["suggest_buy"], "reasons": c["suggest_reasons"], "capped_by_max": c["capped_by_max"]}
        last_price = conn.execute("SELECT unit_price FROM lots WHERE product_id=? AND unit_price>0 ORDER BY id DESC LIMIT 1", (pid,)).fetchone()
        price = last_price["unit_price"] if last_price else 0
        row = {"id": pid, "code": p["code"], "name": p["name"], "unit": p["unit"], "category_name": cat.get("name"),
               "grupo": cat.get("grupo"), "qty": c["total_qty"], "available": c["available"], "daily_rate": c["daily_rate"],
               "autonomy_days": c["autonomy_days"], "autonomy_capped": c["autonomy_capped"], "target_days": t,
               "need": need, "covered": cov, "min_qty": p["min_qty"], "safety_qty": p["safety_qty"], "max_qty": p["max_qty"],
               "buy": sug["buy"], "reasons": sug["reasons"], "capped_by_max": sug["capped_by_max"],
               "last_price": price, "estimated_cost": sug["buy"] * price, "lost_by_expiry": c["lost_by_expiry"]}
        if only_needed and row["buy"] <= 1e-9:
            continue
        rows.append(row)
    rows.sort(key=lambda r: (GROUP_ORDER.index(r["grupo"]) if r["grupo"] in GROUP_ORDER else 99, r["name"]))
    return {"rows": rows, "total_cost": sum(r["estimated_cost"] for r in rows)}


# --------------------------------------------------------------------------- dashboard
def dashboard(conn):
    st = StockState(conn)
    s = settings(conn)
    calc = compute_autonomy(conn, state=st)
    prods = list_products(conn, {}, state=st, calc=calc)
    rows = autonomy_table_from(st, calc)
    exp = expiry_list(conn)
    by_unit = {}
    for p in prods:
        by_unit[p["unit"]] = by_unit.get(p["unit"], 0) + p["qty"]
    top_consumption = conn.execute("""SELECT p.id, p.name, p.unit, -SUM(m.qty) AS q FROM movements m JOIN products p ON p.id=m.product_id
                                      WHERE m.type='CONSUMO' AND m.ts>=? GROUP BY p.id ORDER BY q DESC LIMIT 8""",
                                   ((date.today() - timedelta(days=30)).isoformat(),)).fetchall()
    planned_top = sorted([r for r in rows if r["daily_rate"] > 0], key=lambda r: -r["daily_rate"])[:8]
    plan = purchase_plan(conn)
    last_backup = conn.execute("SELECT * FROM backups ORDER BY id DESC LIMIT 1").fetchone()
    last_review = conn.execute("SELECT * FROM reviews ORDER BY id DESC LIMIT 1").fetchone()
    review_interval = inum(s.get("review_interval_days"), 30)
    review_due = True
    if last_review:
        review_due = (date.today() - date.fromisoformat(last_review["ts"][:10])).days >= review_interval
    return {
        "household": s.get("household_name"), "people": inum(s.get("people"), 1),
        "total_products": len(prods), "total_value": sum(p["value"] for p in prods),
        "qty_by_unit": [{"unit": k, "qty": v} for k, v in sorted(by_unit.items(), key=lambda x: -x[1])],
        "below_min": [p for p in prods if "baixo" in p["flags"] or "zerado" in p["flags"]],
        "expiring": [r for r in exp["rows"] if r["status"].startswith("vence_") and r["days"] <= 30][:15],
        "expired": [r for r in exp["rows"] if r["status"] == "vencido"],
        "expiry_buckets": exp["buckets"],
        "groups": group_autonomy(rows), "overall": overall_autonomy(rows),
        "top_consumption": top_consumption, "planned_top": planned_top,
        "to_buy": plan["rows"][:15], "to_buy_count": len(plan["rows"]), "to_buy_cost": plan["total_cost"],
        "last_backup": last_backup, "last_review": last_review, "review_due": review_due,
        "review_interval": review_interval,
        "status_counts": {k: sum(1 for p in prods if p["status"] == k) for k in ("adequado", "baixo", "vencendo", "vencido")},
        "stocked_products": sum(1 for p in prods if p["qty"] > 1e-9),
        "with_consumption": sum(1 for p in prods if p["daily_rate"] > 0),
        "manual_backup": bool(s.get("ipad_last_export")) or bool(conn.execute("SELECT 1 FROM backups WHERE kind='manual' LIMIT 1").fetchone()),
    }


def autonomy_table_from(st, calc):
    rows = []
    for pid, c in calc.items():
        p = st.products[pid]
        rows.append(dict(c, name=p["name"], unit=p["unit"], critical=p["critical"]))
    return rows


# --------------------------------------------------------------------------- emergência
def emergency(conn, reductions=None, global_reduction=0.0, target_days=None, people=None):
    s = settings(conn)
    target = int(target_days or inum(s.get("emergency_target_days"), 90))
    st = StockState(conn)
    reductions = {k: max(0.0, min(1.0, float(v))) for k, v in (reductions or {}).items()}
    horizons = [30, 60, 90, 180]
    calc = compute_autonomy(conn, state=st, people=people, reductions=reductions, global_reduction=global_reduction,
                            horizons=sorted(set(horizons + [target])))
    base_calc = compute_autonomy(conn, state=st, people=people, horizons=sorted(set(horizons + [target])))
    rows = []
    for pid, c in calc.items():
        p = st.products[pid]
        cat = st.cats.get(p["category_id"]) or {}
        b = base_calc[pid]
        items = sorted(st.items(pid), key=fefo_key)
        usable_items = [i for i in items if not i["expires_at"] or i["expires_at"] >= st.ref.isoformat()]
        need_red = None
        if b["daily_rate"] > 0 and (b["autonomy_days"] or 0) < target:
            need_red = au.required_reduction(usable_items, b["base_rate"], p["cons_rule"], target, st.ref)
        rows.append({"id": pid, "code": p["code"], "name": p["name"], "unit": p["unit"], "grupo": c["grupo"],
                     "category_name": cat.get("name"), "essential": cat.get("essential", 0), "priority": cat.get("priority", 50),
                     "critical": p["critical"], "qty": c["total_qty"], "available": c["available"],
                     "daily_rate": c["daily_rate"], "base_daily_rate": b["daily_rate"],
                     "autonomy_days": c["autonomy_days"], "autonomy_capped": c["autonomy_capped"],
                     "base_autonomy_days": b["autonomy_days"],
                     "coverage": {h: (c["covered"][h] / c["need"][h] if c["need"][h] > 0 else None) for h in horizons},
                     "required_reduction": need_red if (need_red or 0) >= 0 else None,
                     "expiry_limited": need_red is not None and need_red < 0,
                     "economize": need_red is not None and (need_red > 0 or need_red < 0),
                     "next_expiry": next((i["expires_at"] for i in usable_items if i["expires_at"]), None),
                     "fefo_first": usable_items[0]["code"] if usable_items else None,
                     "fefo_location": usable_items[0]["location_path"] if usable_items else None,
                     "locations": sorted({i["location_path"] for i in items if i["location_path"]})})
    prio = {g: i for i, g in enumerate(["agua", "alimentos", "medicamentos", "higiene"])}
    rows.sort(key=lambda r: (prio.get(r["grupo"], 10), r["autonomy_days"] if r["autonomy_days"] is not None else 1e9, r["name"]))
    tbl = [dict(r, critical=r["critical"]) for r in rows]
    groups = group_autonomy(tbl)
    for g in groups:
        g["priority"] = g["grupo"] in prio
        g["coverage"] = {}
        for h in horizons:
            members = [r for r in rows if r["grupo"] == g["grupo"] and r["coverage"][h] is not None]
            g["coverage"][h] = min((r["coverage"][h] for r in members), default=None)
    groups.sort(key=lambda g: (not g["priority"], prio.get(g["grupo"], 10)))
    return {"target_days": target, "horizons": horizons, "reductions": reductions, "global_reduction": global_reduction,
            "people": people or inum(s.get("people"), 1), "rows": rows, "groups": groups,
            "overall": overall_autonomy(tbl), "economize": [r for r in rows if r["economize"]],
            "generated_at": now_ts(), "household": s.get("household_name")}


# --------------------------------------------------------------------------- mapa de armazenamento
def storage_map(conn):
    st = StockState(conn)
    locs = conn.execute("SELECT * FROM locations ORDER BY name").fetchall()
    by_parent = {}
    for l in locs:
        by_parent.setdefault(l["parent_id"], []).append(l)
    contents = {}
    alert = int_list(settings(conn).get("alert_days"), [7, 15, 30, 60, 90])
    for pid, p in st.products.items():
        if not p["active"]:
            continue
        for i in st.items(pid):
            es = expiry_status(i["expires_at"], st.ref, alert)
            contents.setdefault(i["location_id"], []).append(
                dict(i, product_id=pid, product_name=p["name"], unit=p["unit"], status=es["status"], days=es["days"]))

    def build(parent):
        out = []
        for l in by_parent.get(parent, []):
            if not l["active"] and not contents.get(l["id"]):
                continue
            node = dict(l, path=st.locs.get(l["id"]), items=sorted(contents.get(l["id"], []), key=lambda x: x["product_name"]),
                        children=build(l["id"]))
            node["total_items"] = len(node["items"]) + sum(c["total_items"] for c in node["children"])
            out.append(node)
        return out
    tree = build(None)
    unplaced = contents.get(None, [])
    return {"tree": tree, "unplaced": unplaced}


# --------------------------------------------------------------------------- revisão periódica
def review_sheet(conn):
    st = StockState(conn)
    alert = int_list(settings(conn).get("alert_days"), [7, 15, 30, 60, 90])
    rows = []
    for pid, p in st.products.items():
        if not p["active"]:
            continue
        for i in sorted(st.items(pid), key=fefo_key):
            es = expiry_status(i["expires_at"], st.ref, alert)
            rows.append(dict(i, product_id=pid, product_name=p["name"], unit=p["unit"], **es))
    rows.sort(key=lambda r: (r["location_path"] or "~", r["product_name"]))
    last = conn.execute("SELECT * FROM reviews ORDER BY id DESC LIMIT 5").fetchall()
    return {"rows": rows, "history": last}


def submit_review(conn, data, responsible=None):
    resp = responsible_or_default(conn, responsible)
    counts = data.get("counts") or []
    adjustments = 0
    with Tx(conn):
        for c in counts:
            if c.get("counted") in (None, ""):
                continue
            payload = {"type": "AJUSTE", "counted_qty": c["counted"], "reason": sstr(data.get("notes")) or "Revisão periódica de estoque"}
            if c.get("container_id"):
                payload["container_id"] = c["container_id"]
            else:
                payload["lot_id"] = c["lot_id"]
            r = register_movement(conn, payload, resp)
            if r.get("movement_ids"):
                adjustments += 1
        conn.execute("INSERT INTO reviews(ts, responsible, items_checked, adjustments, notes) VALUES (?,?,?,?,?)",
                     (now_ts(), resp, len([c for c in counts if c.get("counted") not in (None, "")]) or len(counts),
                      adjustments, sstr(data.get("notes"))))
    return {"adjustments": adjustments}


# --------------------------------------------------------------------------- cenários
def list_scenarios(conn):
    rows = conn.execute("SELECT * FROM scenarios ORDER BY people").fetchall()
    for r in rows:
        r["reductions"] = json.loads(r["reductions"] or "{}")
    return rows


def save_scenario(conn, data):
    name = sstr(data.get("name"))
    people = inum(data.get("people"))
    if not name or not people or people <= 0:
        raise BusinessError("Informe nome e número de pessoas do cenário.")
    red = data.get("reductions") or {}
    with Tx(conn):
        sid = inum(data.get("id"))
        if sid:
            conn.execute("UPDATE scenarios SET name=?, people=?, reductions=?, notes=? WHERE id=?",
                         (name, people, json.dumps(red), sstr(data.get("notes")), sid))
        else:
            conn.execute("INSERT INTO scenarios(name, people, reductions, notes, created_at) VALUES (?,?,?,?,?)",
                         (name, people, json.dumps(red), sstr(data.get("notes")), now_ts()))
    return list_scenarios(conn)


def delete_scenario(conn, sid):
    with Tx(conn):
        conn.execute("DELETE FROM scenarios WHERE id=?", (sid,))
    return list_scenarios(conn)


def audit_list(conn, limit=500, entity=None):
    if entity:
        return conn.execute("SELECT * FROM audit_log WHERE entity=? ORDER BY id DESC LIMIT ?", (entity, limit)).fetchall()
    return conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()


# --------------------------------------------------------------------------- lista de produtos sugeridos
def _cat_desc(mode, qty, period, rule, unit=""):
    if mode == "nenhum":
        return "sem consumo regular (defina se usar)"
    per = {"dia": "dia", "semana": "semana", "mes": "mês"}.get(period)
    if period == "intervalo":
        per = "%d dias" % (rule or {}).get("interval_days", 0)
    q = ("%g" % qty).replace(".", ",") + " " + unit
    return "%s %s %s" % (q, "por pessoa a cada" if (mode == "por_pessoa" and period == "intervalo") else ("por pessoa por" if mode == "por_pessoa" else ("a cada" if period == "intervalo" else "por")), per)


def catalog_list(conn):
    from .catalogo import CATALOGO
    existing = {r["name"].strip().lower() for r in conn.execute("SELECT name FROM products")}
    out = []
    for key, name, cat, sub, unit, mode, qty, period, crit, open_days, rule in CATALOGO:
        out.append({"key": key, "name": name, "category": cat, "subcategory": sub, "unit": unit, "critical": crit,
                    "consumo": _cat_desc(mode, qty, period, rule, unit), "exists": name.lower() in existing})
    return out


def apply_catalog(conn, keys, responsible=None):
    from .catalogo import CATALOGO
    resp = responsible_or_default(conn, responsible)
    keys = set(keys or [])
    cats = list_categories(conn, True)
    existing = {r["name"].strip().lower() for r in conn.execute("SELECT name FROM products")}
    created = []
    for key, name, cat, sub, unit, mode, qty, period, crit, open_days, rule in CATALOGO:
        if key not in keys or name.lower() in existing:
            continue
        top = next((c for c in cats if not c["parent_id"] and c["name"].lower() == cat.lower()), None)
        if not top:
            top = save_category(conn, {"name": cat}, resp)
            cats = list_categories(conn, True)
        sub_id = None
        if sub:
            sc = next((c for c in cats if c["parent_id"] == top["id"] and c["name"].lower() == sub.lower()), None)
            if not sc:
                sc = save_category(conn, {"name": sub, "parent_id": top["id"], "grupo": top["grupo"]}, resp)
                cats = list_categories(conn, True)
            sub_id = sc["id"]
        if not conn.execute("SELECT 1 FROM units WHERE code=?", (unit,)).fetchone():
            save_unit(conn, {"code": unit, "name": unit})
        p = create_product(conn, {"name": name, "category_id": top["id"], "subcategory_id": sub_id, "unit": unit,
                                  "cons_mode": mode, "cons_qty": qty, "cons_period": period, "critical": crit,
                                  "shelf_life_open_days": open_days, "cons_rule": rule,
                                  "notes": "Cadastrado pela lista de sugestões. Consumo sugerido: ajuste à realidade da casa."}, resp)
        created.append(p["product"]["id"])
    return {"created": len(created), "ids": created}


# --------------------------------------------------------------------------- lançamento de estoque em lote
def bulk_entry(conn, items, responsible=None):
    """Registra várias entradas de uma vez (estoque inicial ou compra grande). Tudo ou nada."""
    resp = responsible_or_default(conn, responsible)
    rows = [i for i in (items or []) if i.get("qty") not in (None, "") and fnum(i.get("qty"), 0) > 0]
    if not rows:
        raise BusinessError("Informe a quantidade de pelo menos um produto.")
    created = []
    with Tx(conn):
        for n, i in enumerate(rows, start=1):
            try:
                lot = register_entry(conn, inum(i.get("product_id")), {
                    "qty": i.get("qty"), "expires_at": i.get("expires_at"), "location_id": i.get("location_id"),
                    "unit_price": i.get("unit_price"), "lot_number": i.get("lot_number"),
                    "reason": sstr(i.get("reason")) or "Lançamento de estoque"}, resp)
            except BusinessError as e:
                p = conn.execute("SELECT name FROM products WHERE id=?", (inum(i.get("product_id")),)).fetchone()
                raise BusinessError("%s: %s" % (p["name"] if p else "Item %d" % n, e)) from e
            created.append(lot["id"])
    return {"created": len(created), "lot_ids": created}

"""Servidor HTTP local (somente 127.0.0.1) que entrega a interface e a API.

Nada sai do computador: a interface, as bibliotecas JavaScript, o banco de
dados, os QR Codes, os PDFs e as planilhas são gerados aqui mesmo.
"""
import base64
import csv
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import sqlite3
import threading
import time
import traceback
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

from core import auth
from core import backup as bk
from core import codes, db, exporters, reports
from core import services as s

APP_ID = "estoque-autonomo"
VERSION = "1.1.0"
HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")


# Tipos fixos: no Windows o registro pode associar .js a "text/plain", o que faria o navegador recusar os scripts.
MIME = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".html": "text/html; charset=utf-8",
        ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".ico": "image/x-icon",
        ".json": "application/json", ".txt": "text/plain; charset=utf-8"}


class App:
    def __init__(self, data_dir, db_name="estoque.db", log=print, mobile=False):
        self.data_dir = db.ensure_dir(data_dir)
        self.db_path = os.path.join(self.data_dir, db_name)
        self.backup_dir = db.ensure_dir(os.path.join(self.data_dir, "backups"))
        self.photo_dir = db.ensure_dir(os.path.join(self.data_dir, "fotos"))
        self.tmp_dir = db.ensure_dir(os.path.join(self.data_dir, "temp"))
        self.lock = threading.RLock()
        self.token = secrets.token_urlsafe(24)
        self.log = log
        self.started_at = db.now_ts()
        self.sessions = auth.Sessions()
        self.mobile = mobile
        self.session_flag = os.path.join(self.data_dir, "sessao_em_uso.flag")
        # no iPad o app nunca "encerra" formalmente (o sistema suspende a página), então não há marca de sessão
        self.unclean_previous = (not mobile) and os.path.exists(self.session_flag)
        self.startup_report = None
        self.conn = None
        self.stop_event = threading.Event()
        self.quit_event = threading.Event()
        self._open()
        if not mobile:
            with open(self.session_flag, "w", encoding="utf-8") as f:
                f.write(self.started_at)
        self._last_signature = self.signature()

    # ------------------------------------------------------------------ banco
    def _open(self):
        new = not os.path.exists(self.db_path)
        self.conn = db.connect(self.db_path)
        db.initialize(self.conn, seed=True)
        rep = db.integrity_report(self.conn)
        rep["new_database"] = new
        rep["unclean_previous"] = self.unclean_previous
        self.startup_report = rep
        if self.unclean_previous:
            self.log("Encerramento anterior inesperado detectado — verificação de integridade: %s" % ("OK" if rep["ok"] else "PROBLEMAS"))

    def signature(self):
        with self.lock:
            r = self.conn.execute("""SELECT (SELECT COALESCE(MAX(id),0) FROM movements) AS m, (SELECT COALESCE(MAX(id),0) FROM audit_log) AS a,
                                     (SELECT COUNT(*) FROM products) AS p, (SELECT COALESCE(MAX(updated_at),'') FROM products) AS u""").fetchone()
            return "%s|%s|%s|%s" % (r["m"], r["a"], r["p"], r["u"])

    def backup(self, kind="manual", notes=None, folder=None):
        with self.lock:
            res = bk.make_backup(self.conn, folder or self.backup_dir, kind, notes)
            self._last_signature = self.signature()
            if kind == "automatico":
                keep = s.inum(s.settings(self.conn).get("auto_backup_keep"), 30)
                bk.prune_auto_backups(self.conn, keep)
            return res

    def list_backup_files(self):
        out = []
        for name in sorted(os.listdir(self.backup_dir), reverse=True):
            if not name.endswith(".db"):
                continue
            p = os.path.join(self.backup_dir, name)
            m = re.match(r"estoque_(\d{4}-\d{2}-\d{2})_(\d{2})(\d{2})(\d{2})_([a-z\-]+)", name)
            out.append({"name": name, "path": p, "size": os.path.getsize(p),
                        "ts": ("%s %s:%s:%s" % m.groups()[:4]) if m else datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S"),
                        "kind": m.group(5) if m else "importado", "has_checksum": os.path.exists(p + ".sha256")})
        out.sort(key=lambda r: r["ts"], reverse=True)
        return out

    def restore_from(self, candidate, label):
        """Restaura com segurança: verifica a cópia, faz backup do estado atual e só então substitui."""
        rep = bk.verify_db_file(candidate)
        side = bk.check_sidecar(candidate)
        if side is False:
            raise s.BusinessError("A soma de verificação (SHA-256) não confere: o arquivo de backup foi alterado ou danificado.")
        if not rep.get("sqlite_ok", rep.get("ok")):
            raise s.BusinessError("O backup não passou na verificação de integridade: " + "; ".join(rep.get("issues", [])[:5]))
        with self.lock:
            pre = bk.make_backup(self.conn, self.backup_dir, "pre-restauracao", "Antes de restaurar %s" % label)
            staged = os.path.join(self.tmp_dir, "restaurando.db")
            shutil.copy2(candidate, staged)
            try:
                self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except sqlite3.Error:
                pass
            self.conn.close()
            for ext in ("-wal", "-shm"):
                if os.path.exists(self.db_path + ext):
                    os.remove(self.db_path + ext)
            os.replace(staged, self.db_path)
            self._open()
            self.sessions = auth.Sessions()  # todos entram de novo, com os usuários do banco restaurado
            s.audit(self.conn, "sistema", None, "restauracao", "sistema", None, {"origem": label, "backup_anterior": pre["path"]})
            self._last_signature = self.signature()
        return {"restored": label, "pre_restore_backup": pre["path"], "integrity": self.startup_report}

    def shutdown_backup(self):
        try:
            if self.signature() != self._last_signature:
                self.backup("encerramento", "Backup ao encerrar")
        except Exception as e:  # noqa
            self.log("Falha no backup de encerramento: %s" % e)

    def close(self):
        self.stop_event.set()
        self.shutdown_backup()
        with self.lock:
            try:
                self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                self.conn.close()
            except sqlite3.Error:
                pass
        try:
            os.remove(self.session_flag)
        except OSError:
            pass

    def backup_due(self):
        st = s.settings(self.conn)
        hours = float(st.get("auto_backup_hours") or 6)
        if hours <= 0:
            return False
        files = [f for f in self.list_backup_files() if f["kind"] in ("automatico", "manual", "encerramento")]
        if not files:
            return True
        last = datetime.strptime(files[0]["ts"], "%Y-%m-%d %H:%M:%S")
        age = datetime.now() - last
        changed = self.signature() != self._last_signature
        return (age >= timedelta(hours=hours) and changed) or age >= timedelta(hours=max(hours, 24) * 7)

    def auto_backup_once(self, startup=False):
        """Faz backup automático se estiver na hora (usado no iPad, que não tem processo em segundo plano)."""
        try:
            if (startup and not self.list_backup_files()) or self.backup_due():
                return self.backup("automatico", "Backup automático")
        except Exception as e:  # noqa
            self.log("Backup automático falhou: %s" % e)
        return None

    def auto_backup_loop(self):
        """Backup automático: na inicialização (se necessário) e periodicamente quando há alterações."""
        def due():
            st = s.settings(self.conn)
            hours = float(st.get("auto_backup_hours") or 6)
            if hours <= 0:
                return False
            files = [f for f in self.list_backup_files() if f["kind"] in ("automatico", "manual", "encerramento")]
            if not files:
                return True
            last = datetime.strptime(files[0]["ts"], "%Y-%m-%d %H:%M:%S")
            age = datetime.now() - last
            changed = self.signature() != self._last_signature
            return (age >= timedelta(hours=hours) and changed) or age >= timedelta(hours=max(hours, 24) * 7)
        try:
            files = self.list_backup_files()
            if not files or self.unclean_previous or due():
                self.backup("automatico", "Backup automático na inicialização")
        except Exception as e:  # noqa
            self.log("Backup automático falhou: %s" % e)
        while not self.stop_event.wait(600):
            try:
                if due():
                    self.backup("automatico", "Backup automático periódico")
            except Exception as e:  # noqa
                self.log("Backup automático falhou: %s" % e)


# ---------------------------------------------------------------------- utilidades HTTP
class HttpError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code
        self.msg = msg


def q1(qs, k, default=None):
    v = qs.get(k)
    return v[0] if v else default


def filters_from(qs):
    return {k: v[0] for k, v in qs.items() if k != "t" and v and v[0] != ""}


def import_products_csv(conn, text, responsible):
    rdr = csv.DictReader(io.StringIO(text.lstrip("\ufeff")), delimiter=";" if text.count(";") >= text.count(",") else ",")
    cats = s.list_categories(conn, True)
    tops = {c["name"].lower(): c for c in cats if not c["parent_id"]}
    locs = {l["name"].lower(): l["id"] for l in s.list_locations(conn, True)}
    locs.update({l["path"].lower(): l["id"] for l in s.list_locations(conn, True)})
    created, errors = 0, []
    for i, row in enumerate(rdr, start=2):
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        if not row.get("nome"):
            continue
        try:
            cat = tops.get(row.get("categoria", "").lower())
            if not cat and row.get("categoria"):
                cat = s.save_category(conn, {"name": row["categoria"]}, responsible)
                tops[cat["name"].lower()] = cat
            sub_id = None
            if cat and row.get("subcategoria"):
                sub = next((c for c in s.list_categories(conn, True) if c["parent_id"] == cat["id"] and c["name"].lower() == row["subcategoria"].lower()), None)
                if not sub:
                    sub = s.save_category(conn, {"name": row["subcategoria"], "parent_id": cat["id"], "grupo": cat["grupo"]}, responsible)
                sub_id = sub["id"]
            loc_id = None
            if row.get("local"):
                loc_id = locs.get(row["local"].lower())
                if not loc_id:
                    loc_id = s.save_location(conn, {"name": row["local"]}, responsible)["id"]
                    locs[row["local"].lower()] = loc_id
            data = {"name": row["nome"], "category_id": cat["id"] if cat else None, "subcategory_id": sub_id,
                    "unit": row.get("unidade") or "un", "brand": row.get("marca"), "manufacturer": row.get("fabricante"),
                    "description": row.get("descricao"), "barcode": row.get("codigo_barras"),
                    "min_qty": row.get("minimo") or 0, "max_qty": row.get("maximo") or None, "safety_qty": row.get("seguranca") or 0,
                    "default_location_id": loc_id, "critical": 1 if row.get("critico", "").lower() in ("1", "s", "sim", "x") else 0,
                    "cons_mode": {"pessoa": "por_pessoa", "por_pessoa": "por_pessoa", "total": "total"}.get(row.get("consumo_modo", "").lower(), "nenhum"),
                    "cons_qty": row.get("consumo_qtd") or 0, "cons_period": row.get("consumo_periodo") or "dia",
                    "notes": row.get("observacoes")}
            if row.get("quantidade") and s.fnum(row["quantidade"]) > 0:
                data["initial_lot"] = {"qty": row["quantidade"], "expires_at": row.get("validade"), "lot_number": row.get("lote"),
                                       "supplier": row.get("fornecedor"), "unit_price": row.get("preco_unitario") or 0,
                                       "acquired_at": row.get("data_aquisicao"), "manufactured_at": row.get("fabricacao"),
                                       "location_id": loc_id}
            s.create_product(conn, data, responsible)
            created += 1
        except Exception as e:
            errors.append("Linha %d (%s): %s" % (i, row.get("nome"), e))
    return {"created": created, "errors": errors}


CSV_TEMPLATE = ("nome;categoria;subcategoria;unidade;marca;fabricante;quantidade;validade;lote;fornecedor;preco_unitario;"
                "data_aquisicao;fabricacao;local;minimo;maximo;seguranca;critico;consumo_modo;consumo_qtd;consumo_periodo;codigo_barras;observacoes\r\n"
                "Água mineral 20 L;Água;Água potável;L;Marca X;;100;31/12/2027;A123;Mercado;0,50;;;Depósito;60;;20;sim;pessoa;3;dia;;\r\n"
                "Arroz tipo 1;Alimentos;Grãos e cereais;kg;;;30;15/08/2027;;;5,20;;;Despensa;10;;5;sim;pessoa;0,1;dia;;\r\n")


# ---------------------------------------------------------------------- handler
def make_handler(app):
    routes = []

    def route(method, pattern):
        rx = re.compile("^" + pattern + "$")

        def deco(fn):
            routes.append((method, rx, fn))
            return fn
        return deco

    def resp(body):
        return s.responsible_or_default(app.conn, body.get("responsible") if isinstance(body, dict) else None)

    # ---------------- leitura geral
    @route("POST", "/api/auth/logout")
    def logout(qs, body):
        app.sessions.drop(body.get("_token"))
        return {"ok": True}

    @route("POST", "/api/auth/password")
    def own_password(qs, body):
        auth.change_own_password(app.conn, body["_user"]["id"], body.get("old"), body.get("new"))
        return {"ok": True}

    @route("GET", "/api/users")
    def users(qs, body):
        return auth.list_users(app.conn)

    @route("POST", "/api/users")
    def user_new(qs, body):
        return auth.create_user(app.conn, body.get("username"), body.get("name"), body.get("password"), body.get("role") or "operador",
                                by=body["_user"]["name"])

    @route("PUT", r"/api/users/(\d+)")
    def user_upd(qs, body, uid):
        u = auth.update_user(app.conn, int(uid), body, body["_user"])
        if not u["active"] or body.get("password"):
            app.sessions.drop_user(int(uid))
        return u

    @route("POST", "/api/users/recovery-code")
    def user_recovery(qs, body):
        return {"recovery_code": auth.new_recovery_code(app.conn)}

    @route("GET", "/api/catalog")
    def catalog(qs, body):
        return s.catalog_list(app.conn)

    @route("POST", "/api/catalog")
    def catalog_apply(qs, body):
        return s.apply_catalog(app.conn, body.get("keys") or [], resp(body))

    @route("GET", "/api/ping")
    def ping(qs, body):
        return {"app": APP_ID, "version": VERSION, "started_at": app.started_at}

    @route("GET", "/api/bootstrap")
    def bootstrap(qs, body):
        c = app.conn
        st = {k: v for k, v in s.settings(c).items() if not k.startswith("recovery_")}
        return {"settings": st, "categories": s.list_categories(c, True), "units": s.list_units(c),
                "locations": s.list_locations(c, True), "movement_types": s.MOVEMENT_TYPES, "groups": s.GROUP_LABELS,
                "location_types": s.LOCATION_TYPES, "scenarios": s.list_scenarios(c), "version": VERSION,
                "startup": app.startup_report, "db_path": app.db_path, "backup_dir": app.backup_dir,
                "label_formats": list(exporters.LABEL_FORMATS.keys())}

    @route("GET", "/api/dashboard")
    def dash(qs, body):
        return s.dashboard(app.conn)

    @route("GET", "/api/lookup")
    def lookup(qs, body):
        r = s.lookup_code(app.conn, q1(qs, "code", ""))
        if not r:
            raise HttpError(404, "Código não encontrado neste banco de dados: %s" % q1(qs, "code", ""))
        return r

    # ---------------- produtos
    @route("GET", "/api/products")
    def products(qs, body):
        return s.list_products(app.conn, filters_from(qs))

    @route("GET", r"/api/products/(\d+)")
    def product(qs, body, pid):
        return s.get_product(app.conn, int(pid))

    @route("POST", "/api/products")
    def product_new(qs, body):
        return s.create_product(app.conn, body, resp(body))

    @route("PUT", r"/api/products/(\d+)")
    def product_upd(qs, body, pid):
        return s.update_product(app.conn, int(pid), body, resp(body))

    @route("POST", r"/api/products/(\d+)/photo")
    def product_photo(qs, body, pid):
        data = body.get("data") or ""
        if data.startswith("data:"):
            data = data.split(",", 1)[1]
        raw = base64.b64decode(data) if data else b""
        if not raw:
            s.set_product_photo(app.conn, int(pid), None, resp(body))
            return {"photo": None}
        if len(raw) > 6 * 1024 * 1024:
            raise s.BusinessError("Foto muito grande (máx. 6 MB).")
        ext = ".png" if raw[:4] == b"\x89PNG" else ".jpg"
        name = "P%06d_%s%s" % (int(pid), datetime.now().strftime("%Y%m%d%H%M%S"), ext)
        with open(os.path.join(app.photo_dir, name), "wb") as f:
            f.write(raw)
        s.set_product_photo(app.conn, int(pid), name, resp(body))
        return {"photo": name}

    @route("POST", r"/api/products/(\d+)/entry")
    def entry(qs, body, pid):
        return s.register_entry(app.conn, int(pid), body, resp(body))

    @route("POST", "/api/import-products-csv")
    def imp_csv(qs, body):
        return import_products_csv(app.conn, body.get("text") or "", resp(body))

    # ---------------- lotes e recipientes
    @route("GET", "/api/lots")
    def lots(qs, body):
        return s.list_lots(app.conn, filters_from(qs))

    @route("GET", r"/api/lots/(\d+)")
    def lot(qs, body, lid):
        return s.get_lot(app.conn, int(lid))

    @route("PUT", r"/api/lots/(\d+)")
    def lot_upd(qs, body, lid):
        return s.update_lot(app.conn, int(lid), body, resp(body))

    @route("POST", r"/api/lots/(\d+)/split")
    def lot_split(qs, body, lid):
        return {"container_ids": s.split_lot(app.conn, int(lid), body, resp(body))}

    @route("GET", r"/api/containers/(\d+)")
    def cont(qs, body, cid):
        return s.get_container(app.conn, int(cid))

    @route("PUT", r"/api/containers/(\d+)")
    def cont_upd(qs, body, cid):
        return s.update_container(app.conn, int(cid), body, resp(body))

    @route("POST", r"/api/containers/(\d+)/return")
    def cont_ret(qs, body, cid):
        return s.return_container_to_lot(app.conn, int(cid), resp(body), body.get("reason"))

    # ---------------- movimentações
    @route("GET", "/api/movements")
    def movs(qs, body):
        return s.list_movements(app.conn, filters_from(qs))

    @route("POST", "/api/movements")
    def mov_new(qs, body):
        return s.register_movement(app.conn, body, resp(body))

    @route("POST", "/api/consume")
    def consume(qs, body):
        return s.consume_fefo(app.conn, int(body["product_id"]), s.fnum(body.get("qty")), resp(body), body.get("reason"),
                              ts=s._mov_ts(body))

    @route("POST", r"/api/movements/(\d+)/reverse")
    def mov_rev(qs, body, mid):
        return s.reverse_movement(app.conn, int(mid), body.get("reason"), resp(body))

    # ---------------- consumo, validade, compras, emergência
    @route("GET", "/api/autonomy")
    def autonomy(qs, body):
        people = s.inum(q1(qs, "people"))
        rows = s.autonomy_table(app.conn, people=people)
        return {"rows": rows, "groups": s.group_autonomy(rows), "overall": s.overall_autonomy(rows)}

    @route("GET", "/api/people")
    def people(qs, body):
        lst = q1(qs, "list")
        return s.people_comparison(app.conn, [int(x) for x in lst.split(",") if x.strip()] if lst else None)

    @route("GET", "/api/expiry")
    def expiry(qs, body):
        f = filters_from(qs)
        return s.expiry_list(app.conn, f)

    @route("GET", "/api/purchase")
    def purchase(qs, body):
        return s.purchase_plan(app.conn, q1(qs, "target_days") or None, people=s.inum(q1(qs, "people")),
                               only_needed=q1(qs, "all") != "1")

    @route("POST", "/api/emergency")
    def emerg(qs, body):
        red = {k: s.fnum(v) / 100.0 for k, v in (body.get("reductions") or {}).items() if v not in (None, "")}
        return s.emergency(app.conn, red, s.fnum(body.get("global_reduction"), 0) / 100.0, body.get("target_days") or None,
                           s.inum(body.get("people")))

    @route("GET", "/api/map")
    def smap(qs, body):
        return s.storage_map(app.conn)

    @route("GET", "/api/review")
    def review(qs, body):
        return s.review_sheet(app.conn)

    @route("POST", "/api/review")
    def review_post(qs, body):
        return s.submit_review(app.conn, body, resp(body))

    # ---------------- cadastros auxiliares
    @route("POST", "/api/categories")
    def cat_save(qs, body):
        return s.save_category(app.conn, body, body.get("responsible") or "usuário")

    @route("DELETE", r"/api/categories/(\d+)")
    def cat_del(qs, body, cid):
        return s.delete_category(app.conn, int(cid), body.get("responsible") or "usuário")

    @route("POST", "/api/locations")
    def loc_save(qs, body):
        return s.save_location(app.conn, body, body.get("responsible") or "usuário")

    @route("DELETE", r"/api/locations/(\d+)")
    def loc_del(qs, body, lid):
        return s.delete_location(app.conn, int(lid), body.get("responsible") or "usuário")

    @route("POST", "/api/units")
    def unit_save(qs, body):
        return s.save_unit(app.conn, body)

    @route("POST", "/api/scenarios")
    def scen_save(qs, body):
        return s.save_scenario(app.conn, body)

    @route("DELETE", r"/api/scenarios/(\d+)")
    def scen_del(qs, body, sid):
        return s.delete_scenario(app.conn, int(sid))

    @route("PUT", "/api/settings")
    def settings_put(qs, body):
        vals = body.get("values") or {}
        if body["_user"]["role"] != "admin" and not set(vals) <= {"people_scenarios", "ipad_last_export"}:
            raise auth.AuthError("Somente um administrador altera as configurações.", 403)
        for k in ("recovery_hash", "recovery_salt", "schema_version"):
            vals.pop(k, None)
        return s.update_settings(app.conn, vals, body.get("responsible") or "usuário")

    @route("GET", "/api/audit")
    def audit(qs, body):
        return s.audit_list(app.conn, int(q1(qs, "limit", "500")), q1(qs, "entity"))

    # ---------------- backup
    @route("GET", "/api/backups")
    def backups(qs, body):
        return {"files": app.list_backup_files(), "drives": bk.removable_drives(), "folder": app.backup_dir,
                "history": app.conn.execute("SELECT * FROM backups ORDER BY id DESC LIMIT 100").fetchall(),
                "db_path": app.db_path, "db_size": os.path.getsize(app.db_path)}

    @route("POST", "/api/backups")
    def backup_new(qs, body):
        dest = (body.get("dest") or "").strip()
        res = app.backup("manual", body.get("notes"))
        if dest:
            cp = bk.copy_backup_to(res["path"], dest, overwrite=bool(body.get("overwrite")))
            res["copy"] = cp
        return res

    @route("POST", "/api/backups/copy")
    def backup_copy(qs, body):
        src = _backup_file(body.get("name"))
        dest = (body.get("dest") or "").strip()
        if not dest:
            raise s.BusinessError("Informe a pasta de destino (por exemplo, a letra do pendrive: E:\\).")
        res = bk.copy_backup_to(src, dest, overwrite=bool(body.get("overwrite")))
        if res.get("exists"):
            return {"needs_confirmation": True, "path": res["path"],
                    "message": "Já existe um backup com esse nome no destino. Confirme para substituir."}
        return res

    @route("POST", "/api/backups/verify")
    def backup_verify(qs, body):
        src = _backup_file(body.get("name")) if body.get("name") else (body.get("path") or "")
        rep = bk.verify_db_file(src)
        rep["checksum_ok"] = bk.check_sidecar(src)
        return rep

    @route("POST", "/api/backups/restore")
    def backup_restore(qs, body):
        if body.get("confirm") != "RESTAURAR":
            raise s.BusinessError("Confirmação ausente. Digite RESTAURAR para confirmar.")
        if body.get("name"):
            src = _backup_file(body["name"])
        else:
            src = (body.get("path") or "").strip().strip('"')
            if not os.path.isfile(src):
                raise s.BusinessError("Arquivo não encontrado: %s" % src)
        return app.restore_from(src, os.path.basename(src))

    @route("POST", "/api/restore-upload")
    def restore_upload(qs, body):
        if body.get("confirm") != "RESTAURAR":
            raise s.BusinessError("Confirmação ausente. Digite RESTAURAR para confirmar.")
        raw = base64.b64decode(body.get("data") or "")
        p = os.path.join(app.tmp_dir, "enviado_%s.db" % datetime.now().strftime("%Y%m%d%H%M%S"))
        with open(p, "wb") as f:
            f.write(raw)
        try:
            return app.restore_from(p, body.get("filename") or "arquivo enviado")
        finally:
            try:
                os.remove(p)
            except OSError:
                pass

    @route("POST", "/api/import-json")
    def import_json(qs, body):
        if body.get("confirm") != "SUBSTITUIR":
            raise s.BusinessError("Confirmação ausente. Digite SUBSTITUIR para confirmar.")
        p = os.path.join(app.tmp_dir, "importacao.db")
        rep = bk.import_json_into_new_db(body.get("data"), p)
        if not rep["ok"]:
            raise s.BusinessError("Dados importados inconsistentes: " + "; ".join(rep["issues"][:5]))
        try:
            return app.restore_from(p, "importação JSON")
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.remove(p + ext)
                except OSError:
                    pass

    @route("GET", "/api/integrity")
    def integrity(qs, body):
        return db.integrity_report(app.conn)

    @route("POST", "/api/shutdown")
    def shutdown(qs, body):
        threading.Thread(target=lambda: (time.sleep(0.5), app.quit_event.set()), daemon=True).start()
        return {"ok": True}

    def _backup_file(name):
        name = os.path.basename(name or "")
        p = os.path.join(app.backup_dir, name)
        if not name.endswith(".db") or not os.path.isfile(p):
            raise s.BusinessError("Backup não encontrado.")
        return p

    # ---------------- arquivos gerados
    def label_items(qs):
        out = []
        st = s.StockState(app.conn)
        for tok in (q1(qs, "items", "") or "").split(","):
            tok = tok.strip()
            if not tok or ":" not in tok:
                continue
            kind, i = tok.split(":", 1)
            i = int(i)
            if kind == "P" and i in st.products:
                p = st.products[i]
                cat = st.cats.get(p["category_id"]) or {}
                out.append({"code": p["code"], "title": p["name"], "line1": " ".join(x for x in (p["brand"] or "", cat.get("name") or "") if x),
                            "line2": "Unidade: %s" % p["unit"], "line3": st.locs.get(p["default_location_id"], "")})
            elif kind == "L" and i in st.lots:
                l = st.lots[i]
                p = st.products[l["product_id"]]
                out.append({"code": l["code"], "title": p["name"],
                            "line1": "Lote %s" % (l["lot_number"] or l["code"]) + ("  |  %s %s" % (exporters.fmt_num(l["qty_acquired"], 3), p["unit"])),
                            "line2": "Validade: %s" % (exporters.fmt_date(l["expires_at"]) or "—"),
                            "line3": "Entrada: %s  %s" % (exporters.fmt_date(l["entry_at"]), l["location_path"])})
            elif kind == "R" and i in st.containers:
                c = st.containers[i]
                l = st.lots[c["lot_id"]]
                p = st.products[c["product_id"]]
                out.append({"code": c["code"], "title": "%s — %s" % (p["name"], c["label"] or c["code"]),
                            "line1": "%s %s  |  lote %s" % (exporters.fmt_num(c["initial_qty"], 3), p["unit"], l["lot_number"] or l["code"]),
                            "line2": "Validade: %s" % (exporters.fmt_date(c["effective_expiry"]) or "—"),
                            "line3": "Armazenado: %s  %s" % (exporters.fmt_date(c["stored_at"]), c["location_path"])})
            elif kind == "LOC":
                r = app.conn.execute("SELECT * FROM locations WHERE id=?", (i,)).fetchone()
                if r:
                    out.append({"code": r["code"], "title": st.locs.get(i), "line1": "Local de armazenamento", "line2": r["type"]})
        return out

    def get_file(path, qs):
        """Downloads/visualizações (relatórios, etiquetas, códigos, exportações)."""
        c = app.conn
        if path == "/codigo/qr.svg":
            return "image/svg+xml", codes.qr_svg(codes.payload(q1(qs, "c", ""))).encode(), None
        if path == "/codigo/barras.svg":
            return "image/svg+xml", codes.barcode_svg(codes.payload(q1(qs, "c", ""))).encode(), None
        if path == "/relatorio":
            kind = q1(qs, "tipo", "estoque")
            fmt = q1(qs, "formato", "html")
            rep = reports.build(c, kind, filters_from(qs))
            stamp = datetime.now().strftime("%Y%m%d_%H%M")
            base = "%s_%s" % (kind, stamp)
            if fmt == "pdf":
                return "application/pdf", exporters.table_pdf(rep["title"], rep.get("subtitle"), rep["sections"], rep.get("landscape", True), rep.get("footer")), base + ".pdf"
            if fmt == "csv":
                cols, rows = _flat(rep)
                return "text/csv; charset=utf-8", exporters.to_csv(cols, rows), base + ".csv"
            if fmt == "xlsx":
                sheets = [((t or rep["title"])[:31], rep["title"] + (" — " + t if t else ""), [x for x in cols if x["key"] != "_blank"], rows)
                          for t, cols, rows in rep["sections"]]
                return ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", exporters.to_xlsx(sheets), base + ".xlsx")
            return "text/html; charset=utf-8", reports.to_html(rep).encode("utf-8"), None
        if path == "/etiquetas":
            items = label_items(qs)
            fmt = q1(qs, "modelo", "a4_3x8")
            copies = int(q1(qs, "copias", "1") or 1)
            skip = int(q1(qs, "pular", "0") or 0)
            if q1(qs, "formato", "html") == "pdf":
                return "application/pdf", exporters.labels_pdf(items, fmt, copies, skip), "etiquetas_%s.pdf" % datetime.now().strftime("%Y%m%d_%H%M")
            return "text/html; charset=utf-8", labels_html(items, fmt, copies, skip).encode("utf-8"), None
        if path == "/exportar/json":
            data = json.dumps(bk.export_json(c), ensure_ascii=False, indent=1, default=str).encode("utf-8")
            return "application/json", data, "estoque_exportacao_%s.json" % datetime.now().strftime("%Y%m%d_%H%M")
        if path == "/exportar/banco":
            res = app.backup("manual", "Exportação integral do banco")
            with open(res["path"], "rb") as f:
                return "application/octet-stream", f.read(), os.path.basename(res["path"])
        if path == "/exportar/modelo-produtos.csv":
            return "text/csv; charset=utf-8", ("\ufeff" + CSV_TEMPLATE).encode("utf-8"), "modelo_importacao_produtos.csv"
        if path == "/exportar/planilha-completa":
            sheets = []
            for kind in ("estoque", "lotes", "validade", "autonomia", "compras", "movimentacoes"):
                rep = reports.build(c, kind, {})
                for t, cols, rows in rep["sections"]:
                    sheets.append((rep["title"][:31], rep["title"], [x for x in cols if x["key"] != "_blank"], rows))
            return ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", exporters.to_xlsx(sheets),
                    "estoque_completo_%s.xlsx" % datetime.now().strftime("%Y%m%d_%H%M"))
        return None

    def _flat(rep):
        if len(rep["sections"]) == 1:
            return [x for x in rep["sections"][0][1] if x["key"] != "_blank"], rep["sections"][0][2]
        cols = [{"label": "Seção", "key": "_section"}]
        seen = set()
        rows = []
        for t, cs, rs in rep["sections"]:
            for x in cs:
                if x["key"] != "_blank" and x["key"] not in seen:
                    seen.add(x["key"])
                    cols.append(x)
            for r in rs:
                rows.append(dict(r, _section=t))
        return cols, rows

    def json_result(code, obj):
        return code, "application/json; charset=utf-8", json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"), None

    def required_role(method, path):
        if path.startswith("/api/users") or path in ("/api/backups/restore", "/api/restore-upload", "/api/import-json") \
                or path in ("/exportar/banco", "/exportar/json") \
                or (method == "DELETE" and path.startswith(("/api/categories", "/api/locations"))):
            return "admin"
        if method == "GET" or path in ("/api/shutdown", "/api/auth/logout", "/api/auth/password"):
            return "consulta"
        return "operador"

    def auth_route(method, path, body, token):
        c = app.conn
        timeout = s.inum(s.settings(c).get("session_timeout_min"), 30)
        if path == "/api/auth/status":
            sess = app.sessions.get(token, timeout)
            return {"has_users": auth.has_users(c), "user": sess["user"] if sess else None,
                    "demo": s.settings(c).get("demo_mode") == "1", "household": s.settings(c).get("household_name")}
        if path == "/api/auth/setup":
            u, code = auth.setup_first_admin(c, body.get("username"), body.get("name"), body.get("password"))
            return {"user": u, "session": app.sessions.create(u), "recovery_code": code}
        if path == "/api/auth/login":
            u = auth.check_login(c, body.get("username"), body.get("password"))
            return {"user": u, "session": app.sessions.create(u)}
        if path == "/api/auth/recover":
            code = auth.recover(c, body.get("code"), body.get("username"), body.get("password"))
            return {"ok": True, "recovery_code": code}
        return None

    def dispatch(method, path, qs, body, token=None):
        """Executa uma requisição. Usado pelo servidor HTTP (Windows) e pelo app do iPad."""
        try:
            token = token or q1(qs, "s")
            if path.startswith("/api/auth/") and path != "/api/auth/logout" and path != "/api/auth/password":
                with app.lock:
                    r = auth_route(method, path, body or {}, token)
                if r is None:
                    raise HttpError(404, "Rota não encontrada")
                return json_result(200, r)
            with app.lock:
                sess = app.sessions.get(token, s.inum(s.settings(app.conn).get("session_timeout_min"), 30))
            if not sess:
                return json_result(401, {"error": "Sua sessão terminou. Entre novamente com usuário e senha.", "auth": True})
            user = sess["user"]
            need = required_role(method, path)
            if auth.ROLE_LEVEL.get(user["role"], 0) < auth.ROLE_LEVEL[need]:
                return json_result(403, {"error": "Seu perfil (%s) não permite esta operação. Peça a um %s." % (
                    auth.ROLES.get(user["role"]), "administrador" if need == "admin" else "operador ou administrador")})
            body = dict(body or {})
            body["responsible"] = user["name"]  # o responsável é sempre o usuário conectado
            body["_user"] = user
            body["_token"] = token
            if method == "GET" and path.startswith("/foto/"):
                fp = os.path.join(app.photo_dir, os.path.basename(path))
                if not os.path.isfile(fp):
                    raise HttpError(404, "Foto não encontrada")
                with open(fp, "rb") as f:
                    return 200, MIME.get(os.path.splitext(fp)[1].lower(), "image/jpeg"), f.read(), None
            if method == "GET" and not path.startswith("/api/"):
                with app.lock:
                    r = get_file(path, qs)
                if r is None:
                    raise HttpError(404, "Não encontrado")
                ctype, data, fname = r
                if q1(qs, "baixar") == "1" and not fname:
                    fname = "relatorio_%s.html" % datetime.now().strftime("%Y%m%d_%H%M")
                return 200, ctype, data, fname
            for m, rx, fn in routes:
                if m == method:
                    mt = rx.match(path)
                    if mt:
                        with app.lock:
                            result = fn(qs, body or {}, *mt.groups())
                        return json_result(200, result)
            raise HttpError(404, "Rota não encontrada: %s" % path)
        except HttpError as e:
            return json_result(e.code, {"error": e.msg})
        except auth.AuthError as e:
            return json_result(e.code, {"error": str(e), "auth": e.code == 401})
        except s.BusinessError as e:
            return json_result(400, {"error": str(e)})
        except sqlite3.IntegrityError as e:
            return json_result(400, {"error": "Operação recusada pelo banco de dados: %s" % e})
        except (ValueError, KeyError) as e:
            return json_result(400, {"error": "Dados inválidos: %s" % e})
        except Exception as e:  # noqa
            app.log(traceback.format_exc())
            return json_result(500, {"error": "Erro interno: %s" % e})

    class Handler(BaseHTTPRequestHandler):
        server_version = "EstoqueAutonomo/" + VERSION
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            pass

        def _send(self, code, ctype, data, filename=None, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            if filename:
                self.send_header("Content-Disposition", "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (
                    filename.encode("ascii", "replace").decode(), quote(filename)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        def _json(self, code, obj):
            self._send(*json_result(code, obj)[:3])

        def _host_ok(self):
            host = (self.headers.get("Host") or "").split(":")[0]
            return host in ("127.0.0.1", "localhost")

        def _auth_ok(self, qs):
            return secrets.compare_digest(self.headers.get("X-EA-Token") or q1(qs, "t", "") or "", app.token)

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        def do_PUT(self):
            self._dispatch("PUT")

        def do_DELETE(self):
            self._dispatch("DELETE")

        def _dispatch(self, method):
            try:
                if not self._host_ok():
                    return self._send(403, "text/plain", b"Acesso permitido somente a partir deste computador.")
                u = urlparse(self.path)
                path = unquote(u.path)
                qs = parse_qs(u.query, keep_blank_values=True)
                if method == "GET" and (path == "/" or path == "/index.html"):
                    with open(os.path.join(WEB, "index.html"), encoding="utf-8") as f:
                        html = f.read().replace("__EA_TOKEN__", app.token).replace("__EA_VERSION__", VERSION)
                    return self._send(200, "text/html; charset=utf-8", html.encode("utf-8"))
                if method == "GET" and path.startswith("/static/"):
                    rel = os.path.normpath(path[len("/static/"):]).replace("\\", "/")
                    fp = os.path.join(WEB, rel)
                    if rel.startswith("..") or not os.path.isfile(fp):
                        return self._json(404, {"error": "não encontrado"})
                    ctype = MIME.get(os.path.splitext(fp)[1].lower()) or mimetypes.guess_type(fp)[0] or "application/octet-stream"
                    with open(fp, "rb") as f:
                        return self._send(200, ctype, f.read())
                if method == "GET" and path == "/api/ping":
                    return self._json(200, ping(qs, {}))
                if not self._auth_ok(qs):
                    return self._json(401, {"error": "Sessão inválida. Feche e abra o sistema novamente."})
                body = {}
                if method in ("POST", "PUT", "DELETE"):
                    n = int(self.headers.get("Content-Length") or 0)
                    if n > 200 * 1024 * 1024:
                        return self._json(413, {"error": "Arquivo grande demais."})
                    raw = self.rfile.read(n) if n else b""
                    if raw:
                        body = json.loads(raw.decode("utf-8"))
                self._send(*dispatch(method, path, qs, body, self.headers.get("X-EA-Session")))
            except Exception as e:  # noqa
                app.log(traceback.format_exc())
                try:
                    self._json(500, {"error": "Erro interno: %s" % e})
                except Exception:
                    pass

    Handler.dispatch = staticmethod(dispatch)
    return Handler


def labels_html(items, fmt, copies, skip):
    w, h, cols, rows, top, left, gx, gy, page = exporters.LABEL_FORMATS.get(fmt, exporters.LABEL_FORMATS["a4_3x8"])
    seq = [None] * skip + [x for x in items for _ in range(max(1, copies))]
    css = ("@page{size:%s;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif}"
           ".sheet{width:%s;padding:%smm 0 0 %smm;display:grid;grid-template-columns:repeat(%d,%smm);column-gap:%smm;row-gap:%smm;page-break-after:always}"
           ".lab{width:%smm;height:%smm;display:flex;gap:2mm;padding:2mm;overflow:hidden;align-items:center}"
           ".lab img.qr{height:%smm;width:%smm;flex:none}.t{flex:1;min-width:0;display:flex;flex-direction:column;height:100%%;justify-content:center}"
           ".t b{font-size:%spt;line-height:1.1;max-height:2.3em;overflow:hidden}.t span{font-size:%spt;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}"
           ".t img.bc{height:%smm;width:100%%;margin-top:1mm}.t code{font-size:7pt;font-weight:bold}"
           "@media screen{body{background:#888}.sheet{background:#fff;margin:10px auto;box-shadow:0 0 6px #000}.lab{outline:1px dashed #bbb}}") % (
        "A4 portrait" if page == "A4" else "%smm %smm" % (w, h), "210mm" if page == "A4" else "%smm" % w, top, left, cols, w, gx, gy, w, h,
        min(h - 4, w * 0.42), min(h - 4, w * 0.42), 9 if h > 30 else 7.5, 7 if h > 30 else 6, max(4, min(h * 0.18, 8)))
    per = cols * rows
    out = ['<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Etiquetas</title><style>%s</style></head><body>' % css]
    for i in range(0, max(len(seq), 1), per):
        out.append('<div class="sheet">')
        for lab in seq[i:i + per]:
            if lab is None:
                out.append('<div class="lab"></div>')
                continue
            from html import escape as e
            pl = codes.payload(lab["code"])
            qr = "data:image/svg+xml;base64," + base64.b64encode(codes.qr_svg(pl).encode()).decode()
            bc = "data:image/svg+xml;base64," + base64.b64encode(codes.barcode_svg(pl).encode()).decode()
            lines = "".join("<span>%s</span>" % e(lab[k]) for k in ("line1", "line2", "line3") if lab.get(k))
            out.append('<div class="lab"><img class="qr" src="%s" alt=""><div class="t"><b>%s</b>%s<img class="bc" src="%s" alt=""><code>%s</code></div></div>'
                       % (qr, e(lab.get("title") or ""), lines, bc, e(pl)))
        out.append("</div>")
    out.append("<script>window.onload=function(){if(location.hash==='#imprimir')setTimeout(function(){window.print()},300)}</script></body></html>")
    return "".join(out)


def make_dispatch(app):
    """Função de atendimento sem HTTP (usada pelo app do iPad, que roda o mesmo código no navegador)."""
    return make_handler(app).dispatch


def serve(app, port=8765, host="127.0.0.1", tries=20):
    handler = make_handler(app)
    last = None
    for p in range(port, port + tries):
        try:
            srv = ThreadingHTTPServer((host, p), handler)
            srv.daemon_threads = True
            app.server = srv
            app.port = p
            return srv
        except OSError as e:
            last = e
    raise last
